﻿using _01.Exeptions;
using _01.Models;
namespace _01
{
   
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Alter = 101 ;
        }
    }
}
