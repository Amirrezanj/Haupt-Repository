﻿namespace _02
{
    class Prüfsumme
    {

    }
}
