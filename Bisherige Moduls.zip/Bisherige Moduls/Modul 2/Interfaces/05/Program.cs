﻿namespace _05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
    public class Ninja
    {

    }
    public class Schwert
    {

    }
    public class shuriken
    {

    }
}
