﻿namespace Aufgabe01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            (DateTime.Now);
        }
    }
}
