﻿namespace Aufgabe01
{
    public enum Gender
    {
        Male,
        Female,
        Diverse
    }
}
