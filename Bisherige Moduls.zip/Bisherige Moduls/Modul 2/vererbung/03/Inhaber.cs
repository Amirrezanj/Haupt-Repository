﻿namespace _03
{
    public class Inhaber
    {
        private string _vorname;
        private string _nachname;

        public Inhaber(string vorname,string nachname) 
        {
            _vorname = vorname;
            _nachname = nachname;
        }
    }
}
