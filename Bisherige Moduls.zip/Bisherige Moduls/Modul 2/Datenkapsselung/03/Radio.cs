﻿namespace _03
{
    internal class Radio
    {
        private bool _eingeschaltet = false;
        private int _lautsärke;

        public void Lauter()
        {
            _lautsärke += 1;
        }
        public void Leiser()
        {
            _lautsärke -= 1;
        }

        public void SetLeiser

    }
}