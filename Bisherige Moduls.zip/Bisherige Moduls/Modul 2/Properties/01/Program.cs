﻿using _01.Models;

namespace _01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student("amir", 28) { Note=1};
            Student student2 = new Student("tasos", 45);
            
        }
    }
}
