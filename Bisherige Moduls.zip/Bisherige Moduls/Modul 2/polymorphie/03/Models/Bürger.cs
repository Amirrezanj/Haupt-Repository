﻿namespace _03.Models
{
    internal class Bürger : Einwohner
    {
        public Bürger(int einkommen) : base(einkommen)
        {
        }
    }
}
