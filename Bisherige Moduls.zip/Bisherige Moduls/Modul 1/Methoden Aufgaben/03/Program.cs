﻿namespace _03
{
    internal class Program
    {
        public static int WieViel(string x)
        {
            return x.Length;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(WieViel("sam"));
        }
    }
}
