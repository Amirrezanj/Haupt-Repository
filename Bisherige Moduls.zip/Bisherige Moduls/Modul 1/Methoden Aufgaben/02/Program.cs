﻿namespace _02
{
    internal class Program
    {
        public static double komma(double a, double b, double c)
        {
            return a * b * c;
                       
        }
        static void Main(string[] args)
        {
            Console.WriteLine(komma(1.2,1.3,1.4));
        }
    }
}
