﻿namespace _10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char buchstabe = 'A';
            int tasos = buchstabe;
            Console.WriteLine(tasos);
        }
    }
}