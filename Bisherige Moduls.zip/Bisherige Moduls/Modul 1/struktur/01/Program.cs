﻿namespace _01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            vector3 veci;

            veci.x = 1; 
            veci.y = 2;
            veci.z = 3;

            Console.WriteLine(veci.x);
            Console.WriteLine(veci.y);
            Console.WriteLine(veci.z);




            vector3 veci2;

            veci2.x = 4;
            veci2.y = 5;
            veci2.z = 6;

            Console.WriteLine(veci2.x);
            Console.WriteLine(veci2.y);
            Console.WriteLine(veci2.z);
        }
    }
}
