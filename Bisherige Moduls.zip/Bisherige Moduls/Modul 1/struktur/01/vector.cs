﻿namespace _01
{
    struct vector3
    {
        public double x;
        public double y;
        public double z;
    }
}
