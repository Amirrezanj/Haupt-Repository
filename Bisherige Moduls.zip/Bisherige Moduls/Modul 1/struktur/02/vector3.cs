﻿namespace _02
{
    struct vector3
    {
        public double x;
        public double y;
        public double z;


        public string AsString()
        {
            return $"„{x},{y},{z}“";
        }
    }
}
