﻿namespace _07
{
    struct Date
    {
        public int Day;
        public int Month;
        public int Year;
    }
}