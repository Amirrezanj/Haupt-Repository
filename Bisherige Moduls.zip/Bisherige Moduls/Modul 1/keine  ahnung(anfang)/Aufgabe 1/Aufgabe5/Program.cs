﻿namespace Aufgabe5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wie ist Ihr Name?");
            string name = Console.ReadLine();
            Console.Write("Hallo " + name);
        }
    }
}
