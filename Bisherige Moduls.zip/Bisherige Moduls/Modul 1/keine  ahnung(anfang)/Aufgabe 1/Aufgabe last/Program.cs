﻿namespace Aufgabe_last
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("pl write your name");
            string name = Console.ReadLine();
            Console.WriteLine("and now your fav farbe");
            string farbe = Console.ReadLine();
            Console.Write("Hallo " + " "+ name + "!");
            Console.Write("Deine fav farbe ist " + farbe);

        }
    }
}
