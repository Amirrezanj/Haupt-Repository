﻿namespace Aufgabe_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hallo");
            Console.WriteLine("\t ich bin");
            Console.WriteLine("\t\t\t Peter");
        }
    }
}
