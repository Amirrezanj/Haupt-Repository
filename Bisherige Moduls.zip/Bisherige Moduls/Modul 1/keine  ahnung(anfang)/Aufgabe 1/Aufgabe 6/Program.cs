﻿namespace Aufgabe_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wie alt sind sie?");
            string alter = Console.ReadLine();
            Console.WriteLine("u are "+ alter);
        }
    }
}
