﻿namespace Aufgabe_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hi write ur name");
            string name = Console.ReadLine();
            Console.WriteLine("and now how old u R");
            string alter = Console.ReadLine();
            Console.WriteLine("hallo " + name + " u are " + alter + " jahre alt");
        }
    }
}
