﻿namespace Aufgabe_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("schreiben sie text");
            string value = Console.ReadLine();
            Console.WriteLine("\"" +value + "\"");
        }
    }
}
