﻿namespace Aufgabe_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****** Meine Musiktitel ******");
            Console.WriteLine("N = Neuen Eintrag hinzufügen");
            Console.WriteLine("L = Eintrag löschen");
            Console.WriteLine("F = Titel finden");
            Console.WriteLine("A = Alle Einträge anzeigen");
            Console.WriteLine("B = Programm beenden");

        }
    }
}
