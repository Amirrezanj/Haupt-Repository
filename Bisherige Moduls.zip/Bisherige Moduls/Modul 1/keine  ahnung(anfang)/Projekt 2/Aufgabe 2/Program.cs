﻿namespace Aufgabe_2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int a = 10;
            int b = 7;
            int amir = a - b;
            Console.WriteLine(amir);
        }
    }
}