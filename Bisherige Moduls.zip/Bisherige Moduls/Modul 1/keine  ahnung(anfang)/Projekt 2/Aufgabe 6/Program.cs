﻿namespace Aufgabe_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 9;
            Console.WriteLine(a*a);
        }
    }
}
