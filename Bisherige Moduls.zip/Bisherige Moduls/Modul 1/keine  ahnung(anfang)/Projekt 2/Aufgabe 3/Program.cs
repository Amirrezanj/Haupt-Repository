﻿namespace Aufgabe_3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int num1 = 4;
            int num2 = 6;
            int multi = num1 * num2;
            Console.WriteLine(multi);
        }
    }
}