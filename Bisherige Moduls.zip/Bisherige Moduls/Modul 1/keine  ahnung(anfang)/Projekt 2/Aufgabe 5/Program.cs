﻿namespace Aufgabe_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 15;
            int b = 4;
            int rest = a % b;
            Console.WriteLine(rest);

        }
    }
}
