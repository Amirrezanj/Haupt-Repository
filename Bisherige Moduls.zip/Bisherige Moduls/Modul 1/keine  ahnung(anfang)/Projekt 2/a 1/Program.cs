﻿namespace a_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hi pl write a number");
            string UserNumberString = Console.ReadLine();
            int UserNumber = int.Parse(UserNumberString);
            Console.WriteLine(UserNumber);

        }
    }
}
