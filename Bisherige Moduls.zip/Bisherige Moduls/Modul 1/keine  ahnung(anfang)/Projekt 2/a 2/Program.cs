﻿namespace a_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("pl write your num");
            string UserInputString = Console.ReadLine();
            float UserInputFloat = float.Parse(UserInputString);
            Console.WriteLine(UserInputFloat);


        }
    }
}
