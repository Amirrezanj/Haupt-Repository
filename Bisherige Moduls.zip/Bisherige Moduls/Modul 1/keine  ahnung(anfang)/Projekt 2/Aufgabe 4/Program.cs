﻿namespace Aufgabe_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1= 12;
            int num2= 3;
            int quo = num1 / num2;
            Console.WriteLine(quo);
        }
    }
}
