﻿namespace Aufgabe_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 3;
            int b = 7;
            int c = 8;
            int sum = a + b + c;
            int dev = (sum / 3);
            Console.WriteLine(dev);

        }
    }
}
