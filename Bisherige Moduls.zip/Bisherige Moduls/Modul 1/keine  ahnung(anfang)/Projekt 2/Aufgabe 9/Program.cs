﻿namespace Aufgabe_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int r = 5;
            double rad = (r * r * 3.14159);
            Console.WriteLine(rad);

        }
    }
}
