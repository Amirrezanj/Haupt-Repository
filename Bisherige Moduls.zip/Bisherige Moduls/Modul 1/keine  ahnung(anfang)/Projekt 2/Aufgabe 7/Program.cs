﻿namespace Aufgabe_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("erste op > "+(5+3)*2);
            Console.WriteLine("2te op > " + (4 + (6 * 2)));
        }
    }
}
