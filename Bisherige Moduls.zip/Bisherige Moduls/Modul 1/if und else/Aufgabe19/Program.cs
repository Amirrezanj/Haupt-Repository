﻿namespace Aufgabe19
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
