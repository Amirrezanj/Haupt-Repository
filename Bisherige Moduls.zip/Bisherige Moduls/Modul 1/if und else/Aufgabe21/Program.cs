﻿namespace Aufgabe21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("das quadrat von " + i + " ist " + (i * i));
            }

        }
    }
}
