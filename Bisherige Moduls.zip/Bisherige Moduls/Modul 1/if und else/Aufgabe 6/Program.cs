﻿namespace Aufgabe_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i =2; i<=20; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}
