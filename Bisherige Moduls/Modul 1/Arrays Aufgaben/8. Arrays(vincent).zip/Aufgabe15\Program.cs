﻿namespace Aufgabe15
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 3 };

            bool ascSort = true;

            for (int i = 0; i < numbers.Length - 1; i++)
            {
                if (numbers[i] > numbers[i + 1])
                {
                    ascSort = false;
                    break;
                }
            }

            if (ascSort)
            {
                Console.WriteLine("Aufsteigend sortiert");
            }
            else
            {
                bool descSort = true;

                for (int i = 0; i < numbers.Length - 1; i++)
                {
                    if (numbers[i] < numbers[i + 1])
                    {
                        descSort = false;
                        break;
                    }
                }

                if (descSort)
                {
                    Console.WriteLine("Absteigend sortiert");
                }
                else
                {
                    Console.WriteLine("Unsortiert");
                }
            }
        }
    }
}