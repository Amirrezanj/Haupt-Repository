﻿namespace Aufgabe11
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] arr1 = { 1, 2, 3, 4, 5 };
            int[] arr2 = { 2, 3, 4, 5, 6 };
            int[] results = new int[5];

            for (int i = 0; i < arr1.Length; i++)
            {
                results[i] = arr1[i] + arr2[i];
                Console.WriteLine(results[i]);
            }
        }
    }
}