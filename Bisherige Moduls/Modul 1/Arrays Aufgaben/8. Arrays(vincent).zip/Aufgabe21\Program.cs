﻿namespace Aufgabe21
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[,] matrix =
            {
                {1, 2, 1 },
                {3, 4, 5 },
                {7, 4, 9 }
            };

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                Console.Write(matrix[i, i] + " ");
            }
        }
    }
}