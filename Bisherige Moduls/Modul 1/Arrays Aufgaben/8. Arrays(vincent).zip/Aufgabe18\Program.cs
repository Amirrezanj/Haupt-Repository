﻿namespace Aufgabe18
{
    internal class Program
    {
        private static void Main()
        {
            int[,] matrix =
            {
                { 3, 2, 3},
                { 1, 5, 2},
                { 3, 5, 7}
            };

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }

                Console.WriteLine();
            }
        }
    }
}