﻿namespace Aufgabe17
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--help" || args[i] == "-h")
                {
                    Console.WriteLine("---------- HELP ----------");
                    Console.WriteLine();
                    Console.WriteLine("---------- Commands ----------");
                    Console.WriteLine();
                    Console.WriteLine("--foreground_color");
                    Console.WriteLine("--background_color");
                    Console.WriteLine();
                    Console.WriteLine("---------- Colors ----------");
                    Console.WriteLine();
                    Console.WriteLine("Green - Red - Blue - Yellow");

                    return;
                }

                if (args[i] == "--foreground_color")
                {
                    switch (args[i + 1])
                    {
                        case "Green":
                            Console.ForegroundColor = ConsoleColor.Green;
                            break;

                        case "Red":
                            Console.ForegroundColor = ConsoleColor.Red;
                            break;

                        case "Blue":
                            Console.ForegroundColor = ConsoleColor.Blue;
                            break;

                        case "Yellow":
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            break;
                    }
                }

                if (args[i] == "--background_color")
                {
                    switch (args[i + 1])
                    {
                        case "Green":
                            Console.BackgroundColor = ConsoleColor.Green;
                            break;

                        case "Red":
                            Console.BackgroundColor = ConsoleColor.Red;
                            break;

                        case "Blue":
                            Console.BackgroundColor = ConsoleColor.Blue;
                            break;

                        case "Yellow":
                            Console.BackgroundColor = ConsoleColor.Yellow;
                            break;
                    }
                }
            }

            Console.WriteLine("Hello World");
        }
    }
}