﻿namespace Aufgabe8
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] arr = { 2, 10, 1, 50, 2151, 301, 52 };

            //int min = arr.Min();
            //int max = arr.Max();

            int min = arr[0];
            int max = arr[0];

            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] < min)
                {
                    min = arr[i];
                }
                else if (arr[i] > max)
                {
                    max = arr[i];
                }
            }

            Console.WriteLine("Min: " + min);
            Console.WriteLine("Max: " + max);
        }
    }
}