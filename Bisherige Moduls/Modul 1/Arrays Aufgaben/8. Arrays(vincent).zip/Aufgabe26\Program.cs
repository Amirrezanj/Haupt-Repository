﻿namespace Aufgabe26
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] arr = { 5, 21, 3, 616, 2, 65, 43, 7 };

            int numberToFind = 65;
            int indexNumberFoundAt = -1;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == numberToFind)
                {
                    indexNumberFoundAt = i;
                    break;
                }
            }

            if (indexNumberFoundAt != -1)
            {
                Console.WriteLine("Die Zahl " + numberToFind + " wurde an der Stelle " + (indexNumberFoundAt + 1) + " gefunden.");
            }
            else
            {
                Console.WriteLine("Die Zahl " + numberToFind + " wurde nicht gefunden.");
            }
        }
    }
}