﻿namespace Aufgabe23
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.Write("Länge für das Jagged Array: ");
            int jaggedLength = int.Parse(Console.ReadLine());

            int[][] jagged = new int[jaggedLength][];

            for (int i = 0; i < jagged.Length; i++)
            {
                Console.Write("Länge für das " + (i + 1) + ". Array im Jagged Array: ");
                int length = int.Parse(Console.ReadLine());

                jagged[i] = new int[length];
            }

            for (int i = 0; i < jagged.Length; i++)
            {
                for (int j = 0; j < jagged[i].Length; j++)
                {
                    Console.Write("Zahl " + (j + 1) + ". von Array " + (i + 1) + ". im Jagged Array: ");
                    int number = int.Parse(Console.ReadLine());

                    jagged[i][j] = number;
                }
            }

            Console.WriteLine("--------------------");

            foreach (int[] array in jagged)
            {
                foreach (int value in array)
                {
                    Console.Write(value + " ");
                }

                Console.WriteLine();
            }
        }
    }
}