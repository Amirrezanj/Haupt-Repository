﻿namespace Aufgabe22
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[,,] matrix =
            {
                {
                    { 1, 2, 3 },
                    { 2, 3, 4 },
                    { 3, 4, 5 }
                },
                {
                    { 2, 3, 4 },
                    { 3, 4, 5 },
                    { 4, 5, 6 }
                },
                {
                    { 3, 4, 5 },
                    { 4, 5, 6 },
                    { 5, 6, 7 }
                }
            };

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    for (int y = 0; y < matrix.GetLength(2); y++)
                    {
                        Console.Write(matrix[y, j, i] + " ");
                    }

                    Console.Write(" ");
                }
                Console.WriteLine();
            }

            //for (int i = 0; i < matrix.GetLength(0); i++)
            //{
            //    for(int j = 0; j < matrix.GetLength(1); j++)
            //    {
            //        for(int y = 0; y < matrix.GetLength(2); y++)
            //        {
            //            Console.Write(matrix[i, j, y] + " ");
            //        }

            //        Console.WriteLine();
            //    }
            //    Console.WriteLine();
            //}
        }
    }
}