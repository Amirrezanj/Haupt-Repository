﻿namespace Aufgabe7
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            int sum = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }

            double avg = (double)sum / arr.Length;

            double variance = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                variance += Math.Pow(arr[i] - avg, 2);
            }

            variance = variance / (arr.Length - 1);

            double std = Math.Sqrt(variance);

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }

            Console.WriteLine("Sum: " + sum);
            Console.WriteLine("Avg: " + avg);
            Console.WriteLine("Variance: " + variance);
            Console.WriteLine("Std: " + std);
        }
    }
}