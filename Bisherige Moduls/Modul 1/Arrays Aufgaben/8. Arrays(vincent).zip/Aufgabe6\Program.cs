﻿namespace Aufgabe6
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            bool[] arr = { true, false, true, true, true, false, false };

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = !arr[i];
            }

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}