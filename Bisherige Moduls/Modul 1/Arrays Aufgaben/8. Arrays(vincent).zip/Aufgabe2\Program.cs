﻿namespace Aufgabe2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            float[] arr = new float[5];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = i;
                Console.WriteLine(arr[i]);
            }
        }
    }
}