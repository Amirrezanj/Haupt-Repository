﻿namespace Aufgabe20
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[,] matrix = {
                { 1, 2, 3 },
                { 2, 4, 6 }
            };

            for (int i = 0; i < matrix.GetLength(1); i++)
            {
                for (int j = 0; j < matrix.GetLength(0); j++)
                {
                    Console.Write(matrix[j, i] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}