﻿namespace Aufgabe14
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] numbers = { 6, 5, 4, 3, 2, 1 };

            bool descSort = true;

            for (int i = 0; i < numbers.Length - 1; i++)
            {
                if (numbers[i] < numbers[i + 1])
                {
                    descSort = false;
                    break;
                }
            }

            if (descSort)
            {
                Console.WriteLine("Absteigend sortiert");
            }
            else
            {
                Console.WriteLine("Nicht absteigend sortiert");
            }
        }
    }
}