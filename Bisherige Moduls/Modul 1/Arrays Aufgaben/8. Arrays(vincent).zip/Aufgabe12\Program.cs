﻿namespace Aufgabe12
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] arr = { 2, 3, 4, 5, 6, 7, 8, 9 };

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 == 0)
                {
                    arr[i] /= 2;
                    //arr[i] = arr[i] / 2;
                }
                else
                {
                    arr[i] *= 2;
                    //arr[i] = arr[i] * 2;
                }

                Console.WriteLine(arr[i]);
            }
        }
    }
}