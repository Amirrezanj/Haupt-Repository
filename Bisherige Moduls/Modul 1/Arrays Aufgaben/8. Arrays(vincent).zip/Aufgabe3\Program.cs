﻿namespace Aufgabe3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] arr = new int[10];

            for (int i = 0; i < arr.Length; i += 2)
            {
                arr[i] = i;
            }

            for (int i = 1; i < arr.Length; i += 2)
            {
                arr[i] = i;
            }

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}