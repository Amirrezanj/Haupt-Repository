﻿namespace Aufgabe4
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            bool textValid = false;
            int length = 0;
            string text = string.Empty;

            do
            {
                Console.Write("Gib die Länge des Arrays ein: ");
                text = Console.ReadLine();
                textValid = int.TryParse(text, out length);
            } while (!textValid);

            int[] arr = new int[length];

            Random random = new Random();
            int sum = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next(1, 101);
                sum += arr[i];
            }

            Console.WriteLine("Die Summe aller Zahlen ist: " + sum);
        }
    }
}