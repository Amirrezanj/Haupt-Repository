﻿namespace Aufgabe16
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] values = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            //if (values.Length == 0)
            //    return;

            int lastValue = values[values.Length - 1];

            for (int i = values.Length - 1; i > 0; i--)
            {
                values[i] = values[i - 1];
            }

            values[0] = lastValue;

            foreach (int value in values)
            {
                Console.WriteLine(value);
            }
        }
    }
}