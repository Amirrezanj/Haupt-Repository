﻿namespace Aufgabe3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int length = CountTextLength("Peter");
            Console.WriteLine(length);
        }

        public static int CountTextLength(string s)
        {
            return s.Length;
        }
    }
}