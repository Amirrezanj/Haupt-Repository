﻿namespace Aufgabe9
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int numberOne = ReadNumberFromUser("Gib die erste Zahl ein");
            int numberTwo = ReadNumberFromUser("Gib die zweite Zahl ein");
            int numberThree = ReadNumberFromUser("Gib die dritte Zahl ein");
            int sum = CalculateSum(numberOne, numberTwo, numberThree);
            int product = CalculateProduct(numberOne, numberTwo, numberThree);
            PrintResult(sum, product);
        }

        public static int ReadNumberFromUser(string message)
        {
            Console.WriteLine(message);

            bool success = int.TryParse(Console.ReadLine(), out int number);

            while (!success)
            {
                Console.WriteLine("Ungültige Eingabe");
                Console.WriteLine(message);
                success = int.TryParse(Console.ReadLine(), out number);
            }

            return number;
        }

        public static int CalculateSum(int numberOne, int numberTwo, int numberThree)
        {
            return numberOne + numberTwo + numberThree;
        }

        public static int CalculateProduct(int numberOne, int numberTwo, int numberThree)
        {
            return numberOne * numberTwo * numberThree;
        }

        public static void PrintResult(int sum, int product)
        {
            Console.WriteLine($"Ergebnis: Summe: {sum} Produkt: {product}");
        }
    }
}