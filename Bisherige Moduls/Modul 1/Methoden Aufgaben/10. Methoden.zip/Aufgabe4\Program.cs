﻿namespace Aufgabe4
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int max = GetMaxNumber(100, 42);
            Console.WriteLine(max);
        }

        public static int GetMaxNumber(int num1, int num2)
        {
            if (num1 > num2)
                return num1;

            return num2;
        }
    }
}