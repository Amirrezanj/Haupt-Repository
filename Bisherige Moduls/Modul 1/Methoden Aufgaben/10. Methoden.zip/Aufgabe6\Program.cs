﻿namespace Aufgabe6
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string name = ReadNameFromUser();
            PrintGreeting(name);
        }

        public static string ReadNameFromUser()
        {
            Console.WriteLine("Wie ist dein Name");
            return Console.ReadLine();
        }

        public static void PrintGreeting(string name)
        {
            Console.WriteLine($"Hallo {name}");
        }
    }
}