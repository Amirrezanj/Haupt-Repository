﻿namespace Aufgabe16
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (TryReadNumber("Gib eine Zahl ein", out int x))
            {
                Console.WriteLine($"Die Zahl ist: {x}");
            }
            else
            {
                Console.WriteLine("Ungültige Eingabe");
            }
        }

        public static bool TryReadNumber(string text, out int x)
        {
            Console.WriteLine(text);
            return int.TryParse(Console.ReadLine(), out x);
        }
    }
}