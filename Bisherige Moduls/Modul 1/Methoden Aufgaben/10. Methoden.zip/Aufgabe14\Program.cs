﻿namespace Aufgabe14
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int numberOfElements = ReadNumberFromUser("Wie lang soll das Array sein?", 1, 100);
            int[] arr = new int[numberOfElements];
            FillArrayWithRandomNumbers(arr);
            int sum = Sum(arr);
            double avg = Avg(arr);
            Console.WriteLine($"Summe: {sum}");
            Console.WriteLine($"Avg: {avg}");
            PrintArray(arr);
        }

        public static int ReadNumberFromUser(string text, int min, int max)
        {
            Console.WriteLine(text);

            bool success = int.TryParse(Console.ReadLine(), out int number);

            while (!success || number < min || number > max)
            {
                Console.WriteLine("Ungültige Eingabe");
                Console.WriteLine(text);
                success = int.TryParse(Console.ReadLine(), out number);
            }

            return number;
        }

        public static void FillArrayWithRandomNumbers(int[] arr)
        {
            Random random = new Random();

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next();
            }
        }

        public static int Sum(int[] arr)
        {
            int sum = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }

            return sum;
        }

        public static double Avg(int[] arr)
        {
            return Sum(arr) / arr.Length;
        }

        public static void PrintArray(int[] arr)
        {
            foreach (int value in arr)
            {
                Console.WriteLine(value);
            }
        }
    }
}