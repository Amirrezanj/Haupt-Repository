﻿namespace Aufgabe1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int result = Sum(5, 10);
            Console.WriteLine(result);
        }

        public static int Sum(int a, int b)
        {
            return a + b;
        }
    }
}