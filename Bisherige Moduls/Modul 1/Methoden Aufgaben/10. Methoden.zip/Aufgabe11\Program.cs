﻿namespace Aufgabe11
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int result1 = Sum(5, 2);
            int result2 = Sum(50, 2, 1);

            Console.WriteLine($"Result1: {result1} Result2: {result2}");
        }

        public static int Sum(int a, int b, int c = 0)
        {
            return a + b + c;
        }
    }
}