﻿namespace Aufgabe12
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int result = Sum(50, 20, 10, 155, 1515, 241);
            Console.WriteLine($"Result: {result}");
        }

        public static int Sum(params int[] arr)
        {
            int sum = 0;

            foreach (int value in arr)
            {
                sum += value;
            }

            return sum;
        }
    }
}