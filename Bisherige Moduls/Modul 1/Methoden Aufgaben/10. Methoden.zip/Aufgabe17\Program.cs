﻿namespace Aufgabe17
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int max = 1000;
            bool[] isPrime = SieveOfEratosthenes(max);

            for (int i = 2; i <= max; i++)
            {
                if (isPrime[i])
                {
                    Console.Write(i + " ");
                }
            }
        }

        private static bool[] SieveOfEratosthenes(int max)
        {
            bool[] isPrime = new bool[max + 1];

            for (int i = 2; i <= max; i++)
            {
                isPrime[i] = true;
            }

            for (int i = 2; i * i <= max; i++)
            {
                if (isPrime[i])
                {
                    for (int j = i * i; j <= max; j += i)
                    {
                        isPrime[j] = false;
                    }
                }
            }

            return isPrime;
        }
    }
}