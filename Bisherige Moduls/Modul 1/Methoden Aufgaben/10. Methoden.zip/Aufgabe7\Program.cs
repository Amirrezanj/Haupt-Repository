﻿namespace Aufgabe7
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string name = ReadNameFromUser();
            int age = ReadAgeFromUser();
            PrintGreeting(name, age);
        }

        public static string ReadNameFromUser()
        {
            Console.WriteLine("Wie ist dein Name");
            return Console.ReadLine();
        }

        public static int ReadAgeFromUser()
        {
            Console.WriteLine("Wie alt bist du?");

            bool success = int.TryParse(Console.ReadLine(), out int age);

            while (!success)
            {
                Console.WriteLine("Ungültige Eingabe.");
                Console.WriteLine("Wie alt bist du?");
                success = int.TryParse(Console.ReadLine(), out age);
            }

            return age;
        }

        public static void PrintGreeting(string name, int age)
        {
            Console.WriteLine($"Hallo {name}, du bist {age} Jahre alt.");
        }
    }
}