﻿namespace Aufgabe13
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int numberOfElements = ReadNumberFromUser("Wie lang soll das Array sein?", 1, 20);
            int[] arr = ReadInArray(numberOfElements);
            int max = FindMax(arr);
            int min = FindMin(arr);
            Console.WriteLine($"Max: {max} Min: {min}");
        }

        public static int ReadNumberFromUser(string text, int min, int max)
        {
            Console.WriteLine(text);

            bool success = int.TryParse(Console.ReadLine(), out int number);

            while (!success || number < min || number > max)
            {
                Console.WriteLine("Ungültige Eingabe");
                Console.WriteLine(text);
                success = int.TryParse(Console.ReadLine(), out number);
            }

            return number;
        }

        public static int[] ReadInArray(int numberOfElements)
        {
            int[] arr = new int[numberOfElements];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = ReadNumberFromUser($"Gib die {i}. Zahl ein", 0, 500);
            }

            return arr;
        }

        public static int FindMin(int[] searchArray)
        {
            int max = searchArray[0];

            for (int i = 1; i < searchArray.Length; i++)
            {
                if (searchArray[i] > max)
                {
                    max = searchArray[i];
                }
            }

            return max;
        }

        public static int FindMax(int[] searchArray)
        {
            int min = searchArray[0];

            for (int i = 1; i < searchArray.Length; i++)
            {
                if (searchArray[i] < min)
                {
                    min = searchArray[i];
                }
            }

            return min;
        }
    }
}