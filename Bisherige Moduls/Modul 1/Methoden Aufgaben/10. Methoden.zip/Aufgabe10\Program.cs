﻿namespace Aufgabe10
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int sum1 = Add(5, 10);
            double sum2 = Add(15.3, 16.2);
            Console.WriteLine($"Sum1: {sum1} Sum2: {sum2}");
        }

        public static int Add(int a, int b)
        {
            return a + b;
        }

        public static double Add(double a, double b)
        {
            return a + b;
        }
    }
}