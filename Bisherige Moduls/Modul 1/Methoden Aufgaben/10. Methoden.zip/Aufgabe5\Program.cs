﻿namespace Aufgabe5
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            bool even = IsEven(25);
            Console.WriteLine(even);
        }

        public static bool IsEven(int number)
        {
            return number % 2 == 0;
        }
    }
}