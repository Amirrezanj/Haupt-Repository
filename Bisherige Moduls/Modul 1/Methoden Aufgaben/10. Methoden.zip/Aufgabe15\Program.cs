﻿namespace Aufgabe15
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int length = ReadNumberFromUser("Geben Sie die Anzahl der Zahlen im Array ein (1 bis 100): ", 1, 100);
            int min = ReadNumberFromUser("Geben Sie das Minimum des Intervalls ein (4 bis 14): ", 1, 15);
            int max = ReadNumberFromUser("Geben Sie das Maximum des Intervalls ein: (4 bis 14)", 1, 15);

            if (max <= min)
            {
                Console.WriteLine("Das Maximum das nicht kleiner sein als das Minimum.");
                return;
            }

            int[] arr = FillArrayWithRandomNumbers(length, min, max);
            int[,] frequency = GetFrequency(arr, min, max);

            PrintFrequency(arr, frequency);
        }

        public static int ReadNumberFromUser(string text, int min, int max)
        {
            Console.Write(text);

            bool success = int.TryParse(Console.ReadLine(), out int number);

            while (!success || number < min || number > max)
            {
                Console.WriteLine("Ungültige Eingabe");
                Console.Write(text);
                success = int.TryParse(Console.ReadLine(), out number);
            }

            return number;
        }

        public static int[] FillArrayWithRandomNumbers(int length, int min, int max)
        {
            int[] arr = new int[length];
            Random random = new Random();

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next(min, max + 1);
            }

            return arr;
        }

        public static int[,] GetFrequency(int[] arr, int min, int max)
        {
            int[,] frequency = new int[2, max - min + 1];

            for (int i = min; i <= max; i++)
            {
                frequency[0, i - min] = i;
            }

            for (int i = 0; i < arr.Length; i++)
            {
                frequency[1, arr[i] - min]++;
            }

            return frequency;
        }

        public static void PrintFrequency(int[] arr, int[,] frequency)
        {
            Console.WriteLine();
            Console.WriteLine("Zufallszahlen im Array");

            foreach (int number in arr)
            {
                Console.Write($"{number} ");
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Häufigkeiten");

            for (int i = 0; i < frequency.GetLength(1); i++)
            {
                Console.WriteLine($"{frequency[0, i]}: {frequency[1, i]}");
            }
        }
    }
}