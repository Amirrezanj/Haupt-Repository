﻿namespace Aufgabe2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            double result = Product(5, 10);
            Console.WriteLine(result);
        }

        public static double Product(double a, double b)
        {
            return a * b;
        }
    }
}