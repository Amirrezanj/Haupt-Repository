﻿namespace Aufgabe20
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // 0 1 1 2 3 4 8 13 21 ....

            int numberOne = 0;
            int numberTwo = 1;
            int result = 0;

            Console.WriteLine(numberOne);
            Console.WriteLine(numberTwo);

            for (int i = 0; i < 300000; i++)
            {
                result = numberOne + numberTwo;
                Console.WriteLine(result);
                numberOne = numberTwo;
                numberTwo = result;
            }
        }
    }
}