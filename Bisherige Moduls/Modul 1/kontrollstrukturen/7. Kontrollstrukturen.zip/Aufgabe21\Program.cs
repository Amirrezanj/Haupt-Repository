﻿namespace Aufgabe21
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Lösung 1
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Das Quadrat von " + i + " ist " + i * i);
            }

            // Lösung 2
            int x = 1;

            while (x <= 10)
            {
                Console.WriteLine("Das Quadrat von " + x + " ist " + x * x);
                x++;
            }
        }
    }
}