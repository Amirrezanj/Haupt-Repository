﻿namespace Aufgabe26
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            bool updateNumberOne = true;
            double numberOne = 0.0;

            while (true)
            {
                if (updateNumberOne)
                {
                    Console.Write("Bitte gib die erste Zahl ein: ");
                    bool validFirstNumber = double.TryParse(Console.ReadLine(), out numberOne);

                    while (!validFirstNumber)
                    {
                        Console.Write("Keine gültige Zahl, bitte gib die erste Zahl erneut ein: ");
                        validFirstNumber = double.TryParse(Console.ReadLine(), out numberOne);
                    }
                }

                Console.Write("Bitte gib den Operator ein (+, -, *, /): ");
                string op = Console.ReadLine();

                while (op != "+" && op != "-" && op != "*" && op != "/")
                {
                    Console.Write("Kein gültiger Operator, bitte gib den Operator erneut ein (+, -, *, /): ");
                    op = Console.ReadLine();
                }

                Console.Write("Bitte gib die zweite Zahl ein: ");
                bool validSecondNumber = double.TryParse(Console.ReadLine(), out double numberTwo);

                while (!validSecondNumber)
                {
                    Console.Write("Keine gültige Zahl, bitte gib die zweite Zahl erneut ein: ");
                    validSecondNumber = double.TryParse(Console.ReadLine(), out numberTwo);
                }

                double result = 0.0;

                switch (op)
                {
                    case "+":
                        result = numberOne + numberTwo;
                        break;

                    case "-":
                        result = numberOne - numberTwo;
                        break;

                    case "*":
                        result = numberOne * numberTwo;
                        break;

                    case "/":
                        result = numberOne / numberTwo;
                        break;
                }

                Console.WriteLine("Das Ergebnis von: " + numberOne + " " + op + " " + numberTwo + " ist: " + result + "\n");

                Console.Write("Möchtest du weiter rechnen? (y/n): ");
                string continueInput = Console.ReadLine();

                while (continueInput != "y" && continueInput != "n")
                {
                    Console.WriteLine("Invalide Eingabe.");
                    Console.Write("Möchtest du weiter rechnen? (y/n): ");
                    continueInput = Console.ReadLine();
                }

                if (continueInput == "n")
                {
                    break;
                }

                Console.Write("Möchtest du mit dem letzten Ergebnis weiter rechnen? (y/n): ");
                string useLastResultInput = Console.ReadLine();

                while (useLastResultInput != "y" && useLastResultInput != "n")
                {
                    Console.WriteLine("Invalide Eingabe.");
                    Console.Write("Möchtest du mit dem letzten Ergebnis weiter rechnen? (y/n): ");
                    useLastResultInput = Console.ReadLine();
                }

                if (useLastResultInput == "y")
                {
                    numberOne = result;
                    updateNumberOne = false;
                }
                else
                {
                    numberOne = 0.0;
                    updateNumberOne = true;
                }
            }
        }
    }
}