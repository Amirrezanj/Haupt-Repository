﻿namespace Aufgabe22
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Random random = new Random();
            int randomNumber = random.Next(1, 101);
            int tryCount = 0;

            do
            {
                Console.WriteLine("Gib die Zahl ein");
                string numberFromUserText = Console.ReadLine();
                bool numberFromUserValid = int.TryParse(numberFromUserText, out int numberFromUser);

                if (!numberFromUserValid)
                {
                    Console.WriteLine("Ungültige Eingabe");
                    continue;
                }

                if (numberFromUser < 0 || numberFromUser > 100)
                {
                    Console.WriteLine("Eingabe auserhalb der Range 0 - 100");
                    continue;
                }

                tryCount++;

                if (numberFromUser < randomNumber)
                {
                    Console.WriteLine("Die gesuchte Zahl ist größer");
                }
                else if (numberFromUser > randomNumber)
                {
                    Console.WriteLine("Die gesuchte Zahl ist kleiner");
                }
                else
                {
                    Console.WriteLine("Glückwunsch, richtige Zahl. Versuche: " + tryCount);
                    break;
                }
            } while (true);
        }
    }
}