﻿namespace Aufgabe8
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine(i * i);
                //Console.WriteLine(Math.Pow(i, 2));
            }
        }
    }
}