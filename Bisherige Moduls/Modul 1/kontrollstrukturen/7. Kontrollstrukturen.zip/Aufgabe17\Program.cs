﻿namespace Aufgabe17
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Random random = new Random();
            int number = random.Next(1, 101);
            int number2 = random.Next(1, 101);

            Console.WriteLine("Addiere die folgenden Zahlen: " + number + " " + number2);

            string inputText = Console.ReadLine();
            bool resultSuccess = int.TryParse(inputText, out int result);

            while (resultSuccess == false || result != number + number2)
            {
                Console.WriteLine("Das Ergebnis ist falsch");
                inputText = Console.ReadLine();
                resultSuccess = int.TryParse(inputText, out result);
            }

            Console.WriteLine("Das Ergebnis ist richtig");
        }
    }
}