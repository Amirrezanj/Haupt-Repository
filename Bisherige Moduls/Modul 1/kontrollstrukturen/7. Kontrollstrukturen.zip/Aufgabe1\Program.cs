﻿namespace Kontrollstrukturen
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.Write("Gib dein Alter ein: ");
            string ageText = Console.ReadLine();

            //int age = int.Parse(ageText);
            bool ageTextValid = int.TryParse(ageText, out int age);

            if (ageTextValid)
            {
                if (age >= 18)
                {
                    Console.WriteLine("Du bist volljährig");
                }
                else
                {
                    Console.WriteLine("Du bist minderjährig");
                }
            }
            else
            {
                Console.WriteLine("Ungültiges Alter");
            }
        }
    }
}