﻿namespace Aufgabe10
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            for (int i = 1; i <= 50; i += 2)
            {
                Console.WriteLine(i);
            }
        }
    }
}