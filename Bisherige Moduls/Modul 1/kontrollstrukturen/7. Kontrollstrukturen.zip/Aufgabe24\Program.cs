﻿namespace Aufgabe24
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.Write("Gib eine Kreditkartennummer ein: ");

            long cardNumber = long.Parse(Console.ReadLine());
            long originalCardNumber = cardNumber;

            int sum = 0;
            bool shouldDouble = false;

            while (cardNumber > 0)
            {
                int digit = (int)(cardNumber % 10);

                if (shouldDouble)
                {
                    digit *= 2;
                    if (digit > 9)
                    {
                        digit -= 9;
                    }
                }

                sum += digit;
                shouldDouble = !shouldDouble;

                cardNumber /= 10;
            }

            if (sum % 10 == 0)
            {
                Console.WriteLine("Die Kreditkartennummer ist gültig.");
            }
            else
            {
                Console.WriteLine("Die Kreditkartennummer ist ungültig.");
            }
        }
    }
}