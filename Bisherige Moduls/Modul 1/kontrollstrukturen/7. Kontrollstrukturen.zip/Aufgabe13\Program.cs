﻿namespace Aufgabe13
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // 1x1 = 1, 2x1 = 2, 3x1 = 3, 4x1 = 4, 5x1 = 5, 6x1 = 6, 7x1 = 7, 8x1 = 8

            int number = 15;

            for (int i = 1; i <= 8; i++)
            {
                Console.Write(i + "x" + number + " = " + i * number);

                if (i <= 7)
                {
                    Console.Write(", ");
                }
            }
        }
    }
}