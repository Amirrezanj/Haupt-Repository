﻿namespace Aufgabe25
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Erste Zahl");
            int firstNumber = int.Parse(Console.ReadLine());

            Console.WriteLine("Zweite Zahl");
            int secondNumber = int.Parse(Console.ReadLine());

            int result = 0;

            while (firstNumber > 0)
            {
                if (firstNumber % 2 != 0)
                {
                    result += secondNumber;
                }

                firstNumber /= 2;
                secondNumber *= 2;
            }

            Console.WriteLine("Das Ergebnis ist: " + result);
        }
    }
}