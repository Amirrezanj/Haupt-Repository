﻿namespace Aufgabe9
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int sum = 0;

            for (int i = 1; i <= 100; i++)
            {
                //sum = sum + i;
                sum += i;
            }

            Console.WriteLine(sum);
        }
    }
}