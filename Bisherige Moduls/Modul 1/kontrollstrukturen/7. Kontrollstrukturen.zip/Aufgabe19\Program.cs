﻿namespace Aufgabe19
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            bool weightValid;
            string weightText;
            float weight;

            do
            {
                Console.WriteLine("Gib dein Gewicht in KG ein");
                weightText = Console.ReadLine();
                weightValid = float.TryParse(weightText, out weight);
            } while (!weightValid || weight < 0);

            bool sizeValid;
            string sizeText;
            float size;

            do
            {
                Console.WriteLine("Gib deine Größe in Meter ein");
                sizeText = Console.ReadLine();
                sizeValid = float.TryParse(sizeText, out size);
            } while (!sizeValid || size < 0);

            float bmi = weight / (size * size);

            if (bmi < 18.5)
            {
                Console.WriteLine("Untergewicht");
            }
            else if (bmi < 25)
            {
                Console.WriteLine("Normalgewicht");
            }
            else if (bmi < 30)
            {
                Console.WriteLine("Übergewicht");
            }
            else
            {
                Console.WriteLine("Adipositas");
            }
        }
    }
}