﻿namespace Aufgabe6
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            for (int i = 2; i < 21; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}