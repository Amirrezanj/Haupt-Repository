﻿namespace Aufgabe3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Gib dein Alter ein");
            string ageText = Console.ReadLine();
            //int age = int.Parse(ageText);
            bool ageTextValid = int.TryParse(ageText, out int age);

            if (ageTextValid)
            {
                if (age < 0)
                {
                    Console.WriteLine("Ungültiges Alter, muss eine positive Zahl sein");
                }
                else if (age >= 0 && age <= 12)
                {
                    Console.WriteLine("Kind");
                }
                else if (age >= 13 && age <= 19)
                {
                    Console.WriteLine("Jugendlicher");
                }
                else if (age >= 20 && age <= 59)
                {
                    Console.WriteLine("Erwachsen");
                }
                else
                {
                    Console.WriteLine("Senior");
                }
            }
            else
            {
                Console.WriteLine("Ungültige Eingabe");
            }
        }
    }
}