﻿namespace Aufgabe12
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            /*
               15 X 1 = 15
               15 X 2 = 30
            */

            int number = 15;

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(number + " X " + i + " = " + number * i);
            }
        }
    }
}