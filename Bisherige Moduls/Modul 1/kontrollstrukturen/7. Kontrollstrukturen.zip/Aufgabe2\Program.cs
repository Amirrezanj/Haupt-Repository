﻿namespace Aufgabe2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.Write("Gib eine Zahl ein: ");
            string numberText = Console.ReadLine();

            //int number = int.Parse(numberText);
            bool numberTextValid = int.TryParse(numberText, out int number);

            if (numberTextValid)
            {
                if (number % 2 == 0)
                {
                    Console.WriteLine("Die Zahl ist gerade");
                }
                else
                {
                    Console.WriteLine("Die Zahl ist ungerade");
                }
            }
            else
            {
                Console.WriteLine("Ungültige Zahl");
            }
        }
    }
}