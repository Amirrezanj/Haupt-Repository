﻿namespace Aufgabe14
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int sum = 0;

            Console.Write("Die ungeraden Zahlen sind: ");

            for (int i = 1; i < 100; i += 2)
            {
                sum += i;
                Console.Write(i + " ");
            }

            Console.WriteLine("\nDie Summe ist: " + sum);
        }
    }
}