﻿namespace Aufgabe18
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Eingabe
            Console.Write("Betrag: ");
            string amountText = Console.ReadLine();
            int amount = int.Parse(amountText);

            Console.Write("Währung: ");
            string targetCurrency = Console.ReadLine();

            double result = 0.0d;

            switch (targetCurrency)
            {
                case "Dollar":
                    result = amount * 1.4;
                    Console.WriteLine(result);
                    break;

                case "Yen":
                    result = amount * 2.4;
                    Console.WriteLine(result);
                    break;

                default:
                    Console.WriteLine("Falsche Eingabe");
                    break;
            }
        }
    }
}