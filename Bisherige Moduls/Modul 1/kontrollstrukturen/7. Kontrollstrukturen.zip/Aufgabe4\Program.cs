﻿namespace Aufgabe4
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Gib die erste Zahl ein");
            string numberOneText = Console.ReadLine();
            bool numberOneValid = int.TryParse(numberOneText, out int numberOne);

            if (numberOneValid)
            {
                Console.WriteLine("Gib die zweite Zahl ein");
                string numberTwoText = Console.ReadLine();
                bool numberTwoValid = int.TryParse(numberTwoText, out int numberTwo);

                if (numberTwoValid)
                {
                    Console.WriteLine("Gib die dritte Zahl ein");
                    string numberThreeText = Console.ReadLine();
                    bool numberThreeValid = int.TryParse(numberThreeText, out int numberThree);

                    if (numberThreeValid)
                    {
                        if (numberOne > numberTwo && numberOne > numberThree)
                        {
                            Console.WriteLine("Die Zahl " + numberOne + " ist die größte");
                        }
                        else if (numberTwo > numberOne && numberTwo > numberThree)
                        {
                            Console.WriteLine("Die Zahl " + numberTwo + " ist die größte");
                        }
                        else
                        {
                            Console.WriteLine("Die Zahl " + numberThree + " ist die größte");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Ungültige dritte Zahl");
                    }
                }
                else
                {
                    Console.WriteLine("Ungültige zweite Zahl");
                }
            }
            else
            {
                Console.WriteLine("Ungültige erste Zahl");
            }
        }
    }
}