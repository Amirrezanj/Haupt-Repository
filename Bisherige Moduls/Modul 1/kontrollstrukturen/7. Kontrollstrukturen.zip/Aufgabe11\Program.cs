﻿namespace Aufgabe11
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Gib eine Zahl ein");
            string numberText = Console.ReadLine();

            bool numberSuccess = int.TryParse(numberText, out int number);

            if (numberSuccess == false)
            {
                Console.WriteLine("Ungültige Eingabe");
                return;
            }

            if (number == 1)
            {
                Console.WriteLine("Du bist keine Primzahl");
                return;
            }

            if (number == 2)
            {
                Console.WriteLine("Du bist eine Primzahl");
                return;
            }

            bool isPrime = true;

            for (int i = 3; i < number; i++)
            {
                if (number % i == 0)
                {
                    isPrime = false;
                    break;
                }
            }

            if (isPrime == true)
            {
                Console.WriteLine("Du bist eine Primzahl");
            }
            else
            {
                Console.WriteLine("Du bist keine Primzahl");
            }
        }
    }
}