﻿namespace Aufgabe7
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            for (int i = 10; i > 0; i--)
            {
                Console.WriteLine(i);
            }
        }
    }
}