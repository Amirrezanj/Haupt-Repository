﻿namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string folderPath = Path.Combine(desktop, "TestFolder");
            string filePath = Path.Combine(folderPath, "example.txt");

            string fileContent = File.ReadAllText(filePath);
            Console.WriteLine(fileContent);

            File.AppendAllText(filePath, "\nThis is a new line.");

            fileContent = File.ReadAllText(filePath);
            Console.WriteLine(fileContent);
        }
    }
}