﻿namespace Aufgabe06
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            PrintRecursive(desktop);
        }

        public static void PrintRecursive(string folderPath, int intendation = 0)
        {
            string intendationString = new string(' ', 2 * intendation);

            Console.WriteLine(intendationString + folderPath);
            string[] files = Directory.GetFiles(folderPath);

            foreach (string file in files)
            {
                Console.WriteLine(intendationString + file);
            }

            string[] dirs = Directory.GetDirectories(folderPath);

            foreach (string dir in dirs)
            {
                PrintRecursive(dir, intendation + 1);
            }
        }
    }
}