﻿namespace Aufgabe04
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string oldFolderPath = Path.Combine(desktop, "TestFolder");
            string newFolderPath = Path.Combine(desktop, "Backup");
            string oldFilePath = Path.Combine(oldFolderPath, "example.txt");
            string newFilePath = Path.Combine(newFolderPath, "example.txt");

            Directory.CreateDirectory(newFolderPath);

            File.Copy(oldFilePath, newFilePath);

            if (File.Exists(newFilePath))
            {
                Console.WriteLine("Datei existiert");
                File.Delete(oldFilePath);
            }
            else
            {
                Console.WriteLine("Datei existiert nicht");
            }
        }
    }
}