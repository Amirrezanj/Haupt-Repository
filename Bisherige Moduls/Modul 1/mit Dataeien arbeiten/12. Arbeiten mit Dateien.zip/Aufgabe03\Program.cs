﻿namespace Aufgabe03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string folderPath = Path.Combine(desktop, "MyFiles");
            string filePath1 = Path.Combine(folderPath, "document1.txt");
            string filePath2 = Path.Combine(folderPath, "document2.txt");
            string filePath3 = Path.Combine(folderPath, "document3.txt");

            string fileName1 = Path.GetFileName(filePath1);
            string fileExtension1 = Path.GetExtension(filePath1);
            Console.WriteLine(fileName1);
            Console.WriteLine(fileExtension1);

            string fileName2 = Path.GetFileName(filePath2);
            string fileExtension2 = Path.GetExtension(filePath2);
            Console.WriteLine(fileName2);
            Console.WriteLine(fileExtension2);

            string fileName3 = Path.GetFileName(filePath3);
            string fileExtension3 = Path.GetExtension(filePath3);
            Console.WriteLine(fileName3);
            Console.WriteLine(fileExtension3);
        }
    }
}