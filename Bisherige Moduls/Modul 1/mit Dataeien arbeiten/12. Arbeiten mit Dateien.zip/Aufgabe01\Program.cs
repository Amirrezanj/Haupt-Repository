﻿namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string folderPath = Path.Combine(desktop, "TestFolder");
            string filePath = Path.Combine(folderPath, "example.txt");

            Directory.CreateDirectory(folderPath);
            File.WriteAllText(filePath, "Hello, World!");

            if (File.Exists(filePath))
            {
                Console.WriteLine("Datei existiert");
            }
            else
            {
                Console.WriteLine("Datei existiert nicht");
            }
        }
    }
}