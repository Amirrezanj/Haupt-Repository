﻿namespace Aufgabe05
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string folderPath = Path.Combine(desktop, "Logs");

            Directory.CreateDirectory(folderPath);

            for (int i = 0; i < 3; i++)
            {
                string filePath = Path.Combine(folderPath, $"log{i}.txt");
                File.WriteAllText(filePath, string.Empty);
            }

            string[] logFiles = Directory.GetFiles(folderPath);

            foreach (string logFile in logFiles)
            {
                Console.WriteLine(logFile);
            }
        }
    }
}

/*
 * Ein Verzeichnis namens "Logs" ist auf dem Desktop zu erstellen, wobei vorher zu prüfen ist,
ob es bereits existiert. Nach dem Erstellen des Verzeichnisses sollen darin mehrere leere
Textdateien angelegt werden, wie z.B. "log1.txt", "log2.txt" und "log3.txt". Schließlich sollen
alle Dateien im "Logs"-Verzeichnis aufgelistet und ihre Namen in der Konsole ausgegeben
werden.
*/