﻿namespace Aufgabe4
{
    internal class Program
    {        
        static void Main(string[] args)
        {
            Console.WriteLine("Gib die Länge des Rechtecks ein: ");
            string lengthText = Console.ReadLine();
            double length = double.Parse(lengthText);

            Console.WriteLine("Gib die Breite des Rechtecks ein: ");
            string widthText = Console.ReadLine();
            double width = double.Parse(widthText);

            double result = width * length;
            Console.WriteLine("Das Rechteck hat eine Fläche von: ");
        }
    }
}
