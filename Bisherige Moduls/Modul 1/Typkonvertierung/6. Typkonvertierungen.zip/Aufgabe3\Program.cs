﻿namespace Aufgabe3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Gib eine dezimal Zahl ein: ");

            string numberText = Console.ReadLine();

            int intNumber = 0;
            bool intNumberSuccess = int.TryParse(numberText, out intNumber);

            float floatNumber = 0.0f;
            bool floatNumberSuccess = float.TryParse(numberText, out floatNumber);

            Console.WriteLine("Int parse hat geklappt: " + intNumberSuccess);
            Console.WriteLine("Float parse hat geklappt: " + floatNumberSuccess);

            Console.WriteLine("Der int ist: " + intNumber + " und der float" +
                "ist: " + floatNumber);
        }
    }
}
