﻿namespace Aufgabe2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Gib eine dezimal Zahl ein: ");
            string numberText = Console.ReadLine();
            float number = float.Parse(numberText);
            Console.WriteLine(number);
        }
    }
}
