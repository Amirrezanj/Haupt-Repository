﻿namespace Aufgabe1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Gib eine ganze Zahl ein: ");
            string numberText = Console.ReadLine();
            int number = int.Parse(numberText);
            Console.WriteLine(number);
        }
    }
}
