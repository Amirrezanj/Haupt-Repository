﻿namespace Aufgabe10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Alter: ");
            string age = Console.ReadLine();

            Console.WriteLine("\"Hallo " + name + "! Du bist " + age + " Jahre alt.\"");
        }
    }
}
