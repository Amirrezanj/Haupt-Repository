﻿namespace Aufgabe3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("„C:\\Docs\\Sprueche.doc“");
        }
    }
}
