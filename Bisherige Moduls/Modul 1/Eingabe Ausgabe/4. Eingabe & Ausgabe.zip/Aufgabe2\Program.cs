﻿namespace Aufgabe2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hallo,\n\tich bin\n\t\tPeter!");
        }
    }
}
