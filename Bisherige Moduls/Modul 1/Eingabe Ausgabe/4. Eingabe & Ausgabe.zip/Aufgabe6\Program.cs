﻿namespace Aufgabe6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wie alt bist du?");
            string age = Console.ReadLine();
            Console.WriteLine("\"Du bist " + age + " Jahre alt!\"");
        }
    }
}
