﻿namespace Aufgabe11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Farbe: ");
            string color = Console.ReadLine();

            Console.WriteLine("\"Hallo " + name + "! Deine Lieblingsfarbe ist " + color + ".\"");
        }
    }
}
