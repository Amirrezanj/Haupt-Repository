﻿namespace Aufgabe8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Bitte gib deine Adresse ein! Straße, Hausnummer, Ort");
            //string address = Console.ReadLine();
            //Console.WriteLine("Adresse:" + address);

            Console.WriteLine("Bitte gib deine Straße ein");
            string street = Console.ReadLine();

            Console.WriteLine("Bitte gib deine Hausnummer ein");
            string housenumber = Console.ReadLine();

            Console.WriteLine("Bitte gib deine Stadt ein");
            string city = Console.ReadLine();

            Console.WriteLine("Deine Adresse lautet: " + street + " " + housenumber + " " + city);
        }
    }
}
