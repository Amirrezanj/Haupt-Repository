﻿namespace Aufgabe4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****** Meine Musiktitel ******\n\t" +
                                    "N = Neuen Eintrag hinzufügen\n\t" +
                                    "L = Eintrag löschen\n\t" +
                                    "F = Titel finden\n\t" +
                                    "A = Alle Einträge anzeigen\n\t" +
                                    "B = Programm beenden");
        }
    }
}