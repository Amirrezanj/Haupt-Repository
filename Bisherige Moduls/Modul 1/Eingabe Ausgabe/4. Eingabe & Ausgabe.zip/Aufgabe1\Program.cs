﻿namespace Aufgabe1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\"Hallo!\"");
        }
    }
}
