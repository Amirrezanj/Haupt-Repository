﻿namespace Aufgabe5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wie heißt du?");
            string name = Console.ReadLine();
            Console.WriteLine("\"Hallo " + name + "!\"");
            //Console.WriteLine("\"Hallo " + Console.ReadLine() + "!\"");
        }
    }
}
