﻿namespace Aufgabe7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gib einen Text ein!");
            string text = Console.ReadLine();
            Console.WriteLine("\"" + text + "\"");
        }
    }
}
