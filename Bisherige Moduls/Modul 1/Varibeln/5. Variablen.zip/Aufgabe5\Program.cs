﻿namespace Aufgabe5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOne = 15;
            int numberTwo = 4;
            int result = numberOne % numberTwo;
            Console.WriteLine(result);
        }
    }
}
