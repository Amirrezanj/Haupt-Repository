﻿namespace Aufgabe3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOne = 4;
            int numberTwo = 6;
            int result = numberOne * numberTwo;
            Console.WriteLine(result);
        }
    }
}
