﻿namespace Aufgabe1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int numberOne = 5;
            int numberTwo = 3;
            int sum = numberOne + numberTwo;
            Console.WriteLine(sum);
        }
    }
}