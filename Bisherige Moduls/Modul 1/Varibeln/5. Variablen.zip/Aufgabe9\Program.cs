﻿namespace Aufgabe9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //double pi = 3.14159;
            int numberOne = 5;
            double result = numberOne * Math.PI * 2;
            Console.WriteLine(result);
        }
    }
}
