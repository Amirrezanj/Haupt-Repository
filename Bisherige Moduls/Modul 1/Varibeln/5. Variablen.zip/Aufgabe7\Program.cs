﻿namespace Aufgabe7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOne = 5;
            int numberTwo = 3;
            int numberThree = 2;
            int result = (numberOne + numberTwo) * numberThree;
            Console.WriteLine(result);

            numberOne = 4;
            numberTwo = 6;
            numberTwo = 2;
            result = numberOne + numberTwo * numberThree;
            Console.WriteLine(result);

            Console.WriteLine((10 - 4) / 2);
        }
    }
}
