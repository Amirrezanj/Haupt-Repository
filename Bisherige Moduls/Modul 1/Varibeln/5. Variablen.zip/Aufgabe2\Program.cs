﻿namespace Aufgabe2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOne = 10;
            int numberTwo = 7;
            int result = numberOne - numberTwo;
            Console.WriteLine(result);
        }
    }
}
