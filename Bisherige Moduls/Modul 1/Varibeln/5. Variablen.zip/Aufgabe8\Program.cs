﻿namespace Aufgabe8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOne = 3;
            int numberTwo = 5;
            int numberThree = 7;
            int result = (numberOne + numberTwo + numberThree) / 3;
            Console.WriteLine(result);
        }
    }
}
