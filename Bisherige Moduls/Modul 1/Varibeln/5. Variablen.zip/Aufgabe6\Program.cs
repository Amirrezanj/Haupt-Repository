﻿namespace Aufgabe6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOne = 9;
            int result = numberOne * numberOne;
            double result2 = Math.Pow(numberOne, 2);
            Console.WriteLine(result);
            Console.WriteLine(result2);
        }
    }
}
