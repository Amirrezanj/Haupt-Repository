﻿namespace Aufgabe4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOne = 12;
            int numberTwo = 3;
            int result = numberOne / numberTwo;
            Console.WriteLine(result);
        }
    }
}
