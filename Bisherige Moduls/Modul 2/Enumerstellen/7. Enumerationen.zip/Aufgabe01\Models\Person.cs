﻿using Aufgabe01.Collections;

namespace Aufgabe01.Models
{
    public class Person
    {
        private string _firstName;
        private string _lastName;
        private Gender _gender;
        private DateTime _birthdate;

        public Person(string firstName, string lastName, Gender gender, DateTime birthdate)
        {
            _firstName = firstName;
            _lastName = lastName;
            _gender = gender;
            _birthdate = birthdate;
        }

        public string GetFirstName()
        {
            return _firstName;
        }

        public void SetFirstName(string firstName)
        {
            if (string.IsNullOrWhiteSpace(firstName))
                return;

            _firstName = firstName;
        }

        public string GetLastName()
        {
            return _lastName;
        }

        public void SetLastName(string lastName)
        {
            if (string.IsNullOrWhiteSpace(lastName))
                return;

            _lastName = lastName;
        }

        public string GetFullName()
        {
            return $"{_firstName} {_lastName}";
        }

        public Gender GetGender()
        {
            return _gender;
        }

        public void SetGender(Gender gender)
        {
            _gender = gender;
        }

        public DateTime GetBirthdate()
        {
            return _birthdate;
        }
    }
}