﻿namespace Aufgabe01.Collections
{
    public enum Gender
    {
        Male,
        Female,
        Diverse
    }
}