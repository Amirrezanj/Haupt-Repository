﻿using Aufgabe01.Collections;
using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Person person1 = new Person("Peter", "Bauer", Gender.Male, DateTime.Parse("15.04.1975"));
            Console.WriteLine(person1.GetFullName());
        }
    }
}