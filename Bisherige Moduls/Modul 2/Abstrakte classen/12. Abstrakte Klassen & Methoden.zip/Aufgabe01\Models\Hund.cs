﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe01.Models
{
    public class Hund : Tier
    {
        public Hund(string name) : base(name)
        {
        }

        public override void Ausgabe()
        {
            Console.WriteLine($"Ich bin ein Hund, mit dem Namen {GetName()}");
        }

        public override void GibtLaute()
        {
            Console.WriteLine("Wuff");
        }
    }
}
