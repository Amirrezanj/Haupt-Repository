﻿namespace Aufgabe01.Models
{
    public abstract class Tier
    {
        private string _name;

        public Tier(string name)
        {
            _name = name;
        }

        public abstract void Ausgabe();

        public abstract void GibtLaute();

        public string GetName()
        {
            return _name;
        }
    }
}
