﻿namespace Aufgabe01.Models
{
    public class Kuh : Tier
    {
        public Kuh(string name) : base(name) 
        {
        }

        public override void Ausgabe()
        {
            Console.WriteLine($"Ich bin eine Kuh, mit dem Namen {GetName()}");
        }

        public override void GibtLaute()
        {
            Console.WriteLine("Muh");
        }
    }
}
