﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe02.Models
{
    public abstract class GeometrieObjekt
    {
        public abstract double BerechneFläche();
        public abstract double BerechneUmfang();

        public void Ausgabe()
        {
            Console.WriteLine($"Fläche {BerechneFläche()} Umfang {BerechneUmfang()}");
        }
    }
}
