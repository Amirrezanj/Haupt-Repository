﻿namespace Aufgabe01.Models
{
    public class Katze : Tier
    {
        public Katze(string name) : base(name)
        {
        }

        public override void Ausgabe()
        {
            Console.WriteLine($"Ich bin eine Katze, mit dem Namen {GetName()}");
        }

        public override void GibtLaute()
        {
            Console.WriteLine("Miau");
        }
    }
}
