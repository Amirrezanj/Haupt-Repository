﻿namespace Aufgabe02.Models
{
    public class Kreis : GeometrieObjekt
    {
        private double _radius;

        public Kreis(double radius)
        {
            _radius = radius;
        }

        public override double BerechneFläche()
        {
            return Math.PI * Math.Pow(_radius, 2);
        }

        public override double BerechneUmfang()
        {
            return 2 * Math.PI * _radius;
        }
    }
}
