﻿namespace Aufgabe02.Models
{
    public class Quadrat : GeometrieObjekt
    {
        private double _seitenlänge;

        public Quadrat(double seitenlänge)
        {
            _seitenlänge = seitenlänge;
        }

        public override double BerechneFläche()
        {
            return Math.Pow(_seitenlänge, 2);
        }

        public override double BerechneUmfang()
        {
            return _seitenlänge * 4;
        }
    }
}
