﻿namespace Aufgabe02
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
