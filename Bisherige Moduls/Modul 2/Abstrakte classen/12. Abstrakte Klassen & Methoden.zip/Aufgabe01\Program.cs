﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hund hund = new Hund("Bello");
            hund.Ausgabe();
            hund.GibtLaute();

            Katze katze = new Katze("Trixi");
            katze.Ausgabe();
            katze.GibtLaute();

            Kuh kuh = new Kuh("Beate");
            kuh.Ausgabe();
            kuh.GibtLaute();
        }
    }
}
