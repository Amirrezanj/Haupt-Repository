﻿namespace Aufgabe02.Models;

public class Zeitung : NachrichtenQuelle
{
}
