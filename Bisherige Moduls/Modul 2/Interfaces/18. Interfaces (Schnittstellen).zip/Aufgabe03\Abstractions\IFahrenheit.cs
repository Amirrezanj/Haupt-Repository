﻿namespace Aufgabe03.Abstractions
{
    public interface IFahrenheit
    {
        double Fahrenheit { get; set; }

        void Ausgabe();
    }
}
