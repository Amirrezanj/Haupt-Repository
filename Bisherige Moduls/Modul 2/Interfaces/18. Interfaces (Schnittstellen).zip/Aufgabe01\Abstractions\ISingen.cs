﻿namespace Aufgabe01.Abstractions
{
    public interface ISingen
    {
        void Singen();
    }
}
