﻿using Aufgabe03.Abstractions;

namespace Aufgabe03.Models
{
    public class Temperatur : ICelcius, IKelvin, IFahrenheit
    {
        public double Celcius { get; set; }

        public double Kelvin {
            get => Celcius + 273.15;
            set => Celcius = value - 273.15;
        }

        public double Fahrenheit {
            get => ((Celcius * 9) / 5) + 32;
            set => Celcius = (value - 32) * (5 / 9);
        }

        void ICelcius.Ausgabe()
        {
            Console.WriteLine($"Celcius: {Celcius}");
        }

        void IKelvin.Ausgabe()
        {
            Console.WriteLine($"Kelvin: {Kelvin}");
        }

        void IFahrenheit.Ausgabe()
        {
            Console.WriteLine($"Fahrenheit: {Fahrenheit}");
        }
    }
}
