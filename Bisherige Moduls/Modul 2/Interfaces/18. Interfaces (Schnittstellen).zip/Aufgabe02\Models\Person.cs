﻿using Aufgabe02.Abstractions;

namespace Aufgabe02.Models;

public class Person : INachrichtenEmpfänger
{
    public string Name { get; }

    public Person(string name)
    {
        Name = name;
    }

    public void EmpfangeNachricht(string nachricht)
    {
        Console.WriteLine($"{Name} hat folgende Nachricht erhalten: {nachricht}");
    }
}
