﻿using Aufgabe01.Abstractions;

namespace Aufgabe01.Models
{
    public class Fledermaus : IFliegen
    {
        public void Fliegen()
        {
            Console.WriteLine("FlatterFlatter");
        }
    }
}
