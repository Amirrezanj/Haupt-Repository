﻿using Aufgabe04.Abstractions;

namespace Aufgabe04.Models;

public class Büffelhirte : IBeobachter
{
    public void WasserstandsÄnderung(double wasserstand)
    {
        if (wasserstand <= 0.3) {
            Console.WriteLine("Tiere zusätzlich tränken");
        } else if (wasserstand >= 5 && wasserstand <= 7) {
            Console.WriteLine("Tiere müssen in den Stall gebracht werden");
        } else if (wasserstand >= 7) {
            Console.WriteLine("Tiere müssen evakuiert werden");
        } else {
            Console.WriteLine("Alles in Ordnung");
        }
    }
}
