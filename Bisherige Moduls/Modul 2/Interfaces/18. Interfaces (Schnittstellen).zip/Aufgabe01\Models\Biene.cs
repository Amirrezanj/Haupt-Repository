﻿using Aufgabe01.Abstractions;

namespace Aufgabe01.Models
{
    public class Biene : IFliegen
    {
        public void Fliegen()
        {
            Console.WriteLine("Summsumm");
        }
    }
}
