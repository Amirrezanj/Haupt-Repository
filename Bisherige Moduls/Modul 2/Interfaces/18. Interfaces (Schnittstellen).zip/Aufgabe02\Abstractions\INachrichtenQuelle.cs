﻿namespace Aufgabe02.Abstractions;

public interface INachrichtenQuelle
{
    void Anmelden(INachrichtenEmpfänger empfänger);

    void Abmelden(INachrichtenEmpfänger empfänger);

    void SendeNachricht(string nachricht);
}
