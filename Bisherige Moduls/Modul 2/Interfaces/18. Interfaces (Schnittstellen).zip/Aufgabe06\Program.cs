﻿using Aufgabe06.Models;

namespace Aufgabe06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MoveableRect movableRect = new MoveableRect(1, 10, 6, 5, 3, 2);

            Console.WriteLine(movableRect.ToString());

            for (int i = 0; i < 3; i++)
            {
                movableRect.MoveRight();
                Console.WriteLine(movableRect.ToString());
            }

            for (int i = 0; i < 3; i++)
            {
                movableRect.MoveUp();
                Console.WriteLine(movableRect.ToString());
            }

            for (int i = 0; i < 2; i++)
            {
                movableRect.MoveLeft();
                Console.WriteLine(movableRect.ToString());
            }
        }
    }
}
