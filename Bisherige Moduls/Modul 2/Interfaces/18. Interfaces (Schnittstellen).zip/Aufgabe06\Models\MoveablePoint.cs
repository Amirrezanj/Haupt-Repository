﻿using Aufgabe06.Abstractions;

namespace Aufgabe06.Models;

public class MoveablePoint : IMoveable
{
    public double X { get; private set; }
    public double Y { get; private set; }
    public double XSpeed { get; }
    public double YSpeed { get; }

    public MoveablePoint(double x, double y, double xSpeed, double ySpeed)
    {
        X = x;
        Y = y;
        XSpeed = xSpeed;
        YSpeed = ySpeed;
    }

    public void MoveUp()
    {
        Y += YSpeed;
    }

    public void MoveDown()
    {
        Y -= YSpeed;
    }

    public void MoveLeft()
    {
        X -= XSpeed;
    }

    public void MoveRight()
    {
        X += XSpeed;
    }

    public override string ToString()
    {
        return $"({X}, {Y}, {XSpeed}, {YSpeed})";
    }
}
