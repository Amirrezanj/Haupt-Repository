﻿using Aufgabe04.Abstractions;

namespace Aufgabe04.Models;

public class Strassenwacht : IBeobachter
{
    private bool _gesperrt = false;

    public void WasserstandsÄnderung(double wasserstand)
    {
        if (wasserstand >= 9 || _gesperrt) {
            Console.WriteLine("Straße ist gesperrt, bis sie wieder Freigegeben wurde");
            _gesperrt = true;
        }
    }
}
