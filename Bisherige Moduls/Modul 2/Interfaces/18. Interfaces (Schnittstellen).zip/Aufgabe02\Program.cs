﻿using Aufgabe02.Models;

namespace Aufgabe02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Peter");
            Person person2 = new Person("Marie");

            Vermittler vermittler = new Vermittler();

            vermittler.Anmelden(person1);
            vermittler.Anmelden(person2);

            Radio radio = new Radio(108.4);
            TV tv = new TV();
            Website website = new Website();
            Zeitung zeitung = new Zeitung();

            radio.Anmelden(vermittler);
            tv.Anmelden(vermittler);
            website.Anmelden(vermittler);
            zeitung.Anmelden(vermittler);

            radio.SendeNachricht("Hallo Radio");
            tv.SendeNachricht("Hallo TV");
            website.SendeNachricht("Hallo Website");
            zeitung.SendeNachricht("Hallo Zeitung");
        }
    }
}
