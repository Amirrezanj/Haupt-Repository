﻿using Aufgabe01.Abstractions;

namespace Aufgabe01.Models
{
    public class Singvogel : IFliegen, ISingen
    {
        public void Fliegen()
        {
            Console.WriteLine("FlapFlap");
        }

        public void Singen()
        {
            Console.WriteLine("ZwitscherZwitscher");
        }
    }
}
