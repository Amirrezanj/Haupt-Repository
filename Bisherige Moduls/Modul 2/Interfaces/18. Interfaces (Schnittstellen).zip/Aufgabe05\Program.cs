﻿using Aufgabe05.Models;

namespace Aufgabe05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Schwert schwert = new Schwert();
            Shuriken shuriken = new Shuriken();

            Ninja ninja1 = new Ninja(schwert);
            Ninja ninja2 = new Ninja(shuriken);

            ninja1.Angreifen("den Bösewicht");
            ninja2.Angreifen("Den Gegner");
        }
    }
}
