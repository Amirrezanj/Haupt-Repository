﻿namespace Aufgabe01.Abstractions
{
    public interface IFliegen
    {
        void Fliegen();
    }
}
