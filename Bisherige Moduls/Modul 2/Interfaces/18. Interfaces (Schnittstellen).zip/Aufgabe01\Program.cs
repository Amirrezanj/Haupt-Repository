﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Biene biene = new Biene();
            Fledermaus fledermaus = new Fledermaus();
            Singvogel singvogel = new Singvogel();

            biene.Fliegen();
            fledermaus.Fliegen();
            singvogel.Fliegen();
            singvogel.Singen();

        }
    }
}
