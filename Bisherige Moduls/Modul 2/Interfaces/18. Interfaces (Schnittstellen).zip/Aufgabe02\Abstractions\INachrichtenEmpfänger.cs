﻿namespace Aufgabe02.Abstractions;

public interface INachrichtenEmpfänger
{
    void EmpfangeNachricht(string nachricht);
}
