﻿namespace Aufgabe02.Models;

public class Radio : NachrichtenQuelle
{
    public double Frequenz { get; }

    public Radio(double frequenz)
    {
        Frequenz = frequenz;
    }

    public override void SendeNachricht(string nachricht)
    {
        base.SendeNachricht($"Ich bin ein Radio {nachricht}");
    }
}
