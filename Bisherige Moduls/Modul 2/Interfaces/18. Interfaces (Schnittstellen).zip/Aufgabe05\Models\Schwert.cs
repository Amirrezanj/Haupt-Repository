﻿using Aufgabe05.Abstraction;

namespace Aufgabe05.Models;

public class Schwert : IWaffe
{
    public void GegnerTreffen(string gegner)
    {
        Console.WriteLine($"Zertrennte {gegner} genau in der Mitte");
    }
}
