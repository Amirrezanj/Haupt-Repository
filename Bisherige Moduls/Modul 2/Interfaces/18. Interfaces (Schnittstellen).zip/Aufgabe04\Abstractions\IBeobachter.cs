﻿namespace Aufgabe04.Abstractions;

public interface IBeobachter
{
    void WasserstandsÄnderung(double wasserstand);
}
