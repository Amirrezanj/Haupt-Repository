﻿using Aufgabe04.Abstractions;

namespace Aufgabe04.Models;

public class Fluss
{
    private static Random _random = new Random();

    private readonly List<IBeobachter> _beobachter = new List<IBeobachter>();

    public void BeobachterHinzufügen(IBeobachter beobachter)
    {
        _beobachter.Add(beobachter);
    }

    public void WasserpegelÄndern()
    {
        double wasserstand = _random.Next(30, 1000) / 100.0d;

        foreach (IBeobachter beobachter in _beobachter) {
            beobachter.WasserstandsÄnderung(wasserstand);
        }
    }
}
