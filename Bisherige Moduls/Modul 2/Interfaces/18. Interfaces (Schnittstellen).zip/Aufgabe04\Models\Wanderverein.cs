﻿using Aufgabe04.Abstractions;

namespace Aufgabe04.Models;

public class Wanderverein : IBeobachter
{
    public void WasserstandsÄnderung(double wasserstand)
    {
        if (wasserstand <= 1) {
            Console.WriteLine("Fluss kann durchquert werden");
        } else if (wasserstand >= 6) {
            Console.WriteLine("Wanderweg überschwemmt");
        }
    }
}
