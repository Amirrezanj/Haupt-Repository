﻿namespace Aufgabe06.Abstractions;

public interface IMoveable
{
    void MoveUp();

    void MoveDown();

    void MoveLeft();

    void MoveRight();
}
