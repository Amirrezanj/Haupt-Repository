﻿namespace Aufgabe02.Models;

public class TV : NachrichtenQuelle
{
}
