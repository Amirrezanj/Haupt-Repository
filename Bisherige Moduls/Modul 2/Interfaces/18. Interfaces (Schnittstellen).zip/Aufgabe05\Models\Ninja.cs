﻿using Aufgabe05.Abstraction;

namespace Aufgabe05.Models;

public class Ninja
{
    private IWaffe _waffe;

    public Ninja(IWaffe waffe)
    {
        _waffe = waffe;
    }

    public void Angreifen(string gegner)
    {
        _waffe.GegnerTreffen(gegner);
    }
}
