﻿using Aufgabe02.Abstractions;

namespace Aufgabe02.Models;

public abstract class NachrichtenQuelle : INachrichtenQuelle
{
    private readonly List<INachrichtenEmpfänger> _empfängerListe = new List<INachrichtenEmpfänger>();

    public void Anmelden(INachrichtenEmpfänger empfänger)
    {
        _empfängerListe.Add(empfänger);
    }

    public void Abmelden(INachrichtenEmpfänger empfänger)
    {
        _empfängerListe.Remove(empfänger);
    }

    public virtual void SendeNachricht(string nachricht)
    {
        foreach (INachrichtenEmpfänger empfänger in _empfängerListe) {
            empfänger.EmpfangeNachricht(nachricht);
        }
    }
}
