﻿namespace Aufgabe02.Models;

public class Website : NachrichtenQuelle
{
}
