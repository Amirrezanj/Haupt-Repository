﻿using Aufgabe03.Abstractions;
using Aufgabe03.Models;

namespace Aufgabe02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Temperatur temperatur = new Temperatur();
            temperatur.Celcius = 32.5;

            ICelcius celciusTemp = temperatur;
            celciusTemp.Ausgabe();

            IKelvin kelvinTemp = temperatur;
            kelvinTemp.Ausgabe();

            IFahrenheit fahrenheitTemp = temperatur;
            fahrenheitTemp.Ausgabe();
        }
    }
}
