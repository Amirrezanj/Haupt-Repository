﻿using Aufgabe05.Abstraction;

namespace Aufgabe05.Models;

public class Shuriken : IWaffe
{
    public void GegnerTreffen(string gegner)
    {
        Console.WriteLine($"Traf {gegner} mit voller Wucht");
    }
}
