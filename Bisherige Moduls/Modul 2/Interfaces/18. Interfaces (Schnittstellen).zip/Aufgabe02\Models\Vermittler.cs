﻿using Aufgabe02.Abstractions;

namespace Aufgabe02.Models;

public class Vermittler : NachrichtenQuelle, INachrichtenEmpfänger
{
    private List<INachrichtenEmpfänger> _empfänger = new List<INachrichtenEmpfänger>();

    public void EmpfangeNachricht(string nachricht)
    {
        SendeNachricht(nachricht);
    }
}
