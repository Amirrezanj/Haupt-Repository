﻿using Aufgabe04.Models;

namespace Aufgabe04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Fluss fluss = new Fluss();

            Büffelhirte büffelhirte = new Büffelhirte();
            Strassenwacht strassenwacht = new Strassenwacht();
            Wanderverein wanderverein = new Wanderverein();

            fluss.BeobachterHinzufügen(büffelhirte);
            fluss.BeobachterHinzufügen(strassenwacht);
            fluss.BeobachterHinzufügen(wanderverein);

            for (int i = 0; i < 10; i++)
            {
                fluss.WasserpegelÄndern();
            }
        }
    }
}
