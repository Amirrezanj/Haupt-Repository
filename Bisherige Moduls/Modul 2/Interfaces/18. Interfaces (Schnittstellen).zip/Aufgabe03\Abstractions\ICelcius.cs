﻿namespace Aufgabe03.Abstractions
{
    public interface ICelcius : IAusgabe
    {
        double Celcius { get; set; }

        void Ausgabe();
    }
}
