﻿using Aufgabe06.Abstractions;

namespace Aufgabe06.Models;

public class MoveableRect : IMoveable
{
    public MoveablePoint UpperLeftCorner { get; }
    public MoveablePoint LowerRightCorner { get; }

    public double XSpeed { get; }
    public double YSpeed { get; }

    public MoveableRect(double upperLeftX, double upperLeftY, double lowerRightX, double lowerRightY, double xSpeed, double ySpeed)
    {
        UpperLeftCorner = new MoveablePoint(upperLeftX, upperLeftY, xSpeed, ySpeed);
        LowerRightCorner = new MoveablePoint(lowerRightX, lowerRightY, xSpeed, ySpeed);
        XSpeed = xSpeed;
        YSpeed = ySpeed;
    }

    public void MoveUp()
    {
        UpperLeftCorner.MoveUp();
        LowerRightCorner.MoveUp();
    }

    public void MoveDown()
    {
        UpperLeftCorner.MoveDown();
        LowerRightCorner.MoveDown();
    }

    public void MoveLeft()
    {
        UpperLeftCorner.MoveLeft();
        LowerRightCorner.MoveLeft();
    }

    public void MoveRight()
    {
        UpperLeftCorner.MoveRight();
        LowerRightCorner.MoveRight();
    }

    public override string ToString()
    {
        return $"{UpperLeftCorner} {LowerRightCorner}";
    }
}
