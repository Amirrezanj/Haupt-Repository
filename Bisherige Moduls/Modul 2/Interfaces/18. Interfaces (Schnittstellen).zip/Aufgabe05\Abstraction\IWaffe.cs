﻿namespace Aufgabe05.Abstraction;

public interface IWaffe
{
    void GegnerTreffen(string gegner);
}
