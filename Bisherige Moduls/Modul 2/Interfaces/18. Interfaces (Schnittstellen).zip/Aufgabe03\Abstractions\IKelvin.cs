﻿namespace Aufgabe03.Abstractions
{
    public interface IKelvin
    {
        double Kelvin { get; set; }

        void Ausgabe();
    }
}
