﻿namespace Aufgabe01
{
    public class PiggyBank
    {
        private int _1CentCount;
        private int _10CentCount;
        private int _50CentCount;
        private int _100CentCount;
        private bool _isBroken;
        private int _maxCoins;
        private int _currentCoins;

        public PiggyBank(int maxCoins)
        {
            _maxCoins = maxCoins;
        }

        public int Add1Cent(int coins)
        {
            return AddCent(ref _1CentCount, coins);
        }

        public int Add10Cent(int coins)
        {
            return AddCent(ref _10CentCount, coins);
        }

        public int Add50Cent(int coins)
        {
            return AddCent(ref _50CentCount, coins);
        }

        public int Add100Cent(int coins)
        {
            return AddCent(ref _100CentCount, coins);
        }

        public void Shake()
        {
            if(_currentCoins == 0)
            {
                Console.WriteLine("Leer");
            } else if(_currentCoins <= _maxCoins / 3)
            {
                Console.WriteLine("Etwa ein drittel");
            } else if(_currentCoins <= _maxCoins / 2)
            {
                Console.WriteLine("Etwa die hälfte");
            } else if(_currentCoins <= (_maxCoins / 3) * 2)
            {
                Console.WriteLine("Etwa zwei drittel");
            } else
            {
                Console.WriteLine("Voll");
            }
        }

        public bool IsBroken()
        {
            return _isBroken;
        }

        public int BreakInto()
        {
            int temp = _1CentCount + (_10CentCount * 10) + (_50CentCount * 50) + (_100CentCount * 100);
            _1CentCount = _10CentCount = _50CentCount = _100CentCount = _currentCoins = 0;
            _isBroken = true;
            return temp;
        }

        // BONUS: Hat nichts mit der eigentlichen Aufgabe zu tun.
        // Zeigt nur die Verwendung von ref zur Vermeidung von sich wiederholendem code.
        private int AddCent(ref int targetCoinCounter, int coins)
        {
            if (_currentCoins + coins <= _maxCoins)
            {
                targetCoinCounter += coins;
                _currentCoins += coins;
                return 0;
            }
            else
            {
                int temp = _currentCoins + coins - _maxCoins;
                targetCoinCounter += coins - temp;
                _currentCoins = _maxCoins;
                return temp;
            }
        }
    }
}
