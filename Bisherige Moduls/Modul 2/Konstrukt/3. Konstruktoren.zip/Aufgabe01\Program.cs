﻿namespace Aufgabe01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PiggyBank piggyBank = new PiggyBank(10);
            piggyBank.Shake();

            Console.WriteLine(piggyBank.Add1Cent(1));
            piggyBank.Shake();

            Console.WriteLine(piggyBank.Add10Cent(1));
            piggyBank.Shake();

            Console.WriteLine(piggyBank.Add50Cent(1));
            piggyBank.Shake();

            Console.WriteLine(piggyBank.Add100Cent(1));
            piggyBank.Shake();

            Console.WriteLine(piggyBank.Add10Cent(10));
            piggyBank.Shake();

            Console.WriteLine(piggyBank.IsBroken());
            Console.WriteLine(piggyBank.BreakInto());
        }
    }
}
