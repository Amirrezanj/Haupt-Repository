﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student("Peter", 45)
            {
                Note = 5
            };

            Console.WriteLine(student);
        }
    }
}
