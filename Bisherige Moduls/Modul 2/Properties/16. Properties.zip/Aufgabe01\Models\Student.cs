﻿namespace Aufgabe01.Models
{
    public class Student
    {
        private string _name = string.Empty;
        private int _alter;

        public string Name
        {
            get => _name;
            private set
            {
                if(!string.IsNullOrWhiteSpace(value) && value.Length > 2 && value.Length < 20)
                    _name = value;
            }
        }

        public int Alter
        {
            get => _alter;
            set
            {
                if(value >= 1 && value <= 99)
                    _alter = value;
            }
        }

        public int Note { get; set; }

        public Student(string name, int alter)
        {
            Name = name;
            Alter = alter;
        }

        public override string ToString()
        {
            return $"{Name} {Alter} {Note}";
        }
    }
}
