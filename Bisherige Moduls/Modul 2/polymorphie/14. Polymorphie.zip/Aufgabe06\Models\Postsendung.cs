﻿namespace Aufgabe06.Models
{
    public abstract class Postsendung
    {
        private int _id;

        private Adresse _absender;

        private Adresse _empfänger;

        private bool _zugestellt;

        public Postsendung(int id, Adresse absender, Adresse empfänger)
        {
            _id = id;
            _absender = absender;
            _empfänger = empfänger;
        }

        public int GetId()
        {
            return _id;
        }

        public Adresse GetAbsender()
        {
            return _absender;
        }

        public void SetAbsender(Adresse adresse)
        {
            _absender = adresse;
        }

        public Adresse GetEmpfänger()
        {
            return _empfänger;
        }

        public void SetEmpfänger(Adresse adresse)
        {
            _empfänger = adresse;
        }

        public bool GetZugestellt()
        {
            return _zugestellt;
        }

        public void SetZugestellt(bool zugestellt)
        {
            _zugestellt = zugestellt;
        }

        public override string ToString()
        {
            return $"Id: {_id} \nAbsender: {_absender} \nEmpfänger: {_empfänger} \nZugestellt: {_zugestellt}";
        }
    }
}