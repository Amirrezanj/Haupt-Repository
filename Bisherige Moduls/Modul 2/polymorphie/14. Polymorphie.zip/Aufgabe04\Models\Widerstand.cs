﻿namespace Aufgabe04.Models
{
    public class Widerstand
    {
        protected string _name = string.Empty;
        protected double _wert;

        protected Widerstand()
        {
        }

        public Widerstand(string name, double wert)
        {
            _name = name;
            _wert = wert;
        }

        public string GetName()
        {
            return _name;
        }

        public double GetWiderstandswert()
        {
            return _wert;
        }

        public override string ToString()
        {
            return $"Name {_name} Wert {_wert}";
        }
    }
}
