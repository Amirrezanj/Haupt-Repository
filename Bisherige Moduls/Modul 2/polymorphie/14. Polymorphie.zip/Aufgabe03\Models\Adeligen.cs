﻿namespace Aufgabe03.Models
{
    public class Adeligen : Einwohner
    {
        public Adeligen(string name) : base(name)
        {
        }

        public override int BerechneSteuer()
        {
            int steuer = base.BerechneSteuer();

            if (steuer < 20)
                return 20;

            return steuer;
        }
    }
}
