﻿namespace Aufgabe01.Models
{
    public class Auto
    {
        private string _kennzeichen;
        private int _sitzplätze;
        private double _kilometer;
        private bool _antenneAusgefahren;

        public Auto() : this("DO OM 3", 5)
        {
        }

        public Auto(string kennzeichen, int sitzplätze)
        {
            _kennzeichen = kennzeichen;
            _sitzplätze = sitzplätze;
            _kilometer = 0;
            _antenneAusgefahren = true;
        }

        public string GetKennzeichen()
        {
            return _kennzeichen;
        }

        public double GetKilometerstand()
        {
            return _kilometer;
        }

        public int GetSitzplätze()
        {
            return _sitzplätze;
        }

        public void Fahren(double gefahreneKilometer)
        {
            Console.WriteLine($"Das Auto fährt {gefahreneKilometer} KM");
            _kilometer += gefahreneKilometer;
        }

        public void AntenneEinfahren()
        {
            Console.WriteLine($"Die Antenne wurde eingefahren");
            _antenneAusgefahren = false;
        }

        public void AntenneAusfahren()
        {
            Console.WriteLine("Die Antenne wurde ausgefahren");
            _antenneAusgefahren = true;
        }

        public bool IstAntenneDrausen()
        {
            return _antenneAusgefahren;
        }

        public virtual void VorDemWaschen()
        {
            AntenneEinfahren();
        }

        public void Waschen()
        {
            VorDemWaschen();
            Console.WriteLine("Wagen wird gewaschen");
        }

        public override string ToString()
        {
            if(_antenneAusgefahren)
            {
                return $"Das Fahrzeug mit dem Kennzeichen {_kennzeichen} " +
                    $"hat {_sitzplätze} und ist {_kilometer} KM gefahren. " +
                    $"Die Antenne ist ausgefahren.";
            } else
            {
                return $"Das Fahrzeug mit dem Kennzeichen {_kennzeichen} " +
                    $"hat {_sitzplätze} und ist {_kilometer} KM gefahren. " +
                    $"Die Antenne ist eingefahren.";
            }
        }
    }
}
