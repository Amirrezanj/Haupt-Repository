﻿namespace Aufgabe01.Models
{
    public class Pickup : Auto
    {
        private int _ladeflächeMax;
        private int _ladung;

        public Pickup(string kennzeichen, int ladeflächeMax) : base(kennzeichen, 2)
        {
            _ladeflächeMax = ladeflächeMax;
        }

        public bool Beladen(int anzahl)
        {
            if(_ladung + anzahl <= _ladeflächeMax)
            {
                _ladung += anzahl;
                Console.WriteLine($"{anzahl} wurden hinzufügt. Neue Beladung {_ladung}");
                return true;
            }

            return false;
        }

        public bool Entladen(int anzahl)
        {
            if (_ladung>= anzahl)
            {
                _ladung -= anzahl;
                Console.WriteLine($"{anzahl} wurden entfernt. Neue Beladung {_ladung}");
                return true;
            }

            return false;
        }

        public int GetLadung()
        {
            return _ladung;
        }

        public override string ToString()
        {
            return $"{base.ToString()} Ladung: {_ladung} LadeflächeMax: {_ladeflächeMax}";
        }

        public override void VorDemWaschen()
        {
            int temp = _ladung;
            Entladen(_ladung);
            base.VorDemWaschen();
            Beladen(temp);
        }
    }
}
