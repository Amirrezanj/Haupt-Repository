﻿namespace Aufgabe05.Models
{
    public abstract class Mitglied
    {
        private static int _nächsteMitgliedsNummer;

        private string _name;
        private int _mitgliedsNummer;

        public Mitglied(string name)
        {
            _name = name;
            _mitgliedsNummer = _nächsteMitgliedsNummer++;
        }

        public abstract double GetEinnahmen();

        public abstract double GetAusgaben();

        public double GetÜberschuss()
        {
            return GetEinnahmen() - GetAusgaben();
        }

        public override string ToString()
        {
           return $"{_mitgliedsNummer} {_name}";
        }

        public string GetName()
        {
            return _name;
        }

        public int GetMitgliedsNummer()
        {
            return _mitgliedsNummer;
        }
    }
}