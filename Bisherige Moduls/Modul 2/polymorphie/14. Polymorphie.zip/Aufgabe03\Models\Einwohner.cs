﻿namespace Aufgabe03.Models
{
    public abstract class Einwohner
    {
        private const int _steuersatz = 10;

        private string _name;
        private double _einkommen;

        public Einwohner(string name)
        {
            _name = name;
        }

        public void SetEinkommen(double einkommen)
        {
            _einkommen = einkommen;
        }

        public virtual double GetZuversteuerndesEinkommen()
        {
            return _einkommen;
        }

        public virtual int BerechneSteuer()
        {
            double result = GetZuversteuerndesEinkommen() * (_steuersatz / 100.0);

            if (result < 1)
                return 1;

            return (int) result;
        }
    }
}
