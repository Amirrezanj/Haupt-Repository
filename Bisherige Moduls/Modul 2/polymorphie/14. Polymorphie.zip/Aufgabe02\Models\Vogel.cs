﻿namespace Aufgabe02.Models
{
    public class Vogel : Haustier
    {
        private bool _singvogel;

        public Vogel(string name, double jahresKosten, bool singvogel) : base(name, false, jahresKosten)
        {
            _singvogel = singvogel;
        }

        public bool GetSingvogel()
        {
            return _singvogel;
        }

        public override string GetBeschreibung()
        {
            return $"{base.GetBeschreibung()} Singvogel: {_singvogel}";
        }
    }
}
