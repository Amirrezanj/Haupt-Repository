﻿namespace Aufgabe05.Models
{
    public class Verein : Mitglied
    {
        private int _maxMitglieder;
        private Mitglied[] _mitglieder;

        public Verein(string name, int maximaleMitgliederAnzahl) : base(name)
        {
            _maxMitglieder = maximaleMitgliederAnzahl;
            _mitglieder = new Mitglied[maximaleMitgliederAnzahl];
        }

        public void MitgliedHinzufügen(Mitglied mitglied)
        {
            for (int i = 0; i < _mitglieder.Length; i++)
            {
                if (_mitglieder[i] == null)
                {
                    _mitglieder[i] = mitglied;
                    break;
                }
            }
        }

        public override double GetAusgaben()
        {
            double sum = 0.0d;

            for (int i = 0; i < _mitglieder.Length; i++)
            {
                sum += _mitglieder[i].GetAusgaben();
            }

            return sum;
        }

        public override double GetEinnahmen()
        {
            double sum = 0.0d;

            for (int i = 0; i < _mitglieder.Length; i++)
            {
                sum += _mitglieder[i].GetEinnahmen();
            }

            return sum;
        }

        public override string ToString()
        {
            string s = string.Empty;

            for (int i = 0; i < _mitglieder.Length; i++)
            {
                s += _mitglieder[i].ToString() + " ";
            }

            return s;
        }
    }
}