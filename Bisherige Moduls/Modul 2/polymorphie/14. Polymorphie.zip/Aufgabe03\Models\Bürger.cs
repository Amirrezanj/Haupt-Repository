﻿namespace Aufgabe03.Models
{
    public class Bürger : Einwohner
    {
        public Bürger(string name) : base(name) 
        { 
        }
    }
}
