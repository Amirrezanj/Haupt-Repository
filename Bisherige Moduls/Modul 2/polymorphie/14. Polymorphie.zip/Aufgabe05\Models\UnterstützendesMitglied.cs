﻿namespace Aufgabe05.Models
{
    public class UnterstützendesMitglied : Mitglied
    {
        public UnterstützendesMitglied(string name) : base(name)
        {
        }

        public override double GetAusgaben()
        {
            return 15;
        }

        public override double GetEinnahmen()
        {
            return 100;
        }
    }
}