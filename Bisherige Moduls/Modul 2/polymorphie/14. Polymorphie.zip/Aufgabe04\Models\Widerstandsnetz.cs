﻿namespace Aufgabe04.Models
{
    public abstract class Widerstandsnetz : Widerstand
    {
        protected List<Widerstand> _widerstände;

        public Widerstandsnetz(Widerstand r1, Widerstand r2, Widerstand[] rn) : base()
        {
            _widerstände = [r1, r2, .. rn];

            //_widerstände = new Widerstand[rn.Length + 2];
            //_widerstände[0] = r1;
            //_widerstände[1] = r2;

            //for (int i = 2; i < rn.Length; i++) {
            //    _widerstände[i] = rn[i - 2];
            //}

            ErzeugeName();
            BerechneWiderstand();
        }

        protected virtual void ErzeugeName()
        {
            string name = string.Empty;

            for (int i = 0; i < _widerstände.Count; i++)
            {
                Widerstand w = _widerstände[i];
                name += w.GetName();

                if (i < _widerstände.Count - 1)
                {
                    name += ",";
                }
            }

            _name = name + ")";
        }

        protected abstract void BerechneWiderstand();
    }
}
