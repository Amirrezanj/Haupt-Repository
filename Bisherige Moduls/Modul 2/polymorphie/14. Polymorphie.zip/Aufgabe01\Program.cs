﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Auto auto1 = new Auto();
            Auto auto2 = new Auto("D FA 512", 4);

            auto1.Fahren(59);
            auto2.Fahren(100);
            auto1.Waschen();
            auto2.Waschen();

            Pickup pickup = new Pickup("D SI 510", 500);
            pickup.Beladen(50);
            pickup.Waschen();

            Console.WriteLine(auto1);
            Console.WriteLine(auto2);
            Console.WriteLine(pickup);
        }
    }
}
