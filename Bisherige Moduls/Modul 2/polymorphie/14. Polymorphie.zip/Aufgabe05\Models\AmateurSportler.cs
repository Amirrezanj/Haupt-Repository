﻿namespace Aufgabe05.Models
{
    public class AmateurSportler : AktivesMitglied
    {
        public AmateurSportler(string name, int aktivitätsgrad) : base(name, aktivitätsgrad, 1.5, 25)
        {
        }
    }
}