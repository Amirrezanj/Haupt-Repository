﻿namespace Aufgabe02.Models
{
    public abstract class Haustier
    {
        private string _name;
        private bool _steuerpflichtig;
        private double _jahresKostenTierarzt;

        public Haustier(string name, bool steuerpflichtig, double jahresKostenTierarzt)
        {
            _name = name;
            _steuerpflichtig = steuerpflichtig;
            _jahresKostenTierarzt = jahresKostenTierarzt;
        }

        public string GetName()
        {
            return _name;
        }

        public double GetJahreskosten()
        {
            return _jahresKostenTierarzt;
        }

        public bool GetSteuerpflichtig()
        {
            return _steuerpflichtig;
        }

        public virtual string GetBeschreibung()
        {
            if (_steuerpflichtig)
                return $"{_name} ist Steuerpflichtig";
            else
                return $"{_name} ist nicht Steuerpflichtig";
        }
    }
}
