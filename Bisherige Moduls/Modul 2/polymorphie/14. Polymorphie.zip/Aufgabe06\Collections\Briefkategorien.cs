﻿namespace Aufgabe06.Collections
{
    public enum Briefkategorien
    {
        Standard,
        Eilbrief,
        Einschreiben
    }
}