﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe03.Models
{
    public class Steuereintreiber
    {
        public int SteuernEintreiben(Einwohner[] volk)
        {
            int sum = 0;

            foreach (Einwohner e in volk)
                sum += e.BerechneSteuer();

            return sum;
        }
    }
}
