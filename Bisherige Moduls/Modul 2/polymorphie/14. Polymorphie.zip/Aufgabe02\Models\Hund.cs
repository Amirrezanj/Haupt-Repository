﻿namespace Aufgabe02.Models
{
    public class Hund : Haustier
    {
        private string _rasse;

        public Hund (string name, double jahresKosten, string rasse) : base(name, true, jahresKosten)
        {
            _rasse = rasse;
        }

        public string GetRasse()
        {
            return _rasse;
        }

        public override string GetBeschreibung()
        {
            return $"{base.GetBeschreibung()} Rasse: {_rasse}" ;
        }
    }
}
