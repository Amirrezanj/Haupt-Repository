﻿namespace Aufgabe04.Models
{
    public class Reihenschaltung : Widerstandsnetz
    {
        public Reihenschaltung(Widerstand r1, Widerstand r2, Widerstand[] rn) : base(r1, r2, rn)
        {
        }

        protected override void ErzeugeName()
        {
            base.ErzeugeName();
            _name = "(Rr:" + _name;
        }

        protected override void BerechneWiderstand()
        {
            double wert = 0;

            for (int i = 0; i < _widerstände.Count; i++)
            {
                wert += _widerstände[i].GetWiderstandswert();
            }

            _wert = wert;
        }
    }
}
