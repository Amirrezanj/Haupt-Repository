﻿namespace Aufgabe05.Models
{
    public class Spitzensportler : AktivesMitglied
    {
        public Spitzensportler(string name, int aktivitätsgrad) : base(name, aktivitätsgrad, 5, 10)
        {
        }
    }
}