﻿namespace Aufgabe02.Models
{
    public class Katze : Haustier
    {
        private Vogel _lieblingsVogel;

        public Katze(string name, double jahresKosten, Vogel lieblingsVogel) : base(name, false, jahresKosten)
        {
            _lieblingsVogel = lieblingsVogel;
        }

        public string GetVogelName()
        {
            return _lieblingsVogel.GetName();
        }

        public void SetzeLieblingsVogel(Vogel vogel)
        {
            _lieblingsVogel = vogel;
        }

        public override string GetBeschreibung()
        {
            return $"{base.GetBeschreibung()} {_lieblingsVogel.GetBeschreibung()}";
        }
    }
}
