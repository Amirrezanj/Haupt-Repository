﻿namespace Aufgabe06.Models
{
    public class Adresse
    {
        private string _vorname;
        private string _nachname;
        private string _straßeHausnummer;
        private string _plzOrt;
        private string _land;

        public Adresse(string vorname, string nachname, string straßeHausnummer, string plzOrt) :
            this(vorname, nachname, straßeHausnummer, plzOrt, "Deutschland")
        {
        }

        public Adresse(string vorname, string nachname, string straßeHausnummer, string plzOrt, string land)
        {
            _vorname = vorname;
            _nachname = nachname;
            _straßeHausnummer = straßeHausnummer;
            _plzOrt = plzOrt;
            _land = land;
        }

        public bool IstGültig()
        {
            return !string.IsNullOrWhiteSpace(_vorname) &&
                !string.IsNullOrWhiteSpace(_nachname) &&
                !string.IsNullOrWhiteSpace(_straßeHausnummer) &&
                !string.IsNullOrWhiteSpace(_plzOrt);
        }

        public override string ToString()
        {
            return $"Vorname: {_vorname} Nachname: {_nachname} StraßeHausnummer: " +
                $"{_straßeHausnummer} PlzOrt: {_plzOrt} Land: {_land}";
        }

        public string GetVorname()
        {
            return _vorname;
        }

        public string GetNachname()
        {
            return _nachname;
        }

        public string GetStraßeHausnummer()
        {
            return _straßeHausnummer;
        }

        public string GetPlzOrt()
        {
            return _plzOrt;
        }

        public string GetLand()
        {
            return _land;
        }
    }
}