﻿using Aufgabe06.Collections;

namespace Aufgabe06.Models
{
    public class VersandService
    {
        private static int _fortlaufendeNummer;
        private List<Postsendung> _allePostsendungen = new List<Postsendung>();

        public void NeuerBrief(Adresse absender, Adresse empfänger)
        {
            Brief brief = new Brief(_fortlaufendeNummer++, absender, empfänger);
            _allePostsendungen.Add(brief);
        }

        public void NeuerBrief(Adresse absender, Adresse empfänger, Briefkategorien kategorie)
        {
            Brief brief = new Brief(_fortlaufendeNummer++, absender, empfänger, kategorie);
            _allePostsendungen.Add(brief);
        }

        public void NeuesPaket(Adresse absender, Adresse empfänger, double gewicht, bool versichert, bool verfolgbaresPaket)
        {
            if (verfolgbaresPaket)
            {
                VerfolgbaresPaket paket = new VerfolgbaresPaket(_fortlaufendeNummer++, absender, empfänger, gewicht, versichert);
                _allePostsendungen.Add(paket);
            }
            else
            {
                Paket paket = new Paket(_fortlaufendeNummer++, absender, empfänger, gewicht, versichert);
                _allePostsendungen.Add(paket);
            }
        }

        public void Ausliefern()
        {
            foreach (Postsendung postsendung in _allePostsendungen)
            {
                if (postsendung.GetAbsender().IstGültig() && postsendung.GetEmpfänger().IstGültig())
                    postsendung.SetZugestellt(true);
            }
        }

        public void SetzeStation(VerfolgbaresPaket paket, string ort)
        {
            paket.SetzeStation(ort);
        }

        public override string ToString()
        {
            string s = string.Empty;

            foreach (Postsendung postsendung in _allePostsendungen)
            {
                s += $"\n{postsendung}";
            }

            return s;
        }
    }
}