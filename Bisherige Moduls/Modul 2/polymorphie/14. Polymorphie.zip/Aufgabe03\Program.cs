﻿using Aufgabe03.Models;

namespace Aufgabe03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            König könig = new König("Peter");
            könig.SetEinkommen(100);
            Console.WriteLine($"König {könig.BerechneSteuer()}");

            Leibeigene leibeigene = new Leibeigene("Torsten");
            leibeigene.SetEinkommen(100);
            Console.WriteLine($"Leibeigene {leibeigene.BerechneSteuer()}");

            Bürger bürger = new Bürger("Sandra");
            bürger.SetEinkommen(100); 
            Console.WriteLine($"Bürger {bürger.BerechneSteuer()}");

            Adeligen adeligen = new Adeligen("Wilhelm");
            adeligen.SetEinkommen(100);
            Console.WriteLine($"Adeligen {adeligen.BerechneSteuer()}");

            Einwohner[] volk = {könig, leibeigene, bürger, adeligen };

            Steuereintreiber steuereintreiber = new Steuereintreiber();
            int steuern = steuereintreiber.SteuernEintreiben(volk);
            Console.WriteLine($"Die Steuern betragen: {steuern}");
        }
    }
}
