﻿using Aufgabe04.Models;

namespace Aufgabe04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Widerstand r1 = new Widerstand("R1", 100);
            Widerstand r2 = new Widerstand("R2", 200);
            Widerstand r3 = new Widerstand("R3", 300);
            Widerstand r4 = new Widerstand("R4", 400);
            Widerstand r5 = new Widerstand("R5", 500);
            Widerstand r6 = new Widerstand("R6", 600);

            Parallelschaltung r13 = new Parallelschaltung(r1, r3, []);
            Reihenschaltung r132 = new Reihenschaltung(r13, r2, []);
            Reihenschaltung r45 = new Reihenschaltung(r4, r5, []);

            Parallelschaltung r123456 = new Parallelschaltung(r132, r45, [r6]);

            Console.WriteLine(r123456.GetName());
            Console.WriteLine(r123456.GetWiderstandswert());
        }
    }
}
