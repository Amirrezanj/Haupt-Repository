﻿namespace Aufgabe05.Models
{
    public class Trainer : AktivesMitglied
    {
        public Trainer(string name, int aktivitätsgrad) : base(name, aktivitätsgrad, 50, 10)
        {
        }
    }
}