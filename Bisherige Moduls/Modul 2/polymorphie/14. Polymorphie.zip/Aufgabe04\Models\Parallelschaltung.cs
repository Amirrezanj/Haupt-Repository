﻿namespace Aufgabe04.Models
{
    public class Parallelschaltung : Widerstandsnetz
    {
        public Parallelschaltung(Widerstand r1, Widerstand r2, Widerstand[] rn) : base(r1, r2, rn)
        {

        }

        protected override void ErzeugeName()
        {
            base.ErzeugeName();
            _name = "(Rp:" + _name;
        }

        protected override void BerechneWiderstand()
        {
            double wert = 0;

            foreach (Widerstand w in _widerstände)
            {
                wert += 1 / w.GetWiderstandswert();
            }

            _wert = 1 / wert;
        }
    }
}
