﻿namespace Aufgabe03.Models
{
    public class Leibeigene : Einwohner
    {
        public Leibeigene(string name) : base(name) 
        {
        }

        public override double GetZuversteuerndesEinkommen()
        {
            double einkommen = base.GetZuversteuerndesEinkommen() - 12;

            if (einkommen <= 12)
                return 0;

            return einkommen; 
        }
    }
}
