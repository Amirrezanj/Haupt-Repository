﻿using Aufgabe05.Models;

namespace Aufgabe05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AmateurSportler amateurSportler = new AmateurSportler("Peter", 5);
            Spitzensportler spitzenSportler = new Spitzensportler("Hans", 9);
            Trainer trainer = new Trainer("Fritz", 2);
            UnterstützendesMitglied unterstützendesMitglied = new UnterstützendesMitglied("Thomas");
            Vorstandsmitglied vorstandsmitglied = new Vorstandsmitglied("George", 10);

            Verein verein = new Verein("BVB", 5);
            verein.MitgliedHinzufügen(amateurSportler);
            verein.MitgliedHinzufügen(spitzenSportler);
            verein.MitgliedHinzufügen(trainer);
            verein.MitgliedHinzufügen(unterstützendesMitglied);
            verein.MitgliedHinzufügen(vorstandsmitglied);

            AmateurSportler amateurSportler2 = new AmateurSportler("Franz", 5);
            Spitzensportler spitzenSportler2 = new Spitzensportler("Laura", 9);
            Trainer trainer2 = new Trainer("Anja", 2);
            UnterstützendesMitglied unterstützendesMitglied2 = new UnterstützendesMitglied("Tom");
            Vorstandsmitglied vorstandsmitglied2 = new Vorstandsmitglied("Paul", 10);

            Verein verein2 = new Verein("Werkself", 6);
            verein2.MitgliedHinzufügen(amateurSportler2);
            verein2.MitgliedHinzufügen(spitzenSportler2);
            verein2.MitgliedHinzufügen(trainer2);
            verein2.MitgliedHinzufügen(unterstützendesMitglied2);
            verein2.MitgliedHinzufügen(vorstandsmitglied2);
            verein2.MitgliedHinzufügen(verein);
            Console.WriteLine(verein2);
        }
    }
}
