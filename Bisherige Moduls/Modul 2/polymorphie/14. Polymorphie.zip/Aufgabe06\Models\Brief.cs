﻿using Aufgabe06.Collections;

namespace Aufgabe06.Models
{
    public class Brief : Postsendung
    {
        private Briefkategorien _briefkategorie;

        public Brief(int id, Adresse absender, Adresse empfänger) : this(id, absender, empfänger, Briefkategorien.Standard)
        {
        }

        public Brief(int id, Adresse absender, Adresse empfänger, Briefkategorien briefkategorie) : base(id, absender, empfänger)
        {
            _briefkategorie = briefkategorie;
        }

        public override string ToString()
        {
            return $"{base.ToString()} \nBriefkategorie: {_briefkategorie}";
        }

        public Briefkategorien GetBriefkategorien()
        {
            return _briefkategorie;
        }
    }
}