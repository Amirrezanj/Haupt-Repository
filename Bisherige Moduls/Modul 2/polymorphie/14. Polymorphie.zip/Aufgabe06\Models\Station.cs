﻿namespace Aufgabe06.Models
{
    public class Station
    {
        private string _ort;
        private DateTime _zeitstempel;

        public Station(string ort)
        {
            _ort = ort;
            _zeitstempel = DateTime.Now;
        }

        public override string ToString()
        {
            return $"Ort: {_ort} Zeitstempel: {_zeitstempel}";
        }

        public string GetOrt()
        {
            return _ort;
        }

        public DateTime GetZeitstempel()
        {
            return _zeitstempel;
        }
    }
}