﻿namespace Aufgabe05.Models
{
    public class Vorstandsmitglied : Mitglied
    {
        private int _kompetenzwert;
        private double _provision = 0.2;

        public Vorstandsmitglied(string name, int kompetenzwert) : base(name)
        {
            _kompetenzwert = kompetenzwert;
        }

        public override double GetAusgaben()
        {
            return GetEinnahmen() * _provision;
        }

        public override double GetEinnahmen()
        {
            return _kompetenzwert * 100;
        }
    }
}