﻿namespace Aufgabe06.Models
{
    public class Paket : Postsendung
    {
        private double _gewicht;
        private bool _versichert;

        public Paket(int id, Adresse absender, Adresse empfänger, double gewicht, bool versichert) : base(id, absender, empfänger)
        {
            _gewicht = gewicht;
            _versichert = versichert;
        }

        public override string ToString()
        {
            return $"{base.ToString()} \nGewicht: {_gewicht} \nVersichert: {_versichert}";
        }

        public double GetGewicht()
        {
            return _gewicht;
        }

        public bool GetVersichert()
        {
            return _versichert;
        }
    }
}