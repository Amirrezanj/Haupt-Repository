﻿namespace Aufgabe05.Models
{
    public abstract class AktivesMitglied : Mitglied
    {
        private int _aktivitätsgrad;
        private double _faktor;
        private double _monatlicherBetrag;

        public AktivesMitglied(string name, int aktivitätsgrad, double faktor, double monatlicherBetrag) : base(name)
        {
            _aktivitätsgrad = aktivitätsgrad;
            _faktor = faktor;
            _monatlicherBetrag = monatlicherBetrag;
        }

        public override double GetEinnahmen()
        {
            return _monatlicherBetrag;
        }

        public override double GetAusgaben()
        {
            return _aktivitätsgrad * _faktor;
        }
    }
}