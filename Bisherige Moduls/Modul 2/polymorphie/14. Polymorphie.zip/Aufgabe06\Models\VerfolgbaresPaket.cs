﻿namespace Aufgabe06.Models
{
    public class VerfolgbaresPaket : Paket
    {
        private List<Station> _stationen = new List<Station>();

        public VerfolgbaresPaket(Paket paket) : base(paket.GetId(), paket.GetAbsender(), paket.GetEmpfänger(), paket.GetGewicht(), paket.GetVersichert())
        {
        }

        public VerfolgbaresPaket(int id, Adresse absender, Adresse empfänger, double gewicht, bool versichert) : base(id, absender, empfänger, gewicht, versichert)
        {
        }

        public void SetzeStation(string ort)
        {
            _stationen.Add(new Station(ort));
        }

        public override string ToString()
        {
            string stationenString = string.Empty;

            foreach (Station station in _stationen)
            {
                stationenString += $"\n   {station}";
            }

            return $"{base.ToString()} \nStationen: {stationenString}";
        }
    }
}