﻿using Aufgabe02.Models;

namespace Aufgabe02
{
    internal class Program
    {
        private static Haustier[] _haustiere = new Haustier[6];

        static void Main(string[] args)
        {
            HaustierObjekteAnlegen();
            NeuerLieblingsvogel(_haustiere[2], _haustiere[0]);
            HaustiereAusgeben();
        }

        public static void HaustierObjekteAnlegen()
        {
            Vogel vogel2 = new Vogel("Schnabel", 10, false);
            _haustiere[0] = new Vogel("Pieps", 50, true);
            _haustiere[1] = vogel2;
            _haustiere[2] = new Katze("Mauzi", 24, (Vogel) _haustiere[0]);
            _haustiere[3] = new Katze("Mieze", 51, vogel2);
            _haustiere[4] = new Hund("Wuff", 190, "Beagle");
            _haustiere[5] = new Hund("Bello", 200, "Goldi");
        }

        public static void NeuerLieblingsvogel(Haustier katze, Haustier vogel)
        {
            Katze k = katze as Katze;
            Vogel v = vogel as Vogel;

            if(k != null && v != null)
            {
                k.SetzeLieblingsVogel(v);
            }
        }

        public static void HaustiereAusgeben()
        {
            double sum = 0;

            foreach(Haustier haustier in _haustiere)
            {
                sum += haustier.GetJahreskosten();
                Console.WriteLine($"{haustier.GetType().Name} {haustier.GetBeschreibung()}");
            }

            Console.WriteLine($"Tierarztkosten: {sum}");
        }
    }
}
