﻿namespace Aufgabe03.Models
{
    public class König : Einwohner
    {
        public König(string name) : base(name) 
        {
        }

        public override int BerechneSteuer()
        {
            return 0;
        }
    }
}
