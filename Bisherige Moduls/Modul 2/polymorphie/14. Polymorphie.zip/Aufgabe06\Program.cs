﻿using Aufgabe06.Models;

namespace Aufgabe06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Adresse absender = new Adresse("Peter", "Bauer", "Peterweg 123", "51251 Köln");
            Adresse empfänger = new Adresse("Hans", "Fischer", "Fischerweg 567", "12161 Bonn");

            VersandService versandService = new VersandService();
            versandService.NeuerBrief(absender, empfänger);
            versandService.NeuesPaket(absender, empfänger, 50.0d, true, false);
            versandService.NeuesPaket(absender, empfänger, 150.0d, true, true);
            versandService.Ausliefern();

            Console.WriteLine(versandService.ToString());
        }
    }
}
