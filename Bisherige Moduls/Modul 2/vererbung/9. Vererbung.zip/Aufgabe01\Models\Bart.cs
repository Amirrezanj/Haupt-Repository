﻿namespace Aufgabe01.Models
{
    internal class Bart : EinSimpson
    {
        public Bart() : base()
        {
            _vorname = nameof(Bart);
            _aktion = "Skaten";
        }

        public void Haushalten()
        {
            _zähler++;
        }
    }
}
