﻿using Aufgabe03.Collections;

namespace Aufgabe03.Models
{
    public class Girokonto : Konto
    {
        private Kategorie _kategorie;
        private double _dispo;
        private double _dispoZinsatz;

        public Girokonto(Inhaber inhaber,
                        double startguthaben,
                        double dispo,
                        Kategorie kategorie)
                        : base(inhaber, startguthaben)
        {
            _kategorie = kategorie;
            _dispo = dispo;
            _dispoZinsatz = 16;
        }

        public void Auszahlen(double betrag)
        {
            if (_kontostand - betrag < 0) {
                if (_kontostand - betrag < _dispo) {
                    _kontostand -= betrag;
                }
            }
        }

        public double BerechneZinsen()
        {
            if (_kontostand < 0) {
                return _kontostand * (_dispoZinsatz / 100);
            }

            return 0;
        }
    }
}
