﻿using Aufgabe02.Collections;

namespace Aufgabe02.Models
{
    public sealed class Praktikant : Mitarbeiter
    {
        private Abteilung _abteilung;

        public Praktikant(string vorname, string nachname, Abteilung abteilung) : base(vorname, nachname)
        {
            _abteilung = abteilung;
        }

        public double GehaltsBerechnung()
        {
            return (double) _abteilung;
        }
    }
}
