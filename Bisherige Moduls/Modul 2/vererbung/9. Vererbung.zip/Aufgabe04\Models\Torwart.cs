﻿namespace Aufgabe04.Models;

public class Torwart : Spieler
{
    private int _reaktion;

    public Torwart(string name, int alter, int stärke, int torschuss, int motivation, int reaktion) : base(name, alter, stärke, torschuss, motivation)
    {
        _reaktion = reaktion;
    }

    public int GetReaktion()
    {
        return _reaktion;
    }

    public bool HältDenSchuss(int schussQualität)
    {
        int halteQualität = Math.Max(1, Math.Min(10, _reaktion + _zufall.Next(3) - 1));
        if (halteQualität >= schussQualität) {
            return true; // gehalten
        } else {
            return false; // TOR!!!
        }
    }
}
