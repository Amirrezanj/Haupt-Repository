﻿namespace Aufgabe02.Collections
{
    public enum Tarifgruppe
    {
        A = 2560,
        B = 3000,
        C = 3200,
        D = 5400
    }
}
