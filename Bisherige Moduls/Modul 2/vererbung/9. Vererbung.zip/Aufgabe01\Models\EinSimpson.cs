﻿namespace Aufgabe01.Models
{
    public class EinSimpson
    {
        protected string _vorname = string.Empty;
        protected string _nachname = "Simpson";
        protected string _adresse = "Evergreen 5";
        protected string _hautfarbe = "Gelb";
        protected string _aktion = string.Empty;
        protected int _zähler;

        protected EinSimpson()
        {
        }

        public void Vorstellen()
        {
            Console.WriteLine($"Ich heiße {_vorname} {_nachname} und wohne in der {_adresse}");
        }

        public void ZählerAusgeben()
        {
            Console.WriteLine($"{_vorname} hat {_zähler} mal {_aktion}");
        }
    }
}
