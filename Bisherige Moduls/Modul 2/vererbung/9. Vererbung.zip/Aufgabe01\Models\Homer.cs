﻿namespace Aufgabe01.Models
{
    internal class Homer : EinSimpson
    {
        public Homer() : base()
        {
            _vorname = nameof(Homer);
            _aktion = "Donuten";
        }

        public void Haushalten()
        {
            _zähler++;
        }
    }
}
