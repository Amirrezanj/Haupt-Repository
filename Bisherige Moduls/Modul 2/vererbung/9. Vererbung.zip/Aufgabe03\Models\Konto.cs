﻿namespace Aufgabe03.Models
{
    public class Konto
    {
        private static readonly Random _random = new Random();

        private Inhaber _inhaber;
        private int _kontonummer;
        protected double _kontostand;
        protected DateTime _eröffnungsDatum;
        protected double _habenzinssatz;

        public Konto(Inhaber inhaber) : this(inhaber, 0)
        {
        }

        public Konto(Inhaber inhaber, double startguthaben)
        {
            _inhaber = inhaber;
            _kontostand = startguthaben;
            _eröffnungsDatum = DateTime.UtcNow;
            _kontonummer = _random.Next(100000, 999999);
        }

        public void Kontostand()
        {
            Console.WriteLine($"{_kontonummer} {_kontostand}");
        }

        public void Einzahlen(double guthaben)
        {
            _kontostand += guthaben;
        }

        public double BerechneZinsen()
        {
            return _kontostand * (_habenzinssatz / 100);
        }
    }
}
