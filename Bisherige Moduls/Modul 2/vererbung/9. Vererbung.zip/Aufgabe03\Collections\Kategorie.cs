﻿namespace Aufgabe03.Collections
{
    public enum Kategorie
    {
        Standard,
        Schüler,
        Student,
        Gewerblich
    }
}
