﻿namespace Aufgabe04.Models;

public class Person
{
    private string _name;
    private int _alter;

    public Person(string name, int alter)
    {
        _name = name;
        _alter = alter;
    }

    public string GetName()
    {
        return _name;
    }

    public int GetAlter()
    {
        return _alter;
    }
}
