﻿using Aufgabe02.Collections;
using Aufgabe02.Models;

namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Angestellter angestellter = new Angestellter("Peter", "bauer", 50, Tarifgruppe.A);
            Console.WriteLine(angestellter.GehaltsBerechnung());

            Praktikant praktikant = new Praktikant("Franz", "Beckenbauer", Abteilung.Entwicklung);
            Console.WriteLine(praktikant.GehaltsBerechnung());

            ExterneMitarbeiter externeMitarbeiter = new ExterneMitarbeiter("Marie", "Curry");
            externeMitarbeiter.SetzeProjektStunden(5);
            Console.WriteLine(externeMitarbeiter.GehaltsBerechnung());
        }
    }
}
