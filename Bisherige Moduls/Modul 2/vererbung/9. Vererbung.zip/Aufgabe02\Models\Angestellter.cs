﻿using Aufgabe02.Collections;

namespace Aufgabe02.Models
{
    public class Angestellter : Mitarbeiter
    {
        private Tarifgruppe _tarifgruppe;

        public Angestellter(string vorname, string nachname, int alter, Tarifgruppe tarifgruppe) : base(vorname, nachname, alter)
        {
            _tarifgruppe = tarifgruppe;
        }

        public double GehaltsBerechnung()
        {
            return (int) _tarifgruppe * (1 + (_alter - 25) / (double) 100);
        }
    }
}
