﻿namespace Aufgabe01.Models
{
    internal class Maggie : EinSimpson
    {
        public Maggie() : base()
        {
            _vorname = nameof(Maggie);
            _aktion = "Schnullern";
        }

        public void Schnullern()
        {
            _zähler++;
        }
    }
}
