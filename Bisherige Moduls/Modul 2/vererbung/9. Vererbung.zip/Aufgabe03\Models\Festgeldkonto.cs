﻿namespace Aufgabe03.Models
{
    public class Festgeldkonto : Konto
    {
        private int _mindestlaufZeitInJahre;

        public Festgeldkonto(Inhaber inhaber, double startguthaben, int mindestlaufZeitInJahre) : base(inhaber, startguthaben)
        {
            _mindestlaufZeitInJahre = mindestlaufZeitInJahre;
            _habenzinssatz = 2.0;
        }

        public void Auszahlen(double betrag)
        {
            if (IstRestlaufzeitErreicht()) {
                if (_kontostand <= betrag)
                    _kontostand = 0;
                else
                    _kontostand -= betrag;
            }
        }

        public bool IstRestlaufzeitErreicht()
        {
            return _eröffnungsDatum.AddYears(_mindestlaufZeitInJahre) <= DateTime.UtcNow;
        }
    }
}
