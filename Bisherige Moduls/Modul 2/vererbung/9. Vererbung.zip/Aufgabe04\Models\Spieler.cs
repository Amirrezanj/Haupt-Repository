﻿namespace Aufgabe04.Models;

public class Spieler : Person
{
    protected static readonly Random _zufall = new Random();

    private int _motivation;
    private int _stärke;
    private int _torschuss;
    private int _tore;

    public Spieler(string name, int alter, int stärke, int torschuss, int motivation) : base(name, alter)
    {
        _stärke = stärke;
        _torschuss = torschuss;
        _motivation = motivation;
        _tore = 0;
    }

    public int GetMotivation()
    {
        return _motivation;
    }

    public int GetStärke()
    {
        return _stärke;
    }

    public int GetTorschuss()
    {
        return _torschuss;
    }

    public int GetTore()
    {
        return _tore;
    }

    public void AddTor()
    {
        _tore++;
    }

    public int SchiesstAufTor()
    {
        _torschuss = Math.Max(1, Math.Min(10, _torschuss - _zufall.Next(3)));
        int schussQualität = Math.Max(1, Math.Min(10, _torschuss + _zufall.Next(3) - 1));
        return schussQualität;
    }
}
