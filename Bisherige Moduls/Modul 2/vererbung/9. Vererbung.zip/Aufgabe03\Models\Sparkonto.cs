﻿namespace Aufgabe03.Models
{
    public class Sparkonto : Konto
    {
        public Sparkonto(Inhaber inhaber, double startguthaben) : base(inhaber, startguthaben)
        {
            _habenzinssatz = 0.5;
        }

        public void Auszahlen(double betrag)
        {
            if (_kontostand <= betrag)
                _kontostand = 0;
            else
                _kontostand -= betrag;
        }
    }
}
