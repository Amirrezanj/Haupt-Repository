﻿namespace Aufgabe01.Models
{
    public class Marge : EinSimpson
    {
        public Marge() : base()
        {
            _vorname = nameof(Marge);
            _aktion = "Haushalten";
        }

        public void Haushalten()
        {
            _zähler++;
        }
    }
}
