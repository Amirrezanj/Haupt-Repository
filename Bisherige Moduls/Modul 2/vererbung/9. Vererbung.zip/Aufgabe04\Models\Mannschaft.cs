﻿namespace Aufgabe04.Models;

public class Mannschaft
{
    private Trainer _trainer;
    private Torwart _torwart;
    private Spieler[] _spieler;
    private string _name;

    public Mannschaft(string name, Trainer trainer, Torwart torwart, Spieler[] spieler)
    {
        _name = name;
        _trainer = trainer;
        _torwart = torwart;
        _spieler = spieler;
    }

    public int GetStärke()
    {
        var sum = 0;

        foreach (var spieler in _spieler) {
            sum += spieler.GetStärke();
        }

        return sum / _spieler.Length;
    }

    public int GetMotivation()
    {
        var sum = 0;

        foreach (var spieler in _spieler) {
            sum += spieler.GetMotivation();
        }

        return sum / _spieler.Length;
    }

    public Spieler[] GetKader()
    {
        return _spieler;
    }

    public string GetName()
    {
        return _name;
    }

    public Trainer GetTrainer()
    {
        return _trainer;
    }

    public Torwart GetTorwart()
    {
        return _torwart;
    }
}
