﻿namespace Aufgabe03.Models
{
    public class Inhaber
    {
        private string _vorname;
        private string _nachname;

        public Inhaber(string vorname, string nachname)
        {
            _vorname = vorname;
            _nachname = nachname;
        }

        public string GetName()
        {
            return $"{_vorname} {_nachname}";
        }
    }
}
