﻿using Aufgabe03.Collections;
using Aufgabe03.Models;

namespace Aufgabe03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Inhaber inhaber = new Inhaber("Peter", "Pan");

            Girokonto girokonto = new Girokonto(inhaber, 50000, 5000, Kategorie.Schüler);
            Sparkonto sparkonto = new Sparkonto(inhaber, 20000);
            Festgeldkonto festgeldkonto = new Festgeldkonto(inhaber, 500000, 2);

            Console.WriteLine(girokonto.BerechneZinsen());
            Console.WriteLine(sparkonto.BerechneZinsen());
            Console.WriteLine(festgeldkonto.BerechneZinsen());
        }
    }
}
