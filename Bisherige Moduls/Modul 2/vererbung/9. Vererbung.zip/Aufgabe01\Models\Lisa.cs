﻿namespace Aufgabe01.Models
{
    internal class Lisa : EinSimpson
    {
        public Lisa() : base()
        {
            _vorname = nameof(Lisa);
            _aktion = "Saxophonen";
        }

        public void Haushalten()
        {
            _zähler++;
        }
    }
}
