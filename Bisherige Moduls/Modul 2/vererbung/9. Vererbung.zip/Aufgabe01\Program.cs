﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Marge marge = new Marge();
            marge.Haushalten();
            marge.Vorstellen();
            marge.ZählerAusgeben();
        }
    }
}
