﻿namespace Aufgabe02.Models
{
    public class ExterneMitarbeiter : Mitarbeiter
    {
        private int _stunden;
        private int _stundensatz = 75;

        public ExterneMitarbeiter(string vorname, string nachname) : base(vorname, nachname)
        {
            _vorname = vorname;
            _nachname = nachname;
        }

        public void SetzeProjektStunden(int stunden)
        {
            _stunden = stunden;
        }

        public double GehaltsBerechnung()
        {
            return _stunden * _stundensatz;
        }
    }
}
