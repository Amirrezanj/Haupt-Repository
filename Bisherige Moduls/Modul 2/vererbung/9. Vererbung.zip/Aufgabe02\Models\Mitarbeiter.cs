﻿namespace Aufgabe02.Models
{
    public class Mitarbeiter
    {
        protected string _vorname;
        protected string _nachname;
        protected int _alter;

        public Mitarbeiter(string vorname, string nachname)
        {
            _vorname = vorname;
            _nachname = nachname;
        }

        public Mitarbeiter(string vorname, string nachname, int alter)
        {
            _vorname = vorname;
            _nachname = nachname;
            _alter = alter;
        }
    }
}
