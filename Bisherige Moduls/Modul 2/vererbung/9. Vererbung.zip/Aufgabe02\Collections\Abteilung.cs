﻿namespace Aufgabe02.Collections
{
    public enum Abteilung
    {
        Entwicklung = 935,
        Vertrieb = 820,
        Produktion = 710
    }
}
