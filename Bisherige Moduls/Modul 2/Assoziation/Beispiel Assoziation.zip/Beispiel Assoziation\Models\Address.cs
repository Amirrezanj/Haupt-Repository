﻿namespace Beispiel_Assoziation.Models
{
    public class Address
    {
        private string _street;

        public Address(string street)
        {
            _street = street;
        }

        public string GetStreet()
        {
            return _street;
        }
    }
}
