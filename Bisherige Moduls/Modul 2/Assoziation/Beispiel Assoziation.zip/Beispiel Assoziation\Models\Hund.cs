﻿namespace Beispiel_Assoziation.Models
{
    public class Hund
    {
        private Person _herrchen;

        public Hund(Person herrchen)
        {
            _herrchen = herrchen;
        }
    }
}
