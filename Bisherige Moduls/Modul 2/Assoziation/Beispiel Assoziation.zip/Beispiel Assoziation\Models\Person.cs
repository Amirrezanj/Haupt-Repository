﻿namespace Beispiel_Assoziation.Models
{
    public class Person
    {
        private static readonly Random _random = new Random();

        private Person _mother;
        private Person _child;
        private Address _homeAddress;
        private Address _workAddress;
        private Hund _hund;
        private int _geschlecht;

        public Person(Address homeAddress) : this(homeAddress, null)
        {
        }

        public Person(Address homeAddress, Address workAddress)
        {
            _homeAddress = homeAddress;
            _workAddress = workAddress;
            _geschlecht = _random.Next(0, 3);
        }

        public Address GetHomeAddress()
        {
            return _homeAddress;
        }

        public bool IsWorkingFromHome()
        {
            return _workAddress == null;
        }

        public void SetHomeAddress(Address homeAddress)
        {
            _homeAddress = homeAddress;
        }

        public void SetWorkAddress(Address workAddress)
        {
            _workAddress = workAddress;
        }

        public void SetHund(Hund hund)
        {
            _hund = hund;
        }

        public void SetMother(Person mother)
        {
            _mother = mother;
        }

        public Person GetMother()
        {
            return _mother;
        }

        public void SetChild(Person child)
        {
            _child = child;
        }

        public Person GetChild()
        {
            return _child;
        }
    }
}
