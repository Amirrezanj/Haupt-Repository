﻿using Beispiel_Assoziation.Models;

namespace Beispiel_Assoziation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Address address = new Address("Peterweg");
            Person person1 = new Person(address);
            Person person2 = new Person(address);
            Hund hund = new Hund(person2);

            string street1 = person1.GetHomeAddress().GetStreet();
            string street2 = person2.GetHomeAddress().GetStreet();

            Console.WriteLine($"Person 1 working from home: {person1.IsWorkingFromHome()}");

            Person person3 = new Person(address);
            Person person4 = new Person(address);

            person1.SetMother(person2);
            person1.GetMother().SetMother(person3);
            person1.GetMother().GetMother().SetMother(person4);

            Person person5 = new Person(address);

            person5.SetMother(person1);
            person1.SetChild(person5);

            person1.GetChild().GetMother().GetChild().GetChild();
        }

        public static Person FindLastMother(Person mother)
        {
            if (mother.GetMother() == null)
                return mother;

            return FindLastMother(mother.GetMother());
        }
    }
}
