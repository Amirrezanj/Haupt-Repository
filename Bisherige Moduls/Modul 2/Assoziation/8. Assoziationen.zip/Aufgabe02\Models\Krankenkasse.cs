﻿namespace Aufgabe02.Models
{
    public class Krankenkasse
    {
        private string _name;
        private int _id;

        public Krankenkasse(string name, int id)
        {
            _name = name;
            _id = id;
        }

        public void Ausgabe()
        {
            Console.WriteLine($"{nameof(_name)} {_name} {nameof(_id)} {_id}");
        }
    }
}