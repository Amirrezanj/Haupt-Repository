﻿namespace Aufgabe03.Models
{
    public class Artikel
    {
        private int _nummer;
        private string _bezeichnung;
        private int _istBestand;
        private int _maxBestand;
        private double _preis;
        private int _verbrauch;
        private int _bestelldauer;

        public Artikel(int nummer,
                        string bezeichnung,
                        int istBestand,
                        int maxBestand,
                        int preis,
                        int verbrauch,
                        int bestelldauer)
        {
            _nummer = nummer;
            _bezeichnung = bezeichnung;
            _istBestand = istBestand;
            _maxBestand = maxBestand;
            _preis = preis;
            _verbrauch = verbrauch;
            _bestelldauer = bestelldauer;
        }

        public void Ausgabe()
        {
            Console.WriteLine($"{_nummer}{_bezeichnung}{_istBestand}{_maxBestand}{_preis}{_verbrauch}{_bestelldauer}");
        }

        public double GetPreis()
        {
            return _preis;
        }

        public int GetIstBestand()
        {
            return _istBestand;
        }

        public int GetBestelldauer()
        {
            return _bestelldauer;
        }

        public int GetVerbrauch()
        {
            return _verbrauch;
        }

        public int GetNummer()
        {
            return _nummer;
        }

        public int GetBestellVorschlag()
        {
            if (_istBestand <= GetMeldeBestand())
            {
                return Math.Abs(_istBestand - GetMeldeBestand());
            }
            else
            {
                return 0;
            }
        }

        public int GetMeldeBestand()
        {
            return _verbrauch * (_bestelldauer + 2);
        }
    }
}