﻿namespace Aufgabe04.Models
{
    public class Vektor
    {
        private Punkt _startpunkt;
        private Punkt _endpunkt;

        public Vektor(Punkt startpunkt, Punkt endpunkt)
        {
            _startpunkt = startpunkt;
            _endpunkt = endpunkt;
        }

        public double Länge()
        {
            return Math.Sqrt(Math.Pow(_startpunkt.GetX(), 2) + Math.Pow(_endpunkt.GetY(), 2));
        }
    }
}