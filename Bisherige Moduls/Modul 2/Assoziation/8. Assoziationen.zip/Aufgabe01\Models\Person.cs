﻿namespace Aufgabe01.Models
{
    public class Person
    {
        private string _vorname;
        private string _nachname;
        private int _age;
        private Adresse _adresse;
        private Hund _hund;

        public Person(string vorname, string nachname, int alter)
        {
            _vorname = vorname;
            _nachname = nachname;
            _age = alter;
        }

        public void SetAdresse(Adresse adresse)
        {
            _adresse = adresse;
        }

        public void SetHund(Hund hund)
        {
            _hund = hund;
        }

        public int GetAlter()
        {
            return _age;
        }

        public void Ausgabe()
        {
            Console.WriteLine($"{nameof(_vorname)} {_vorname} {nameof(_nachname)} {_nachname} {nameof(_age)} {_age}");

            if (_adresse != null)
                _adresse.Ausgabe();

            if (_hund != null)
                _hund.Ausgabe();
        }
    }
}