﻿namespace Aufgabe01.Models
{
    public class Adresse
    {
        private string _straße;
        private string _hausnummer;
        private string _plz;
        private string _ort;

        public Adresse(string straße, string hausnummer, string plz, string ort)
        {
            _straße = straße;
            _hausnummer = hausnummer;
            _plz = plz;
            _ort = ort;
        }

        public void Ausgabe()
        {
            Console.WriteLine($"{nameof(_straße)} {_straße} {nameof(_hausnummer)} {_hausnummer} {nameof(_plz)} {_plz} {nameof(_ort)} {_ort}");
        }
    }
}