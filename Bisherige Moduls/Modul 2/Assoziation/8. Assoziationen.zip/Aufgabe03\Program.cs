﻿using Aufgabe03.Models;

namespace Aufgabe03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Artikel[] artikel = ReadArtikelFromFile();

            Lager lager = new Lager(artikel);
            Console.WriteLine(lager.WarenWertBerechnen());
            lager.AusgabeWarenliste();
        }

        private static Artikel[] ReadArtikelFromFile()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "Artikel.csv");

            string[] lines = File.ReadAllLines(filePath);
            Artikel[] artikel = new Artikel[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                artikel[i] = new Artikel(int.Parse(lines[0]), lines[1], int.Parse(lines[2]), int.Parse(lines[3]), int.Parse(lines[4]), int.Parse(lines[5]), int.Parse(lines[6]));
            }

            return artikel;
        }
    }
}