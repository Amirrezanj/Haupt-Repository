﻿namespace Aufgabe07.Models
{
    public class Wette
    {
        private string _spieler;
        private double _einsatz;
        private string _schnecke;

        public Wette(string spieler, double einsatz, string schnecke)
        {
            _spieler = spieler;
            _einsatz = einsatz;
            _schnecke = schnecke;
        }

        public string Ausgabe()
        {
            return $"Spieler {_spieler} Einsatz {_einsatz} Schnecke {_schnecke}";
        }

        public string GetSchnecke()
        {
            return _schnecke;
        }

        public string GetSpieler()
        {
            return _spieler;
        }

        public double GetEinsatz()
        {
            return _einsatz;
        }
    }
}