﻿namespace Aufgabe06.Models
{
    public class EntryQueue
    {
        private Entry _head;
        private Entry _tail;

        public void Enqueue(string data)
        {
            Entry entry = new Entry(data);

            if (IsEmpty())
            {
                _head = _tail = entry;
            }
            else
            {
                _tail.SetNext(entry);
                _tail = entry;
            }
        }

        public string Dequeue()
        {
            if (IsEmpty())
            {
                return null;
            }

            string data = _head.GetData();
            _head = _head.GetNext();
            return data;
        }

        public bool IsEmpty()
        {
            return _head == null;
        }

        public void Print()
        {
            PrintRecursive(_head);
        }

        private static void PrintRecursive(Entry currentEntry)
        {
            Console.WriteLine(currentEntry.GetData());

            Entry nextEntry = currentEntry.GetNext();

            if (nextEntry == null)
                return;

            PrintRecursive(nextEntry);
        }
    }
}