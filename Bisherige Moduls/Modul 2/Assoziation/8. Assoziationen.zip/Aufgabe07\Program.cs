﻿using Aufgabe07.Models;

namespace Aufgabe07
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Rennschnecke schnecke1 = new Rennschnecke("Peter", 8);
            Rennschnecke schnecke2 = new Rennschnecke("Franz", 6);
            Rennschnecke schnecke3 = new Rennschnecke("Herbert", 7);

            Rennen rennen = new Rennen("Rennen 1", 3, 100);
            rennen.AddRennschnecke(schnecke1);
            rennen.AddRennschnecke(schnecke2);
            rennen.AddRennschnecke(schnecke3);

            Wettbüro wettbüro = new Wettbüro(rennen, 5);
            wettbüro.WetteAnnehmen("Peter", 100, "Spieler 1");
            wettbüro.WetteAnnehmen("Franz", 90, "Spieler 2");
            wettbüro.WetteAnnehmen("Herbert", 110, "Spieler 3");

            rennen.Durchführen();
            Console.WriteLine(wettbüro.Ausgabe());
            Console.WriteLine($"Gewinner: {rennen.ErmittleGewinner().GetName()}");
        }
    }
}