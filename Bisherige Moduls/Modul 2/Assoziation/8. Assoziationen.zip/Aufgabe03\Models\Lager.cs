﻿namespace Aufgabe03.Models
{
    public class Lager
    {
        private Artikel[] _artikel;

        public Lager(Artikel[] artikel)
        {
            _artikel = artikel;
        }

        public double WarenWertBerechnen()
        {
            double sum = 0;

            foreach (Artikel artikel in _artikel)
            {
                sum = artikel.GetPreis() * artikel.GetIstBestand();
            }

            return sum;
        }

        public void AusgabeWarenliste()
        {
            foreach (Artikel artikel in _artikel)
            {
                artikel.Ausgabe();
            }
        }
    }
}