﻿namespace Aufgabe06.Models
{
    public class Entry
    {
        private Entry _next;
        private string _data;

        public Entry(string data)
        {
            _data = data;
        }

        public Entry GetNext()
        {
            return _next;
        }

        public void SetNext(Entry entry)
        {
            _next = entry;
        }

        public string GetData()
        {
            return _data;
        }
    }
}