﻿namespace Aufgabe07.Models
{
    public class Rennen
    {
        private Rennschnecke[] _schnecken;

        private string _name;
        private int _maxTeilnehmer;
        private int _streckenLänge;

        public Rennen(string name, int maxTeilnehmer, int streckenLänge)
        {
            _name = name;
            _maxTeilnehmer = maxTeilnehmer;
            _streckenLänge = streckenLänge;
            _schnecken = new Rennschnecke[_maxTeilnehmer];
        }

        public void AddRennschnecke(Rennschnecke schnecke)
        {
            for (int i = 0; i < _schnecken.Length; i++)
            {
                if (_schnecken[i] == null)
                {
                    _schnecken[i] = schnecke;
                    break;
                }
            }
        }

        public string Ausgabe()
        {
            return $"Name {_name} MaxTeilnehmer {_maxTeilnehmer} StreckenLänge {_streckenLänge}";
        }

        public Rennschnecke ErmittleGewinner()
        {
            foreach (Rennschnecke r in _schnecken)
            {
                if (r != null && r.GetDistanz() >= _streckenLänge)
                {
                    return r;
                }
            }

            return null;
        }

        public void LassSchneckenKriechen()
        {
            foreach (Rennschnecke schnecke in _schnecken)
            {
                if (schnecke != null)
                    schnecke.Krieche();
            }
        }

        public void Durchführen()
        {
            while (ErmittleGewinner() == null)
            {
                LassSchneckenKriechen();
            }
        }

        public bool IstRennteilnehmer(string schneckenName)
        {
            bool contains = false;

            foreach (Rennschnecke schnecke in _schnecken)
            {
                if (schnecke.GetName() == schneckenName)
                {
                    contains = true;
                    break;
                }
            }

            return contains;
        }
    }
}