﻿namespace Aufgabe01.Models
{
    public class Hund
    {
        private bool _gefüttert;
        private string _name;
        private Person _person;

        public Hund(string name, Person person)
        {
            _name = name;
            _person = person;
        }

        public void Füttern()
        {
            _gefüttert = true;
        }

        public void GassiGehen()
        {
            if (!_gefüttert)
            {
                Console.WriteLine("Der Hund muss erst gefüttert werden");
            }
            else if (_person.GetAlter() < 16)
            {
                Console.WriteLine("Die Person muss mindestens 16 Jahre alt sein");
            }
            else
            {
                Console.WriteLine("Der Hund geht gassi");
            }
        }

        public void Ausgabe()
        {
            if (_gefüttert)
                Console.WriteLine($"Der Hund {_name} ist gefüttert");
            else
                Console.WriteLine($"Der Hund {_name} ist nicht gefüttert");
        }
    }
}