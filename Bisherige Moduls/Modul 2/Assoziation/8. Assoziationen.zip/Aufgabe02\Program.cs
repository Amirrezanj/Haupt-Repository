﻿using Aufgabe02.Models;

namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Adresse adresse = new Adresse("Peterweg", "55", "21523", "Baumort");
            Krankenkasse krankenkasse = new Krankenkasse("KKH", 15);
            Patient patient1 = new Patient("Peter", DateTime.Now.AddYears(-18), adresse, krankenkasse);

            patient1.Ausgabe();
        }
    }
}