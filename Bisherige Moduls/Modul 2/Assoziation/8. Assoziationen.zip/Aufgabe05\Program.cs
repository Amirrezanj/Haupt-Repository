﻿using Aufgabe05.Models;

namespace Aufgabe05
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Tennisspieler tennisspieler1 = new Tennisspieler("Peter", 50);
            Tennisspieler tennisspieler2 = new Tennisspieler("Franz", 25, tennisspieler1);
            Tennisspieler tennisspieler3 = new Tennisspieler("Marie", 41, tennisspieler2);

            tennisspieler1.Ausgabe();
            Console.WriteLine(tennisspieler1.IstLetzer());
            Console.WriteLine(tennisspieler2.IstLetzer());
            Console.WriteLine(tennisspieler3.AltersDifferenzBerechnen(tennisspieler2));

            Tennisspieler t = tennisspieler3.GetVerfolger().GetVerfolger();
        }

        public Tennisspieler GetLetzenTennisspieler(Tennisspieler spieler)
        {
            if (spieler.IstLetzer())
                return spieler;

            return GetLetzenTennisspieler(spieler.GetVerfolger());
        }
    }
}