﻿namespace Aufgabe07.Models
{
    public class Rennschnecke
    {
        private static readonly Random _random = new Random();

        private string _name;
        private int _maximaleGeschwindigkeit;
        private int _distanz;

        public Rennschnecke(string name, int maximaleGeschwindigkeit)
        {
            _name = name;
            _maximaleGeschwindigkeit = maximaleGeschwindigkeit;
        }

        public void Krieche()
        {
            _distanz += _random.Next(1, _maximaleGeschwindigkeit);
        }

        public string Ausgabe()
        {
            return $"Name {_name} Distanz {_distanz}";
        }

        public int GetDistanz()
        {
            return _distanz;
        }

        public string GetName()
        {
            return _name;
        }
    }
}