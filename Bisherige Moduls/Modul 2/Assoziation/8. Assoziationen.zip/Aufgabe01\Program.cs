﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Adresse adresse = new Adresse("Peterweg", "55", "512313", "Pfingshausen");
            Person person = new Person("Peter", "Pahn", 50);
            Hund hund = new Hund("Wuff", person);

            person.SetHund(hund);
            person.SetAdresse(adresse);

            hund.Füttern();
            hund.GassiGehen();
        }
    }
}