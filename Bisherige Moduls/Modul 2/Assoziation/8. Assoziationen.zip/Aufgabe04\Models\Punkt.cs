﻿namespace Aufgabe04.Models
{
    public class Punkt
    {
        private double _x;
        private double _y;

        public Punkt(double x, double y)
        {
            _x = x;
            _y = y;
        }

        public double GetX()
        {
            return _x;
        }

        public double GetY()
        {
            return _y;
        }
    }
}