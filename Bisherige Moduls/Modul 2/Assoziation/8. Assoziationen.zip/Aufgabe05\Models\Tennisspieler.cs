﻿namespace Aufgabe05.Models
{
    public class Tennisspieler
    {
        private Tennisspieler _verfolger;

        private string _name;
        private int _alter;

        public Tennisspieler(string name, int alter)
        {
            _name = name;
            _alter = alter;
        }

        public Tennisspieler(string name, int alter, Tennisspieler verfolger)
        {
            _name = name;
            _alter = alter;
            _verfolger = verfolger;
        }

        public bool IstLetzer()
        {
            return _verfolger == null;
        }

        public void Ausgabe()
        {
            Console.WriteLine($"Name {_name} Alter {_alter}");
        }

        public int AltersDifferenzBerechnen(Tennisspieler tennisspieler)
        {
            //if(_alter > tennisspieler._alter)
            //{
            //    return _alter - tennisspieler._alter;
            //} else
            //{
            //    return tennisspieler._alter - _alter;
            //}

            return Math.Abs(_alter - tennisspieler._alter);
        }

        public int GetAlter()
        {
            return _alter;
        }

        public string GetName()
        {
            return _name;
        }

        public Tennisspieler GetVerfolger()
        {
            return _verfolger;
        }
    }
}