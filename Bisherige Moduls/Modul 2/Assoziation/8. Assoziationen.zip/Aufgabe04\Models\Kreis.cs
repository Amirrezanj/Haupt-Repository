﻿namespace Aufgabe04.Models
{
    public class Kreis
    {
        private double _radius;
        private Punkt _mittelpunkt;

        public Kreis(double radius, Punkt mittelpunkt)
        {
            _radius = radius;
            _mittelpunkt = mittelpunkt;
        }

        public double BerechneFläche()
        {
            return Math.PI * Math.Pow(_radius, 2);
        }

        public double BerechneUmfang()
        {
            return 2 * Math.PI * _radius;
        }
    }
}