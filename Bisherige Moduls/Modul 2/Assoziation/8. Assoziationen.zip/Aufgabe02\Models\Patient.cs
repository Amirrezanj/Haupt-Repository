﻿namespace Aufgabe02.Models
{
    public class Patient
    {
        private static int _fortlaufendeNummer = 1;

        private int _id;
        private string _name;
        private DateTime _birthdate;
        private Adresse _adresse;
        private Krankenkasse _krankenkasse;

        public Patient(string name, DateTime birthdate, Adresse adresse, Krankenkasse krankenkasse)
        {
            _id = _fortlaufendeNummer;
            _fortlaufendeNummer++;

            _name = name;
            _birthdate = birthdate;
            _adresse = adresse;
            _krankenkasse = krankenkasse;
        }

        public int GetId()
        {
            return _id;
        }

        public void Ausgabe()
        {
            Console.WriteLine($"{nameof(_id)}{_id}{nameof(_name)}{_name}{nameof(_birthdate)}{_birthdate}");
            _adresse.Ausgabe();
            _krankenkasse.Ausgabe();
        }
    }
}