﻿namespace Aufgabe07.Models
{
    public class Wettbüro
    {
        private Rennen _rennen;
        private Wette[] _wetten = new Wette[10];
        private double _faktor;

        public Wettbüro(Rennen rennen, double faktor)
        {
            _rennen = rennen;
            _faktor = faktor;
        }

        // Nur solange noch nicht 10 Schnecken im Rennen sind. Sonst passiert nichts.
        public void WetteAnnehmen(string schneckenName, double wetteinsatz, string spieler)
        {
            for (int i = 0; i < _wetten.Length; i++)
            {
                if (_wetten[i] == null)
                {
                    _wetten[i] = new Wette(spieler, wetteinsatz, schneckenName);
                    break;
                }
            }
        }

        public void RennAblauf()
        {
            _rennen.Durchführen();
        }

        public string Ausgabe()
        {
            string wettbüro = $"Wettbüro: {_faktor}";
            string rennen = $"Rennen: {_rennen.Ausgabe()}";
            string wetten = string.Empty;

            foreach (Wette wette in _wetten)
            {
                if (wette != null)
                    wetten += wette.Ausgabe() + "\n";
            }

            return $"{wettbüro}\n{rennen}\n{wetten}";
        }
    }
}