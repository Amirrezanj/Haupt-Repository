﻿using Aufgabe06.Models;

namespace Aufgabe06
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            EntryQueue queue = new EntryQueue();
            queue.Enqueue("Hallo");
            queue.Enqueue("Peter");
            queue.Enqueue("Bauer");
            queue.Enqueue("Wie");

            queue.Print();

            string data = queue.Dequeue();
            Console.WriteLine("DATEN: " + data);

            queue.Print();
        }
    }
}