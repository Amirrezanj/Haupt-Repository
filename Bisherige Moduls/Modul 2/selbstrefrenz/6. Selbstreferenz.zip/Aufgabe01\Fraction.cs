﻿namespace Aufgabe01
{
    public class Fraction
    {
        private int _numerator;
        private int _denominator;

        public Fraction(int numerator) : this(numerator, 1)
        {
        }

        public Fraction(int numerator, int denominator)
        {
            _numerator = numerator;
            _denominator = denominator;
        }

        public Fraction Shorten()
        {
            int ggt = CalculateGGT(_numerator, _denominator);
            return new Fraction(_numerator / ggt, _denominator / ggt);
        }

        public Fraction GetReverseValue()
        {
            return new Fraction(_denominator, _numerator);
        }

        public Fraction Add(Fraction other)
        {
            Fraction result = Copy();
            other = other.Copy();
            CalculateCommonDenominators(result, other);
            result._numerator += other._numerator;
            result = result.Shorten();
            return result;
        }

        public Fraction Subtract(Fraction other)
        {
            Fraction result = Copy();
            other = other.Copy();
            CalculateCommonDenominators(result, other);
            result._numerator -= other._numerator;
            result = result.Shorten();
            return result;
        }

        public Fraction Multiply(Fraction other)
        {
            Fraction result = new Fraction(_numerator * other._numerator, _denominator * other._denominator);
            result = result.Shorten();
            return result;
        }

        public Fraction Devide(Fraction other)
        {
            Fraction reversedOther = other.GetReverseValue();
            return Multiply(reversedOther);
        }

        public string Output()
        {
            return $"{_numerator} / {_denominator}";
        }

        private Fraction Copy()
        {
            return new Fraction(_numerator, _denominator);
        }

        private static int CalculateGGT(int a, int b)
        {
            if (b == 0)
                return a;

            return CalculateGGT(b, a % b);
        }

        private static void CalculateCommonDenominators(Fraction a, Fraction b)
        {
            if (a._denominator != b._denominator)
            {
                int temp = a._denominator;
                a._numerator *= b._denominator;
                b._numerator *= a._denominator;
                a._denominator *= b._denominator;
                b._denominator *= temp;
            }
        }
    }
}