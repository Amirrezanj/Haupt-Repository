﻿namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Fraction fraction = new Fraction(5, 10);
            Console.WriteLine($"Fraction: {fraction.Output()}");
            fraction = fraction.Shorten();
            Console.WriteLine($"Shorten: {fraction.Output()}");
            fraction = fraction.GetReverseValue();
            Console.WriteLine($"GetReverseValue: {fraction.Output()}");
            fraction = fraction.Add(new Fraction(5, 10));
            Console.WriteLine($"Add: {fraction.Output()}");
            fraction = fraction.Subtract(new Fraction(1, 2));
            Console.WriteLine($"Subtract: {fraction.Output()}");
            fraction = fraction.Multiply(new Fraction(1, 2));
            Console.WriteLine($"Multiply: {fraction.Output()}");
            fraction = fraction.Devide(new Fraction(4, 2));
            Console.WriteLine($"Devide: {fraction.Output()}");
        }
    }
}