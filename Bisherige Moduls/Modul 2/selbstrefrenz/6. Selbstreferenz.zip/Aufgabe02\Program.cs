﻿namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Validate as String");

            string number = "156766644";

            if (Prüfsumme.CheckIdentNumber(number))
            {
                Console.WriteLine($"Number {number} is valid");
            }
            else
            {
                Console.WriteLine($"Number {number} is invalid");
            }

            Console.WriteLine("Validate as Array");

            int[] arr = { 1, 5, 6, 7, 6, 6, 6, 4, 4 };

            if (Prüfsumme.CheckIdentNumber(arr))
            {
                Console.WriteLine($"Number {number} is valid");
            }
            else
            {
                Console.WriteLine($"Number {number} is invalid");
            }
        }
    }
}