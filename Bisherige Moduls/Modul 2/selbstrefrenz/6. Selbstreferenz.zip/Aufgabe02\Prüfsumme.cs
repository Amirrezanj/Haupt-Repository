﻿namespace Aufgabe02
{
    public static class Prüfsumme
    {
        public static bool CheckIdentNumber(int[] number)
        {
            int[] splitNumber = new int[number.Length];

            for (int i = 0; i < number.Length; i++)
            {
                int currentIndex = number.Length - i - 1;

                if (i % 2 != 0)
                {
                    int newNumber = number[currentIndex] * 2;

                    if (newNumber > 9)
                    {
                        int temp = 0;

                        do
                        {
                            temp += newNumber % 10;
                            newNumber /= 10;
                        } while (newNumber > 0);

                        newNumber = temp;
                    }

                    splitNumber[currentIndex] = newNumber;
                }
                else
                {
                    splitNumber[currentIndex] = number[currentIndex];
                }
            }

            int sum = 0;

            foreach (int value in splitNumber)
            {
                sum += value;
            }

            return sum % 10 == 0;
        }

        public static bool CheckIdentNumber(string number)
        {
            if (string.IsNullOrWhiteSpace(number))
                return false;

            int[] arr = new int[number.Length];

            for (int i = 0; i < number.Length; i++)
            {
                if (!char.IsDigit(number[i]))
                    return false;

                arr[i] = number[i] - '0';
            }

            return CheckIdentNumber(arr);
        }
    }
}