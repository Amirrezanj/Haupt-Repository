﻿namespace Aufgabe01
{
    public class Player
    {
        private static Random _random = new Random();
        private static int _numberOfThrows = 5;

        private string _name;
        private int _score;

        public Player(string name)
        {
            _name = name;
        }

        public int[] Gamble()
        {
            int[] würfe = new int[_numberOfThrows];

            for (int i = 0; i < _numberOfThrows; i++)
            {
                int randomNumber = _random.Next(1, 7);
                würfe[i] = randomNumber;
                _score += randomNumber;
            }

            return würfe;
        }

        public string GetName()
        {
            return _name;
        }

        public int GetScore()
        {
            return _score;
        }
    }
}