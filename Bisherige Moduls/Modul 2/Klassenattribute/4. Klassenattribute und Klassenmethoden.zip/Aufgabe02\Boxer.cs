﻿namespace Aufgabe02
{
    public class Boxer
    {
        private static Random _random = new Random();
        private string _name;
        private int _vitality;

        public Boxer(string name)
        {
            _name = name;
            _vitality = 100;
        }

        public Boxer(string name, int vitality)
        {
            _name = name;
            _vitality = vitality;
        }

        public bool Hit(Boxer boxer)
        {
            if (_random.Next(1, 3) == 1)
            {
                boxer._vitality -= 10;
                return true;
            }

            return false;
        }

        public string GetName()
        {
            return _name;
        }

        public bool IsKo()
        {
            return _vitality <= 0;
        }
    }
}