﻿namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Player player1 = new Player("Peter");
            Player player2 = new Player("Hans");

            Console.WriteLine($"{player1.GetName()} würfelt");
            int[] zahlen = player1.Gamble();

            foreach (int zahl in zahlen)
            {
                Console.WriteLine($"{player1.GetName()} hat eine {zahl} gewürfelt");
            }

            int player1Score = player1.GetScore();
            Console.WriteLine($"{player1.GetName()} hat insgesamt {player1Score} gewürfelt");

            Console.WriteLine($"{player2.GetName()} würfelt");

            zahlen = player2.Gamble();

            foreach (int zahl in zahlen)
            {
                Console.WriteLine($"{player2.GetName()} hat eine {zahl} gewürfelt");
            }

            int player2Score = player2.GetScore();
            Console.WriteLine($"{player2.GetName()} hat insgesamt {player2Score} gewürfelt");

            if (player1Score > player2Score)
            {
                Console.WriteLine($"{player1.GetName()} hat gewonnen");
            }
            else if (player2Score > player1Score)
            {
                Console.WriteLine($"{player2.GetName()} hat gewonnen");
            }
            else
            {
                Console.WriteLine("Unentschieden");
            }
        }
    }
}