﻿namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Boxer boxer1 = new Boxer("Peter");
            Boxer boxer2 = new Boxer("Franz");
            bool success = false;

            while (true)
            {
                success = boxer1.Hit(boxer2);

                if (success)
                {
                    Console.WriteLine($"{boxer1.GetName()} boxt {boxer2.GetName()}");
                }
                else
                {
                    Console.WriteLine($"{boxer1.GetName()} hat {boxer2.GetName()} verfehlt");
                }

                if (boxer2.IsKo())
                {
                    Console.WriteLine($"{boxer2.GetName()} ist KO");
                    break;
                }

                success = boxer2.Hit(boxer1);

                if (success)
                {
                    Console.WriteLine($"{boxer2.GetName()} boxt {boxer1.GetName()}");
                }
                else
                {
                    Console.WriteLine($"{boxer2.GetName()} hat {boxer1.GetName()} verfehlt");
                }

                if (boxer1.IsKo())
                {
                    Console.WriteLine($"{boxer1.GetName()} ist KO");
                    break;
                }
            }
        }
    }
}