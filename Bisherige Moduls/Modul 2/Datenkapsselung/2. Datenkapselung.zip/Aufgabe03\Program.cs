﻿namespace Aufgabe03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Radio radio = new Radio();
            Console.WriteLine(radio.GetRadioInfo());
            radio.Einschalten();
            radio.Lauter();
            radio.Lauter();
            Console.WriteLine(radio.GetRadioInfo());
            radio.WähleSender(101.5);
            Console.WriteLine(radio.GetRadioInfo());
        }
    }
}