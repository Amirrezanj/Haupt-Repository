﻿namespace Aufgabe01
{
    public class Socke
    {
        private string _farbe = "Weiß";
        private bool _trocken = true;
        private bool _sauber = false;

        public void Wasche()
        {
            _sauber = true;
            _trocken = false;
        }

        public void Trockne()
        {
            _trocken = true;
        }

        public void Ausgabe()
        {
            if (_trocken && _sauber)
            {
                Console.WriteLine($"Die Socke mit der Farbe {_farbe} ist trocken und sauber");
            }
            else if (!_trocken && _sauber)
            {
                Console.WriteLine($"Die Socke mit der Farbe {_farbe} ist nass und sauber");
            }
            else if (_trocken && !_sauber)
            {
                Console.WriteLine($"Die Socke mit der Farbe {_farbe} ist trocken und dreckig");
            }
            else
            {
                Console.WriteLine($"Die Socke mit der Farbe {_farbe} ist nass und dreckig");
            }
        }

        public void SetFarbe(string farbe)
        {
            _farbe = farbe;
        }
    }
}