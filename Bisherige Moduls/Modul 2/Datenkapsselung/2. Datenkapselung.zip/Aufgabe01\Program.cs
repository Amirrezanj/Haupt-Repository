﻿namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Socke socke = new Socke();
            socke.SetFarbe("Rot");
            socke.Ausgabe();
            socke.Wasche();
            socke.Ausgabe();
            socke.Trockne();
            socke.Ausgabe();

            Socke socke1 = new Socke();
            socke1.SetFarbe("Grün");

            Socke socke2 = new Socke();
            socke2.SetFarbe("Blau");

            Socke socke3 = socke2;
        }
    }
}