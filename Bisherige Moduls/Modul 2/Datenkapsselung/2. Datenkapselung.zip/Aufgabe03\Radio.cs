﻿using System.Globalization;

namespace Aufgabe03
{
    public class Radio
    {
        private int _lautstärke = 50;
        private double _frequenz = 100;
        private bool _eingeschaltet;

        public void Einschalten()
        {
            _eingeschaltet = true;
            Console.WriteLine("Radio an");
        }

        public void Ausschalten()
        {
            _eingeschaltet = false;
            Console.WriteLine("Radio aus");
        }

        public void Leiser()
        {
            if (_lautstärke >= 1)
            {
                _lautstärke -= 1;
            }
        }

        public void Lauter()
        {
            if (_lautstärke <= 99)
            {
                _lautstärke += 1;
            }
        }

        public bool IstAn()
        {
            return _eingeschaltet;
        }

        public void WähleSender(double frequenz)
        {
            if (frequenz >= 87.5 && frequenz <= 108)
                _frequenz = frequenz;
        }

        public string GetRadioInfo()
        {
            if (_eingeschaltet)
            {
                return $"Radio an: Frequenz={_frequenz.ToString(CultureInfo.InvariantCulture)}, Lautstärke={_lautstärke}";
            }
            else
            {
                return "Radio aus";
            }
        }
    }
}