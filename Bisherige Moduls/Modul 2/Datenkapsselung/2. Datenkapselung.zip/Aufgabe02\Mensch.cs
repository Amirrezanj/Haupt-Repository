﻿namespace Aufgabe02
{
    public class Mensch
    {
        private string _name = string.Empty;
        private int _alter;

        public string GetName()
        {
            return _name;
        }

        public void SetName(string name)
        {
            _name = name;
        }

        public int GetAlter()
        {
            return _alter;
        }

        public void SetAlter(int alter)
        {
            _alter = alter;
        }

        public void Geburtstag()
        {
            _alter++;
        }

        public void Vorstellen()
        {
            Console.WriteLine($"Hallo ich bin {_name} und bin {_alter} alt");
        }
    }
}