﻿namespace Aufgabe04
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Filiale filiale = new Filiale();
            filiale.SetName("Netto");
            filiale.SetWarenbestand(50);
            filiale.SetKasse(30);
            filiale.Ausgabe();
            filiale.Einkaufen();
            filiale.Einkaufen();
            filiale.Ausgabe();
            filiale.Verkaufen();
            filiale.Ausgabe();
        }
    }
}