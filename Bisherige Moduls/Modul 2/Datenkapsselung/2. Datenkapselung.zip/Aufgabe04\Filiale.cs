﻿namespace Aufgabe04
{
    public class Filiale
    {
        private int _minNameLength = 5;
        private int _maxNameLength = 100;

        private string _name = string.Empty;
        private int _kasse;
        private int _warenbestand;

        public void SetName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return;

            if (name.Length < _minNameLength)
                return;

            if (name.Length > _maxNameLength)
                return;

            _name = name;
        }

        public void SetKasse(int kasse)
        {
            _kasse = kasse;
        }

        public void SetWarenbestand(int warenbestand)
        {
            _warenbestand = warenbestand;
        }

        public void Einkaufen()
        {
            if (_kasse >= 10)
            {
                _warenbestand += 1;
                _kasse -= 10;
            }
        }

        public void Verkaufen()
        {
            if (_warenbestand >= 1)
            {
                _warenbestand -= 1;
                _kasse += 20;
            }
        }

        public void Ausgabe()
        {
            Console.WriteLine($"Die Filiale mit dem Namen {_name} hat einen Warenbestand von {_warenbestand} und hat {_kasse} Euro in der Kasse");
        }
    }
}