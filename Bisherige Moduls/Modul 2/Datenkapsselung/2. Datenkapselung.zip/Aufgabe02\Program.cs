﻿namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Mensch mensch = new Mensch();
            mensch.SetAlter(15);
            mensch.SetName("Peter");
            mensch.Vorstellen();
            mensch.Geburtstag();
            mensch.Vorstellen();
        }
    }
}