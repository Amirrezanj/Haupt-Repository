﻿namespace Aufgabe02
{
	internal delegate bool VergleichsHandler(int x, int y);

	internal class Program
	{
		private static void Main(string[] args)
		{
			Random random = new Random();
			int[] arr = new int[25];

			for (int i = 0; i < arr.Length; i++)
			{
				arr[i] = random.Next(0, 101);
				Console.Write(arr[i] + " ");
			}
			Console.WriteLine();

			int index = GetLimit(IstGrösser, arr);
			Console.WriteLine("Index ist: " + index);
		}

		private static int GetLimit(VergleichsHandler handler, int[] arr)
		{
			if (arr == null || arr.Length == 0)
				return -1;

			int index = 0;

			for (int i = 1; i < arr.Length; i++)
			{
				if (handler(arr[i], arr[index]))
				{
					index = i;
				}
			}

			return index;
		}

		private static bool IstKleiner(int a, int b)
		{
			return a < b;
		}

		private static bool IstGrösser(int a, int b)
		{
			return a > b;
		}
	}
}