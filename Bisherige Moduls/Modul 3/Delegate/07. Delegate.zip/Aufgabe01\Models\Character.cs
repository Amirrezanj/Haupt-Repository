﻿namespace Aufgabe01.Models
{
	internal static class Character
	{
		public static void UpperCase(string s)
		{
			Console.WriteLine(s.ToUpper());
		}

		public static void LowerCase(string s)
		{
			Console.WriteLine(s.ToLower());
		}

		public static void UpperLower(string s)
		{
			Console.WriteLine(s);
		}
	}
}