﻿using Aufgabe01.Models;

namespace Aufgabe01
{
	internal delegate void CharacterHandle(string s);

	internal class Program
	{
		private static void Main(string[] args)
		{
			CharacterHandle toLower = Character.LowerCase;
			CharacterHandle toUpper = Character.UpperCase;
			CharacterHandle upperLower = Character.UpperLower;

			toLower("Hallo");
			toUpper("Hallo");
			upperLower("Hallo");

			Console.WriteLine();

			CharacterHandle multicastDelegate = toLower;
			multicastDelegate += toUpper;
			multicastDelegate += upperLower;
			multicastDelegate("PeTeR");

			Console.WriteLine();

			var arr = multicastDelegate.GetInvocationList();

			foreach (var item in arr)
			{
				Console.WriteLine(item.Method.Name);
			}

			Console.WriteLine();

			multicastDelegate += delegate (string s)
			{
				Console.WriteLine("Anonyme Methode: Wert: " + s);
			};

			Console.WriteLine();

			multicastDelegate("FrAnZ");
		}
	}
}