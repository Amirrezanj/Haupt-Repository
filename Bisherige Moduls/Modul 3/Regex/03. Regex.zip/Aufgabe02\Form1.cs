using System.Text.RegularExpressions;

namespace Aufgabe02
{
    public partial class Form1 : Form
    {
        private Regex _anwendernameRegex;
        private Regex _emailRegex;
        private Regex _telefonRegex;
        private Regex _ipv4AdresseRegex;

        public Form1()
        {
            InitializeComponent();
            _anwendernameRegex = new Regex(@"^[^@#!$&\s]+$");
            _emailRegex = new Regex(@"^[a-zA-Z0-9\.-]+\.?[a-zA-Z0-9\.-]+@[a-zA-Z0-9\.-]+\.[a-zA-Z]+$");
            _telefonRegex = new Regex(@"^\+\d{1,2}\s\d{3,4}\s\d{4,8}$");
            _ipv4AdresseRegex = new Regex(@"^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!_anwendernameRegex.IsMatch(textBox1.Text))
            {
                MessageBox.Show("Anwendername ist ung�ltig");
                return;
            }

            if (!_emailRegex.IsMatch(textBox2.Text))
            {
                MessageBox.Show("Email ist ung�ltig");
                return;
            }

            if (!_telefonRegex.IsMatch(textBox3.Text))
            {
                MessageBox.Show("Telefonnummer ist ung�ltig");
                return;
            }

            if (!_ipv4AdresseRegex.IsMatch(textBox4.Text))
            {
                MessageBox.Show("IPv4-Adresse ist ung�ltig");
                return;
            }

            MessageBox.Show("Alles ist g�ltig");
        }
    }
}