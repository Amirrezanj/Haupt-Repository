﻿using System.Text.RegularExpressions;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "Froschkönig Unix Zeilenumbrüche.txt");
            string text = File.ReadAllText(filePath);
            Aufgabe1(text);
            Aufgabe2(text);
            Aufgabe3(text);
            Aufgabe4(text);
            Aufgabe5(text);
            Aufgabe6(text);
            Aufgabe7(text);
            Aufgabe8(text);
            Aufgabe9(text);
        }

        private static void Aufgabe1(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^.*[äöüÄÖÜ]+.*$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }

        private static void Aufgabe2(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^.*\sder\s.*$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }

        private static void Aufgabe3(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^[A-Z].*$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }

        private static void Aufgabe4(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^.*(Frosch|Froschkönig).*$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }

        private static void Aufgabe5(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^.*\.$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }

        private static void Aufgabe6(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^.*ß[^0-9a-zA-ZäÄöÖüÜ].*$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }

        private static void Aufgabe7(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^\s*$", RegexOptions.Multiline);

            Console.WriteLine(matches.Count);
        }

        private static void Aufgabe8(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^[a-zA-zäöüÄÖÜß]{3}\s.*$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }

        private static void Aufgabe9(string text)
        {
            MatchCollection matches = Regex.Matches(text, @"^.*\b(der|die|das)\b.*$", RegexOptions.Multiline);

            for (int i = 0; i < matches.Count; i++)
            {
                Console.WriteLine(matches[i]);
            }
        }
    }
}