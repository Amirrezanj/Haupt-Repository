﻿using System.Text.RegularExpressions;

namespace Aufgabe03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Kennzeichen eingeben (Format: (A - A 1) - (ZZZ - ZZ 9999)");
            string kennzeichen = Console.ReadLine()!;

            if (Regex.IsMatch(kennzeichen, @"^[A-Z]{1,3}\s-\s[A-Z]{1,2}\s\d{1,4}$"))
            {
                Console.WriteLine("Gültiges Kennzeichen");
            }
            else
            {
                Console.WriteLine("Ungültiges Kennzeichen");
            }
        }
    }
}