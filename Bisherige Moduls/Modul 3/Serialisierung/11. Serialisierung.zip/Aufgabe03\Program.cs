﻿using Newtonsoft.Json;

namespace Aufgabe03
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			string path = "C:\\Windows";

			List<CustomDirInfo> customDirInfos = new List<CustomDirInfo>();
			DirectoryInfo dir = new DirectoryInfo(path);

			AddInfosRecursive(customDirInfos, dir);

			string json = JsonConvert.SerializeObject(customDirInfos, Formatting.Indented);

			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			string filePath = Path.Combine(folderPath, "folder.json");

			File.WriteAllText(filePath, json);

			string readJson = File.ReadAllText(filePath);

			List<CustomDirInfo>? deserializedCustomDirInfos = JsonConvert.DeserializeObject<List<CustomDirInfo>>(readJson);

			foreach (var x in deserializedCustomDirInfos ?? Enumerable.Empty<CustomDirInfo>())
			{
				Console.WriteLine(x);
			}
		}

		private static void AddInfosRecursive(List<CustomDirInfo> customDirInfos, DirectoryInfo dir)
		{
			try
			{
				var files = dir.EnumerateFiles();

				CustomDirInfo customDirInfo = new CustomDirInfo
				{
					Name = dir.FullName,
					CreationDate = dir.CreationTime,
					NumberOfFiles = files.Count()
				};

				customDirInfos.Add(customDirInfo);

				foreach (var folder in dir.EnumerateDirectories())
				{
					AddInfosRecursive(customDirInfos, folder);
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	public class CustomDirInfo
	{
		public string Name { get; set; }
		public DateTime CreationDate { get; set; }
		public int NumberOfFiles { get; set; }

		public override string ToString()
		{
			return $"{Name} Angelegt am: {CreationDate} Anzahl der Dateien: {NumberOfFiles}";
		}
	}
}