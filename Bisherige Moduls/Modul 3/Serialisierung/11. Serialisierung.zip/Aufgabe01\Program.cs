﻿using System.Xml.Serialization;

namespace Aufgabe01
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			var folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			var filePath = Path.Combine(folderPath, "11. books.xml");

			XmlSerializer serializer = new XmlSerializer(typeof(Books));
			using StreamReader reader = new StreamReader(filePath);
			Books? books = (Books?)serializer.Deserialize(reader);
		}
	}

	[XmlRoot(ElementName = "Publisher")]
	public class Publisher
	{
		[XmlAttribute(AttributeName = "name")]
		public string Name { get; set; }

		[XmlAttribute(AttributeName = "year")]
		public int Year { get; set; }
	}

	[XmlRoot(ElementName = "Price")]
	public class Price
	{
		[XmlAttribute(AttributeName = "currency")]
		public string Currency { get; set; }

		[XmlText]
		public double Text { get; set; }
	}

	[XmlRoot(ElementName = "Tags")]
	public class Tags
	{
		[XmlElement(ElementName = "Tag")]
		public List<string> Tag { get; set; }
	}

	[XmlRoot(ElementName = "Review")]
	public class Review
	{
		[XmlAttribute(AttributeName = "rating")]
		public int Rating { get; set; }

		[XmlAttribute(AttributeName = "comment")]
		public string Comment { get; set; }
	}

	[XmlRoot(ElementName = "Reviews")]
	public class Reviews
	{
		[XmlElement(ElementName = "Review")]
		public List<Review> Review { get; set; }
	}

	[XmlRoot(ElementName = "Book")]
	public class Book
	{
		[XmlAttribute(AttributeName = "id")]
		public int Id { get; set; }

		[XmlAttribute(AttributeName = "title")]
		public string Title { get; set; }

		[XmlAttribute(AttributeName = "author")]
		public string Author { get; set; }

		[XmlElement(ElementName = "Publisher")]
		public Publisher Publisher { get; set; }

		[XmlElement(ElementName = "ISBN")]
		public double ISBN { get; set; }

		[XmlElement(ElementName = "Price")]
		public Price Price { get; set; }

		[XmlElement(ElementName = "Tags")]
		public Tags Tags { get; set; }

		[XmlElement(ElementName = "Reviews")]
		public Reviews Reviews { get; set; }
	}

	[XmlRoot(ElementName = "Books")]
	public class Books
	{
		[XmlElement(ElementName = "Book")]
		public List<Book> Book { get; set; }
	}
}