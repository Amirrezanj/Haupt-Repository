﻿using Newtonsoft.Json;

namespace Aufgabe02
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			string filePath = Path.Combine(folderPath, "11. car.json");

			string json = File.ReadAllText(filePath);

			Car? car = JsonConvert.DeserializeObject<Car>(json);
		}
	}

	public class Address
	{
		[JsonProperty("Street")]
		public string Street { get; set; }

		[JsonProperty("City")]
		public string City { get; set; }

		[JsonProperty("ZipCode")]
		public string ZipCode { get; set; }
	}

	public class Engine
	{
		[JsonProperty("Name")]
		public string Name { get; set; }

		[JsonProperty("Power")]
		public int Power { get; set; }

		[JsonProperty("Torque")]
		public int Torque { get; set; }
	}

	public class Hobby
	{
		[JsonProperty("Name")]
		public string Name { get; set; }

		[JsonProperty("Description")]
		public string Description { get; set; }
	}

	public class Passenger
	{
		[JsonProperty("Name")]
		public string Name { get; set; }

		[JsonProperty("Age")]
		public int Age { get; set; }

		[JsonProperty("Address")]
		public Address Address { get; set; }

		[JsonProperty("Hobbies")]
		public List<Hobby> Hobbies { get; set; }
	}

	public class Car
	{
		[JsonProperty("Name")]
		public string Name { get; set; }

		[JsonProperty("Model")]
		public string Model { get; set; }

		[JsonProperty("Year")]
		public int Year { get; set; }

		[JsonProperty("Engine")]
		public Engine Engine { get; set; }

		[JsonProperty("Passengers")]
		public List<Passenger> Passengers { get; set; }
	}
}