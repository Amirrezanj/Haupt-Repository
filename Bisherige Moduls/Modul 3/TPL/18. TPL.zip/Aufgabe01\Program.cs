﻿using System.Collections.Concurrent;

namespace Aufgabe01
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			Console.Write("Verzeichnis: ");
			string directoryPath = Console.ReadLine()!;

			Console.Write("Suchstring: ");
			string searchString = Console.ReadLine()!;

			var foundFiles = new ConcurrentStack<string>();

			var files = Directory.EnumerateFiles(directoryPath);

			Parallel.ForEach(files, file =>
			{
				string fileContent = File.ReadAllText(file);

				if (fileContent.Contains(searchString))
				{
					foundFiles.Push(file);
				}
			});

			foreach (var file in foundFiles.Reverse())
			{
				Console.WriteLine(file);
			}

			foundFiles.Clear();
		}
	}
}