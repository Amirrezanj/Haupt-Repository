﻿namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "output.txt");
            string text = File.ReadAllText(path);
            string newText = text.Replace(Environment.NewLine, " ");

            string[] words = newText.Split(' ');

            Dictionary<string, int> dictionary = new Dictionary<string, int>();

            foreach (string word in words)
            {
                if (dictionary.ContainsKey(word))
                    dictionary[word]++;
                else
                    dictionary.Add(word, 1);
            }

            foreach (var word in dictionary)
            {
                Console.WriteLine($"Das Wort: {word.Key} kommt {word.Value} mal vor");
            }
        }
    }
}