﻿using Faker;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Queue<string> queue = new Queue<string>();

            for (int i = 0; i < 10; i++)
            {
                queue.Enqueue(Lorem.Sentence());
            }

            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "output.txt");

            foreach (var s in queue)
            {
                File.AppendAllText(path, s + Environment.NewLine);
            }

            Console.WriteLine("Datei erfolgreich geschrieben");
        }
    }
}