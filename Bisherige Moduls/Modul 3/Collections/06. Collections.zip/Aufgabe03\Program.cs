﻿namespace Aufgabe03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //Console.Write("Mathematischen Ausdruck eingeben: ");
            string expression = "(3 + 6) * ((7 – 4) * 9)"; //Console.ReadLine()!;

            if (CheckBrackets(expression))
            {
                Console.WriteLine("Der Ausdruck ist korrekt geklammert");
            }
            else
            {
                Console.WriteLine("Der Ausdruck ist nicht korrekt geklammert");
            }
        }

        private static bool CheckBrackets(string expression)
        {
            Stack<char> st = new Stack<char>();

            for (int i = 0; i < expression.Length; i++)
            {
                if (expression[i] == '{' || expression[i] == '(' || expression[i] == '[')
                    st.Push(expression[i]);

                if (expression[i] == '}' || expression[i] == ')' || expression[i] == ']')
                {
                    if (st.Count == 0)
                    {
                        return false;
                    }
                    else if (!IsMatchingPair(st.Pop(), expression[i]))
                    {
                        return false;
                    }
                }
            }

            if (st.Count == 0)
                return true;

            return false;
        }

        private static bool IsMatchingPair(char character1, char character2)
        {
            if (character1 == '(' && character2 == ')')
                return true;
            else if (character1 == '{' && character2 == '}')
                return true;
            else if (character1 == '[' && character2 == ']')
                return true;
            else
                return false;
        }
    }
}