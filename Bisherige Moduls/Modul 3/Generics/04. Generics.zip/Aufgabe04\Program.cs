﻿using Aufgabe04.Models;

namespace Aufgabe04
{
    internal class Program
    {
        private static void Main()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();

            int[] values = [50, 100, 25, 1, 10, 75, 75, 65, 85, 61, 45, 35, 15, 10];

            foreach (int value in values)
            {
                bst.Insert(value);
            }

            Console.WriteLine("Inorder traversal:");
            bst.PrintInorder();
            Console.WriteLine();

            Console.WriteLine($"Contains 10: {bst.Contains(10)}");
            Console.WriteLine($"Contains 20: {bst.Contains(20)}");

            bst.Delete(25);
            Console.WriteLine("Nach Entfernung von 25:");
            bst.PrintInorder();
        }
    }
}