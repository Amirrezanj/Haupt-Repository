﻿using Aufgabe04.Abstractions;

namespace Aufgabe04.Models
{
    public class BinarySearchTree<T> : IBinaryTree<T> where T : IComparable<T>
    {
        public BinaryTreeNode<T>? Root { get; private set; }

        public void Clear()
        {
            Root = null;
        }

        public void Insert(T value)
        {
            if (Root == null)
            {
                Root = new BinaryTreeNode<T>(value);
            }
            else
            {
                InsertRecursive(Root, value);
            }
        }

        public void Delete(T value)
        {
            Root = DeleteRecursive(Root, value);
        }

        public bool Contains(T value)
        {
            return Search(value) != null;
        }

        public BinaryTreeNode<T>? Search(T value)
        {
            return SearchRecursive(Root, value);
        }

        public void PrintInorder()
        {
            PrintInorderRecursive(Root);
        }

        private static void InsertRecursive(BinaryTreeNode<T> node, T value)
        {
            if (value.CompareTo(node.Data) < 0)
            {
                if (node.Left == null)
                {
                    node.Left = new BinaryTreeNode<T>(value);
                }
                else
                {
                    InsertRecursive(node.Left, value);
                }
            }
            else if (value.CompareTo(node.Data) > 0)
            {
                if (node.Right == null)
                {
                    node.Right = new BinaryTreeNode<T>(value);
                }
                else
                {
                    InsertRecursive(node.Right, value);
                }
            }
        }

        private static BinaryTreeNode<T>? DeleteRecursive(BinaryTreeNode<T>? node, T value)
        {
            if (node == null)
                return node;

            int comparison = value.CompareTo(node.Data);

            if (comparison < 0)
            {
                node.Left = DeleteRecursive(node.Left, value);
            }
            else if (comparison > 0)
            {
                node.Right = DeleteRecursive(node.Right, value);
            }
            else
            {
                if (node.Left == null && node.Right == null)
                {
                    return null;
                }
                else if (node.Left == null)
                {
                    return node.Right;
                }
                else if (node.Right == null)
                {
                    return node.Left;
                }
                else
                {
                    BinaryTreeNode<T> temp = FindMin(node.Right);
                    node.Data = temp.Data;
                    node.Right = DeleteRecursive(node.Right, temp.Data);
                }
            }

            return node;
        }

        private static BinaryTreeNode<T> FindMin(BinaryTreeNode<T> node)
        {
            while (node.Left != null)
            {
                node = node.Left;
            }
            return node;
        }

        private static void PrintInorderRecursive(BinaryTreeNode<T>? node)
        {
            if (node != null)
            {
                PrintInorderRecursive(node.Left);
                Console.Write(node.Data + " ");
                PrintInorderRecursive(node.Right);
            }
        }

        private static BinaryTreeNode<T>? SearchRecursive(BinaryTreeNode<T>? node, T value)
        {
            if (node == null || node.Data.Equals(value))
            {
                return node;
            }

            int comparison = value.CompareTo(node.Data);

            if (comparison < 0)
            {
                return SearchRecursive(node.Left, value);
            }
            else
            {
                return SearchRecursive(node.Right, value);
            }
        }
    }
}