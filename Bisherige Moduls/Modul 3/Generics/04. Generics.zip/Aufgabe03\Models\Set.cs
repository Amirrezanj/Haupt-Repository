﻿namespace Aufgabe03.Models;

/// <summary>
/// Class that represents a Set of values where each value can only occure once
/// </summary>
/// <typeparam name="T"></typeparam>
public class Set<T> where T : IEquatable<T>
{
    private SetNode<T>? _head = null;
    public int Count { get; private set; }

    public void Add(T x)
    {
        if (Contains(x))
        {
            throw new InvalidOperationException($"Value {x} already exists in the Set");
        }

        if (_head is null)
        {
            var listNode = new SetNode<T>(x);
            _head = listNode;
        }
        else
        {
            var currentNode = _head;

            while (currentNode.Next != null)
            {
                currentNode = currentNode.Next;
            }

            var listNode = new SetNode<T>(x);
            currentNode.Next = listNode;
        }

        Count++;
    }

    public void Remove(T x)
    {
        SetNode<T>? prev = null, currentNode = null;
        currentNode = _head;

        while (currentNode != null)
        {
            if (currentNode.Data.Equals(x))
            {
                if (prev == null)
                {
                    _head = currentNode.Next;
                }
                else
                {
                    prev.Next = currentNode.Next;
                }

                Count--;
                break;
            }

            prev = currentNode;
            currentNode = currentNode.Next;
        }
    }

    public bool Contains(T x)
    {
        var currentNode = _head;

        while (currentNode != null)
        {
            if (currentNode.Data.Equals(x))
                return true;

            currentNode = currentNode.Next;
        }

        return false;
    }

    public T[] ToArray()
    {
        var array = new T[Count];

        var currentNode = _head;

        for (int i = 0; i < Count; i++)
        {
            if (currentNode == null)
                break;

            array[i] = currentNode.Data;
            currentNode = currentNode.Next;
        }

        return array;
    }

    public void PrintAllValues()
    {
        var currentNode = _head;

        while (currentNode != null)
        {
            Console.WriteLine(currentNode.Data);
            currentNode = currentNode.Next;
        }
    }

    /// <summary>
    /// Combines to instances of set into a new one, values that are doubled are ignored
    /// </summary>
    /// <param name="set1">The first list to be merged</param>
    /// <param name="set2">The second list to be merged</param>
    /// <returns>The merged Set</returns>
    public static Set<T> Combine(Set<T> set1, Set<T> set2)
    {
        var result = new Set<T>();

        var currentHead = set1._head;

        // Save values of set1 into result
        for (int i = 0; i < set1.Count; i++)
        {
            if (currentHead == null)
                break;

            result.Add(currentHead.Data);
            currentHead = currentHead.Next;
        }

        currentHead = set2._head;

        // Add values of set 2 to result that are currently not included
        for (int i = 0; i < set2.Count; i++)
        {
            if (currentHead == null)
                break;

            if (!result.Contains(currentHead.Data))
            {
                result.Add(currentHead.Data);
            }

            currentHead = currentHead.Next;
        }

        return result;
    }

    public static Set<T> Intersect(Set<T> set1, Set<T> set2)
    {
        var result = new Set<T>();

        var currentNode = set1._head;

        while (currentNode != null)
        {
            if (set2.Contains(currentNode.Data))
            {
                result.Add(currentNode.Data);
            }

            currentNode = currentNode.Next;
        }

        return result;
    }
}