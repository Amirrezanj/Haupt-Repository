﻿namespace Aufgabe01.Models;

internal class Bier : Getränk
{
    private string _brauerei;

    public Bier(string name, string brauerei) : base(name)
    {
        _brauerei = brauerei;
    }

    public string GetBrauerei()
    {
        return _brauerei;
    }

    public void PrintInformation()
    {
        Console.WriteLine($"Name: {Name} Brauerei: {_brauerei}");
    }
}