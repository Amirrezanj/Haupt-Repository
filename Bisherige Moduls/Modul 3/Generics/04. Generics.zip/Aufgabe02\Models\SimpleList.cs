﻿namespace Aufgabe02.Models;

public class SimpleList<T> where T : IEquatable<T>
{
    private SimpleListNode<T>? _head = null;
    public int Count { get; private set; }

    public void Add(T x)
    {
        if (_head is null)
        {
            var listNode = new SimpleListNode<T>(x);
            _head = listNode;
        }
        else
        {
            var currentNode = _head;

            while (currentNode.Next != null)
            {
                currentNode = currentNode.Next;
            }

            var listNode = new SimpleListNode<T>(x);
            currentNode.Next = listNode;
        }

        Count++;
    }

    public void Remove(T x)
    {
        SimpleListNode<T>? prev = null, currentNode = null;
        currentNode = _head;

        while (currentNode != null)
        {
            if (currentNode.Data.Equals(x))
            {
                if (prev == null)
                {
                    _head = currentNode.Next;
                }
                else
                {
                    prev.Next = currentNode.Next;
                }

                Count--;
                break;
            }

            prev = currentNode;
            currentNode = currentNode.Next;
        }
    }

    public bool Contains(T x)
    {
        var currentNode = _head;

        while (currentNode != null)
        {
            if (currentNode.Data.Equals(x))
                return true;

            currentNode = currentNode.Next;
        }

        return false;
    }

    public T[] ToArray()
    {
        var array = new T[Count];

        var currentNode = _head;

        for (int i = 0; i < Count; i++)
        {
            if (currentNode == null)
                break;

            array[i] = currentNode.Data;
            currentNode = currentNode.Next;
        }

        return array;
    }

    public void PrintAllValues()
    {
        var currentNode = _head;

        while (currentNode != null)
        {
            Console.WriteLine(currentNode.Data);
            currentNode = currentNode.Next;
        }
    }
}