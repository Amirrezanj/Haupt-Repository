﻿namespace Aufgabe01.Collections;

internal enum WeinArt
{
    Rotwein,
    Weißwein
}