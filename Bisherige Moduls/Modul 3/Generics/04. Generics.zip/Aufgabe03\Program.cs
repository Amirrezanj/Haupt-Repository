﻿using Aufgabe03.Models;

namespace Aufgabe03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Set<Person> set1 = new Set<Person>();
            set1.Add(new Person("Peter", 50));
            set1.Add(new Person("Lorenz", 51));
            set1.PrintAllValues();

            Console.WriteLine("-----");

            Set<Person> set2 = new Set<Person>();
            set2.Add(new Person("Hans", 56));
            set2.Add(new Person("Peter", 50));
            set2.Add(new Person("Franz", 25));
            set2.Add(new Person("Fritz", 18));
            set2.PrintAllValues();

            Console.WriteLine("-----");

            Set<Person> set3 = Set<Person>.Combine(set1, set2);
            set3.PrintAllValues();

            Console.WriteLine("-----");

            Set<Person> set4 = Set<Person>.Intersect(set1, set2);
            set4.PrintAllValues();
        }
    }
}