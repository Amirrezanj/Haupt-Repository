﻿using Aufgabe01.Collections;
using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Bier bier = new Bier("veltins", "veltins brauerei und co kg");
            Wein rotwein = new Wein("burgunder", "mosel", WeinArt.Rotwein);
            Wein weißwein = new Wein("chardonay", "pfalz", WeinArt.Weißwein);

            Flasche<Bier> flasche1 = new Flasche<Bier>();
            flasche1.Füllen(bier);
            flasche1.Inhalt?.GetBrauerei();

            Flasche<Wein> flasche2 = new Flasche<Wein>();
            flasche2.Füllen(rotwein);
            var x = flasche2.Inhalt?.Art;

            Flasche<Wein> flasche3 = new Flasche<Wein>();
            flasche3.Füllen(weißwein);
        }
    }
}