﻿using Aufgabe01.Collections;

namespace Aufgabe01.Models;

internal class Wein : Getränk
{
    private string _herkunft;
    public WeinArt Art { get; }

    public Wein(string name, string herkunft, WeinArt art) : base(name)
    {
        _herkunft = herkunft;
        Art = art;
    }

    public string GetHerkunft()
    {
        return _herkunft;
    }

    public void PrintInformation()
    {
        Console.WriteLine($"Name: {Name} Herkunft: {_herkunft} Art: {Art}");
    }
}