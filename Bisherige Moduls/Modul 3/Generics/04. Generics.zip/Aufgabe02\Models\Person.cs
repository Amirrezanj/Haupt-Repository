﻿namespace Aufgabe02.Models;

internal class Person : IEquatable<Person>
{
    public string Name { get; }
    public int Alter { get; }

    public Person(string name, int alter)
    {
        Name = name;
        Alter = alter;
    }

    public override string ToString()
    {
        return $"{Name} {Alter}";
    }

    public bool Equals(Person? other)
    {
        return Name == other?.Name && Alter == other?.Alter;
    }
}