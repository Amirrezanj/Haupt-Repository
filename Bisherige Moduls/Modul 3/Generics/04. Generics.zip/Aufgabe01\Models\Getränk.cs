﻿namespace Aufgabe01.Models;

internal abstract class Getränk
{
    public string Name { get; set; }

    public Getränk(string name)
    {
        Name = name;
    }
}