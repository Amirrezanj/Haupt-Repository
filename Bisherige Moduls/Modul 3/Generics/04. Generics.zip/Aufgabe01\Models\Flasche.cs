﻿namespace Aufgabe01.Models;

internal class Flasche<TGetränk> where TGetränk : Getränk
{
    public TGetränk? Inhalt { get; private set; }

    public bool IstLeer()
    {
        return Inhalt == null;
    }

    public void Füllen(TGetränk getränk)
    {
        Inhalt = getränk;
    }

    public TGetränk? Leeren()
    {
        TGetränk? getränk = Inhalt;
        Inhalt = null;
        return getränk;
    }
}