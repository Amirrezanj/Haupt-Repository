﻿namespace Aufgabe02.Models;

public class SimpleListNode<T>
{
    public T Data { get; }
    public SimpleListNode<T>? Next { get; set; } = null;

    public SimpleListNode(T data)
    {
        Data = data;
    }
}