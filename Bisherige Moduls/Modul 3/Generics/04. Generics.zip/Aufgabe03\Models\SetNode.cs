﻿namespace Aufgabe03.Models;

/// <summary>
/// Represents a single node in a Instance of Set"/>
/// </summary>
/// <typeparam name="T"></typeparam>
public class SetNode<T>
{
    /// <summary>
    /// The actual data stored in a single node of a Set instance
    /// </summary>
    public T Data { get; }

    /// <summary>
    /// The next node stored in a instance of a Set instance, can be null if no next node is available
    /// </summary>
    public SetNode<T>? Next { get; set; } = null;

    /// <summary>
    /// Creates a new Note with the specific value
    /// </summary>
    /// <param name="data"></param>
    public SetNode(T data)
    {
        Data = data;
    }
}