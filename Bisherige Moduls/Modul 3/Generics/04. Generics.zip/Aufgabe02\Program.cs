﻿using Aufgabe02.Models;

namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            SimpleList<Person> simpleList = new SimpleList<Person>();
            var person = new Person("Hans", 30);
            var person2 = new Person("Peter", 50);

            simpleList.Add(person);
            simpleList.Add(person2);
            simpleList.Add(new Person("Franz", 65));

            simpleList.PrintAllValues();
            Console.WriteLine("-----");
            Console.WriteLine(simpleList.Count);
            simpleList.Remove(person);
            Console.WriteLine("-----");
            simpleList.PrintAllValues();
            Console.WriteLine("-----");
            Console.WriteLine(simpleList.Count);
            Console.WriteLine("-----");
            if (simpleList.Contains(person2))
            {
                Console.WriteLine("Wert ist vorhanden");
            }
            else
            {
                Console.WriteLine("Wert ist nicht vorhanden");
            }

            Console.WriteLine("-----");
            Person[] arr = simpleList.ToArray();

            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }
}