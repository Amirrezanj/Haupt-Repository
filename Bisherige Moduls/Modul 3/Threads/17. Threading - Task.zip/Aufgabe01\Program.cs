﻿namespace Aufgabe01
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			var desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			var folderPath = Path.Combine(desktopPath, "Texte");
			List<Task> tasks = new List<Task>();

			foreach (var folder in Directory.EnumerateFiles(folderPath, "*.txt"))
			{
				tasks.Add(Task.Run(() => CountInFile(folder)));
			}

			Task.WaitAll(tasks.ToArray());

			Console.WriteLine("Fertig");
		}

		public static void CountInFile(string filePath)
		{
			FileInfo fileInfo = new FileInfo(filePath);
			string text = File.ReadAllText(fileInfo.FullName);

			Dictionary<char, int> map = new Dictionary<char, int>();

			foreach (var c in text)
			{
				if (map.ContainsKey(c))
				{
					map[c]++;
				}
				else
				{
					map.Add(c, 1);
				}
			}

			using FileStream stream = File.OpenWrite(Path.ChangeExtension(fileInfo.FullName, ".freq"));
			using StreamWriter writer = new StreamWriter(stream);

			foreach (var keyValuePair in map)
			{
				string line = $"Name {fileInfo.Name} Buchstabe: {keyValuePair.Key} Count: {keyValuePair.Value}";

				Console.WriteLine(line);
				writer.WriteLine(line);
			}
		}
	}
}