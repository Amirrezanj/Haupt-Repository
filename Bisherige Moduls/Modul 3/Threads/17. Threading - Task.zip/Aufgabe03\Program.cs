﻿namespace Aufgabe03
{
	internal class Program
	{
		private static void Main()
		{
			int min = 10;
			int max = 50;

			List<Task<long>> tasks = new List<Task<long>>();

			for (int i = min; i <= max; i++)
			{
				int index = i;
				tasks.Add(Task.Run(() => Fib(index)));
			}

			Task task = Task.WhenAll(tasks.ToArray());

			while (!task.IsCompleted)
			{
				Console.Write(".");
				Thread.Sleep(1000);
			}

			Console.WriteLine();

			foreach (var t in tasks)
			{
				Console.WriteLine(t.Result);
			}

			Console.ReadLine();
		}

		public static long Fib(long x)
		{
			return x <= 2 ? 1 : Fib(x - 1) + Fib(x - 2);
		}
	}
}