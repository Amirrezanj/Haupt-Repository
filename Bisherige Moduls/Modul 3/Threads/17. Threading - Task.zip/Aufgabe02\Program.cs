﻿using SkiaSharp;

namespace Aufgabe02
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			var desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			var folderPath = Path.Combine(desktopPath, "Bilder");
			FileSystemWatcher watcher = new FileSystemWatcher(folderPath);
			watcher.EnableRaisingEvents = true;
			watcher.Created += Watcher_Created;

			Console.ReadLine();
		}

		private static void Watcher_Created(object sender, FileSystemEventArgs e)
		{
			Task.Run(() =>
			{
				var bitmap = SKBitmap.Decode(e.FullPath);
				var rootPath = Path.GetDirectoryName(Path.GetDirectoryName(e.FullPath));
				var newFilePath = Path.Combine(rootPath, "GrauBilder", e.Name);

				ColorToGray(bitmap, newFilePath);
			});
		}

		private static void ColorToGray(SKBitmap image, string grayFilename)
		{
			for (int x = 0; x < image.Width; x++)
			{
				for (int y = 0; y < image.Height; y++)
				{
					SKColor color = image.GetPixel(x, y);
					byte gray = (byte)(0.2126f * color.Red + 0.7152f * color.Green + 0.0722f * color.Blue);
					SKColor sKColor = new SKColor(gray, gray, gray, color.Alpha);
					image.SetPixel(x, y, sKColor);
				}
			}

			try
			{
				using FileStream grayFileStream = File.Create(grayFilename);
				image.Encode(grayFileStream, SKEncodedImageFormat.Jpeg, 100);
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}

			image.Dispose();
		}
	}
}