﻿using Aufgabe02.Collections;

namespace Aufgabe02.Models;

public class Person
{
    public string Vorname { get; }
    public string Nachname { get; }
    public DateTime Geburtsdatum { get; }
    public Gender Geschlecht { get; }

    public Person(string vorname, string nachname, DateTime geb, Gender geschlecht)
    {
        if (string.IsNullOrWhiteSpace(vorname))
            throw new ArgumentException("Vorname darf nicht null oder leer sein.", nameof(vorname));

        if (string.IsNullOrWhiteSpace(nachname))
            throw new ArgumentException("Vorname darf nicht null oder leer sein.", nameof(nachname));

        if (geb == default)
            throw new ArgumentException("Geburtsdatum darf nicht leer sein.", nameof(geb));

        if (geb > DateTime.Now)
            throw new ArgumentException("Geburtsdatum darf nicht in der Zukunft liegen.", nameof(geb));

        Vorname = vorname;
        Nachname = nachname;
        Geburtsdatum = geb;
        Geschlecht = geschlecht;
    }
}
