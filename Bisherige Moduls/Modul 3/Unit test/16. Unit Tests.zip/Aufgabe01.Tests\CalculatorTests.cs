﻿using Aufgabe01.Models;

namespace Aufgabe01.Tests;

public class CalculatorTests
{
    [Theory]
    [InlineData(2, 2, 4)]
    [InlineData(0, 0, 0)]
    [InlineData(0, 1, 1)]
    public void Add_ShouldReturnSum_ForMultipleInputs(int a, int b, int result)
    {
        var sum = Calculator.Add(a, b);
        Assert.Equal(result, sum);
    }

    [Theory]
    [InlineData(2, 2, 0)]
    [InlineData(0, 0, 0)]
    [InlineData(0, 1, -1)]
    public void Subtract_ShouldReturnDifference_ForMultipleInputs(int a, int b, int result)
    {
        var difference = Calculator.Subtract(a, b);
        Assert.Equal(result, difference);
    }

    [Theory]
    [InlineData(2, 2, 4)]
    [InlineData(0, 0, 0)]
    [InlineData(-1, 1, -1)]
    public void Multiply_ShouldReturnProduct_ForMultipleInputs(int a, int b, int result)
    {
        var product = Calculator.Multiply(a, b);
        Assert.Equal(result, product);
    }

    [Theory]
    [InlineData(2, 2, 1)]
    [InlineData(0, 1, 0)]
    [InlineData(-2, 2, -1)]
    public void Divide_ShouldReturnQuotient_ForMultipleInputs(int a, int b, int result)
    {
        var quotient = Calculator.Divide(a, b);
        Assert.Equal(result, quotient);
    }

    [Fact]
    public void Divide_ShouldThrowException_WhenDivisorIsZero()
    {
        Assert.Throws<DivideByZeroException>(() => Calculator.Divide(1, 0));
    }
}
