﻿using Aufgabe02.Collections;
using Aufgabe02.Models;

namespace Aufgabe02.Tests;

public class PersonTests
{
    [Fact]
    public void Constructor_ShouldSetProperties()
    {
        var person = new Person("Max", "Mustermann", new DateTime(2000, 1, 1), Gender.Male);

        Assert.Equal("Max", person.Vorname);
        Assert.Equal("Mustermann", person.Nachname);
        Assert.Equal(new DateTime(2000, 1, 1), person.Geburtsdatum);
        Assert.Equal(Gender.Male, person.Geschlecht);
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenVornameIsNull()
    {
        Assert.Throws<ArgumentException>(() => new Person(null, "Mustermann", new DateTime(2000, 1, 1), Gender.Male));
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenVornameIsEmpty()
    {
        Assert.Throws<ArgumentException>(() => new Person(string.Empty, "Mustermann", new DateTime(2000, 1, 1), Gender.Male));
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenVornameIsWhitespace()
    {
        Assert.Throws<ArgumentException>(() => new Person(" ", "Mustermann", new DateTime(2000, 1, 1), Gender.Male));
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenNachnameIsNull()
    {
        Assert.Throws<ArgumentException>(() => new Person("Max", null, new DateTime(2000, 1, 1), Gender.Male));
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenNachnameIsEmpty()
    {
        Assert.Throws<ArgumentException>(() => new Person("Max", string.Empty, new DateTime(2000, 1, 1), Gender.Male));
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenNachnameIsWhitespace()
    {
        Assert.Throws<ArgumentException>(() => new Person("Max", " ", new DateTime(2000, 1, 1), Gender.Male));
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenGeburtsdatumIsEmpty()
    {
        Assert.Throws<ArgumentException>(() => new Person("Max", "Mustermann", default, Gender.Male));
    }

    [Fact]
    public void Constructor_ShouldThrowException_WhenGeburtsdatumIsInFuture()
    {
        Assert.Throws<ArgumentException>(() => new Person("Max", "Mustermann", DateTime.Now.AddDays(1), Gender.Male));
    }
}
