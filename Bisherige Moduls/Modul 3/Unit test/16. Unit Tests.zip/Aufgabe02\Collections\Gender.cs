﻿namespace Aufgabe02.Collections;

public enum Gender
{
    Male,
    Female,
    Diverse
}
