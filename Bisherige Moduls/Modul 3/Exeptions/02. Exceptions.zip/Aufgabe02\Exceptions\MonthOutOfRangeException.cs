﻿namespace Aufgabe02.Exceptions
{
    internal class MonthOutOfRangeException : Exception
    {
        public MonthOutOfRangeException(string msg) : base(msg)
        {
        }
    }
}