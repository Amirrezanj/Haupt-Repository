﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Person person = new Person();

            try
            {
                person.Alter = -5;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}