﻿namespace Aufgabe02.Exceptions
{
    internal class YearOutOfRangeException : Exception
    {
        public YearOutOfRangeException(string msg) : base(msg)
        {
        }
    }
}