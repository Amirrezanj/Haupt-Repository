﻿using Aufgabe02.Exceptions;

namespace Aufgabe02.Models
{
    internal class SimpleData
    {
        private int _year;
        private int _month;
        private int _day;

        public int Year
        {
            get
            {
                return _year;
            }
            set
            {
                if (value < 1 || value > 9999)
                    throw new YearOutOfRangeException("Jahr muss zwischen 1 und 9999 sein");

                _year = value;
            }
        }

        public int Month
        {
            get
            {
                return _month;
            }
            set
            {
                if (value < 0 || value > 12)
                    throw new MonthOutOfRangeException("Monat muss zwischen 1 und 12 sein");

                _month = value;
            }
        }

        public int Day
        {
            get
            {
                return _day;
            }
            set
            {
                if (value < 1 || value > DateTime.DaysInMonth(Year, Month))
                    throw new DayOfMonthException("Invalider Tag für diesen Monat");

                _day = value;
            }
        }
    }
}