﻿namespace Aufgabe02.Exceptions
{
    internal class DayOfMonthException : Exception
    {
        public DayOfMonthException(string msg) : base(msg)
        {
        }
    }
}