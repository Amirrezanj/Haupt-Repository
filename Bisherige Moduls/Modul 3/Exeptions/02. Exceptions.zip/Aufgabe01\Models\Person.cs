﻿namespace Aufgabe01.Models
{
    internal class Person
    {
        private int _alter;
        public string? Name { get; set; }
        public string? Vorname { get; set; }

        public int Alter
        {
            get => _alter;
            set
            {
                if (value < 0)
                    throw new Exception("Kein negatives Alter erlaubt");

                _alter = value;
            }
        }
    }
}