﻿using Aufgabe02.Exceptions;
using Aufgabe02.Models;

namespace Aufgabe02
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            try
            {
                SimpleData simpleData = new SimpleData();
                simpleData.Year = 2016;
                simpleData.Month = 2;
                simpleData.Day = 29;
            }
            catch (YearOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (MonthOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (DayOfMonthException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}