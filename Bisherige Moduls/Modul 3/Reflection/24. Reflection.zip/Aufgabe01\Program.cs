﻿using System.Reflection;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Type type = typeof(string);

            var members = type.GetMembers(BindingFlags.Public | BindingFlags.Static);

            foreach (var m in members) {
                Console.WriteLine(m.Name);
            }

            Console.WriteLine("----------");

            var methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);

            foreach (var m in members) {
                Console.WriteLine(m.Name);
            }

            Console.WriteLine("----------");

            var fields = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);

            foreach (var field in fields) {
                Console.WriteLine(field.Name);
            }
        }
    }
}
