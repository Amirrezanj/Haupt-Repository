﻿using System.Reflection;

namespace Aufgabe02;

internal class Program
{
    private static void Main(string[] args)
    {
        string path = Console.ReadLine()!;

        Assembly assembly = Assembly.LoadFrom(path);

        Type[] types = assembly.GetTypes();

        foreach (Type type in types) {
            Console.WriteLine(type.FullName);
        }

        Console.ReadKey();
    }
}
