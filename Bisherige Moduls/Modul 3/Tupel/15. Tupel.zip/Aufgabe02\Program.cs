﻿namespace Aufgabe02;

internal class Program
{
    private static void Main(string[] args)
    {
        int[] values1 = { 21, 65, 6, 1, 14, 58, 56, 38, 18, 2 };
        int[] values2 = { 95, 1, 86, 32, 66, 27, 67, 10, 54, 55 };
        var values3 = PrintValuePairs(values1, values2);

        foreach (var v in values3) {
            Console.WriteLine(v);
        }

        float[] values4 = { 21.3f, 65.3f, 6.3f, 1.3f, 14.3f, 58.3f, 56.3f, 38.3f, 18.3f, 2.3f };
        float[] values5 = { 95.3f, 1.3f, 86.3f, 32.3f, 66.3f, 27.3f, 67.3f, 10.3f, 54.3f, 55.3f };
        var values6 = PrintValuePairs(values4, values5);

        foreach (var v in values6) {
            Console.WriteLine(v);
        }
    }

    private static (T a, T b)[] PrintValuePairs<T>(T[] arr1, T[] arr2)
    {
        int length = Math.Min(arr1.Length, arr2.Length);
        (T a, T b)[] values = new (T a, T b)[length];

        for (int i = 0; i < length; i++) {
            values[i] = (arr1[i], arr2[i]);
        }

        return values;
    }
}
