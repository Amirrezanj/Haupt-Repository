﻿namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var values = PrintValuePairs<int>(9, 42, 60, 33, 38, 7, 7, 11);

            foreach (var v in values) {
                Console.WriteLine(v);
            }
        }

        public static (T a, T b)[] PrintValuePairs<T>(params T[] arr)
        {
            (T a, T b)[] values = new (T a, T b)[arr.Length / 2];

            for (int i = 0; i < arr.Length; i += 2) {
                if (i + 1 >= arr.Length) {
                    break;
                }

                values[i / 2] = (arr[i], arr[i + 1]);
            }

            return values;
        }
    }
}
