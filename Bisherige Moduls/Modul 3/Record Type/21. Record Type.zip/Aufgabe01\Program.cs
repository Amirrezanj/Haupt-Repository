﻿using Aufgabe01.Collections;
using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Person person1 = new Person("Franz", "Müller");
            Console.WriteLine(person1);
            Console.WriteLine(person1.FullName);

            Person person2 = person1 with { FirstName = "Hans" };

            if (person1 == person2) {
                Console.WriteLine("person1 == person2");
            } else {
                Console.WriteLine("person1 != person2");
            }

            Employee employee1 = new Employee("Franz", "Müller", Position.Manager);
            Employee employee2 = new Employee("Franz", "Müller", Position.Manager);

            if (employee1 is Person) {
                Console.WriteLine("employee1 is Person");
            } else {
                Console.WriteLine("employee1 is not Person");
            }

            if (employee1 == person1) {
                Console.WriteLine("employee1 == person1");
            } else {
                Console.WriteLine("employee1 != person1");
            }

            if (employee1 == employee2) {
                Console.WriteLine("employee1 == employee2");
            } else {
                Console.WriteLine("employee1 != employee2");
            }
        }
    }
}
