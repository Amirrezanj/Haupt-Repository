﻿namespace Aufgabe01.Collections;

public enum Position
{
    Manager,
    Developer,
    Tester
}
