﻿using Aufgabe01.Collections;

namespace Aufgabe01.Models;

public record Employee(string FirstName, string LastName, Position Position) : Person(FirstName, LastName);
