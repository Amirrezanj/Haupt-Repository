﻿using Aufgabe02.Models;

namespace Aufgabe02
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			Fluss rhein = new Fluss("Rhein", 1000);

			Schiff rheingold = new Schiff("Rheingold");
			Schiff lorelei = new Schiff("Lorelei");
			Stadt köln = new Stadt("Köln");
			Stadt düsseldorf = new Stadt("Düsseldorf");

			rhein.WasserstandChanged += rheingold.WasserstandHatSichGeändert;
			rhein.WasserstandChanged += lorelei.WasserstandHatSichGeändert;
			rhein.WasserstandChanged += köln.WasserstandHatSichGeändert;
			rhein.WasserstandChanged += düsseldorf.WasserstandHatSichGeändert;

			Fluss donau = new Fluss("Donau", 1000);

			Stadt ulm = new Stadt("Ulm");
			Schiff xaver = new Schiff("Xaver");
			Schiff franz = new Schiff("Franz");
			Klärwerk strauß1 = new Klärwerk("Strauß 1");

			donau.WasserstandChanged += ulm.WasserstandHatSichGeändert;
			donau.WasserstandChanged += xaver.WasserstandHatSichGeändert;
			donau.WasserstandChanged += franz.WasserstandHatSichGeändert;
			donau.WasserstandChanged += strauß1.WasserstandHatSichGeändert;
			donau.WasserstandChanged += düsseldorf.WasserstandHatSichGeändert;

			rhein.Wasserstand = 9000;
			donau.Wasserstand = 8800;
		}
	}
}