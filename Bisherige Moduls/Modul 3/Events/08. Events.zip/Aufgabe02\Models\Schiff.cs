﻿namespace Aufgabe02.Models;

internal class Schiff : FlussBeobachter
{
	public Schiff(string name) : base(name)
	{
	}

	public override void WasserstandHatSichGeändert(object? sender, WasserstandChangedEventArgs e)
	{
		if ((e.NeuerWasserstand < 250 || e.NeuerWasserstand > 8000) && sender != null)
		{
			Fluss fluss = (Fluss)sender;

			Console.WriteLine($"{Name} hat angehalten, " +
				$"Wasserstand des Flusses {fluss.Name} hat sich von {e.AlterWasserstand} auf {e.NeuerWasserstand} verändert");
		}
	}
}