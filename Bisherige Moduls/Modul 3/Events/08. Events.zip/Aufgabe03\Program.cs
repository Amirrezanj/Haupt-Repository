﻿using Aufgabe03.Models;

namespace Aufgabe03
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			Counter counter = new Counter();
			counter.ValueThresholdExceeded += CounterValueThresholdExceeded;
			counter.ZählerstandErhöhen(5000, Predicate, Action);
		}

		private static void CounterValueThresholdExceeded(object? sender, EventArgs e)
		{
			Console.WriteLine("EventHandler");
		}

		private static bool Predicate(int x)
		{
			return x >= 1000;
		}

		private static void Action(int x)
		{
			Console.WriteLine("Action: {0}", x);
		}
	}
}