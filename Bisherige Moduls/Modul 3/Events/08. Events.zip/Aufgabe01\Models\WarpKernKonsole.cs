﻿namespace Aufgabe01.Models;

internal class WarpKernKonsole
{
	public void TemperaturHatSichGeändert(object? sender, WarpKernTemperatureChangedEventArgs e)
	{
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine($"Time: {e.Time.ToString().PadRight(15)} OldTemp: {e.OldTemp.ToString().PadRight(1).PadLeft(10)} NewTemp: {e.NewTemp.ToString().PadLeft(10)}");
		Console.ResetColor();
	}

	public void KritischeTemperaturErreicht(object? sender, WarpKernTemperatureChangedEventArgs e)
	{
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine($"Time: {e.Time.ToString().PadRight(15)} OldTemp: {e.OldTemp.ToString().PadRight(1).PadLeft(10)} NewTemp: {e.NewTemp.ToString().PadLeft(10)} KRITISCH");
		Console.ResetColor();
	}
}