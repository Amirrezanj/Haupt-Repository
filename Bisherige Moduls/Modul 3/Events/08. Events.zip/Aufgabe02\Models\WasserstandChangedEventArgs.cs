﻿namespace Aufgabe02.Models;

internal class WasserstandChangedEventArgs : EventArgs
{
	public int AlterWasserstand { get; }
	public int NeuerWasserstand { get; }

	public WasserstandChangedEventArgs(int alterWasserstand, int neuerWasserstand)
	{
		AlterWasserstand = alterWasserstand;
		NeuerWasserstand = neuerWasserstand;
	}
}