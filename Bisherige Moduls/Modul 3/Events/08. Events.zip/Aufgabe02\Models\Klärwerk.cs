﻿namespace Aufgabe02.Models;

internal class Klärwerk : FlussBeobachter
{
	public Klärwerk(string name) : base(name)
	{
	}

	public override void WasserstandHatSichGeändert(object? sender, WasserstandChangedEventArgs e)
	{
		if (e.NeuerWasserstand > 8000 && sender != null)
		{
			Fluss fluss = (Fluss)sender;

			Console.WriteLine($"{Name} hat die Einleitung von Wasser in den Fluss {fluss.Name} gestoppt, " +
				$"Wasserstand hat sich von {e.AlterWasserstand} auf {e.NeuerWasserstand} erhöht");
		}
		else if (e.NeuerWasserstand < 3000 && sender != null)
		{
			Fluss fluss = (Fluss)sender;

			Console.WriteLine($"{Name} hat die Einleitung von Wasser in den Fluss {fluss.Name} erhöht, " +
				$"Wasserstand hat sich von {e.AlterWasserstand} auf {e.NeuerWasserstand} verringer");
		}
	}
}