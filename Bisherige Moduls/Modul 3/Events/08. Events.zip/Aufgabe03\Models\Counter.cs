﻿namespace Aufgabe03.Models
{
	public class Counter
	{
		public int Value { get; private set; }

		public event EventHandler? ValueThresholdExceeded;

		public void ZählerstandErhöhen(int x, Predicate<int> predicate, Action<int> action)
		{
			Value += x;

			if (predicate(Value))
			{
				action(Value);
				ValueThresholdExceeded?.Invoke(this, EventArgs.Empty);
			}
		}

		public void Clear()
		{
			Value = 0;
		}
	}
}