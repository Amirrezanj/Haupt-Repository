﻿namespace Aufgabe01.Models;

internal class WarpKern
{
	private int _warpKernTemperatur;

	public int WarpKernTemperatur
	{
		get => _warpKernTemperatur;
		set
		{
			var args = new WarpKernTemperatureChangedEventArgs(_warpKernTemperatur, value, DateTime.Now.ToLongTimeString());

			_warpKernTemperatur = value;
			TemperaturChanged?.Invoke(this, args);

			if (value > 500)
				KritischeTemperaturReached?.Invoke(this, args);
		}
	}

	public event EventHandler<WarpKernTemperatureChangedEventArgs>? TemperaturChanged;

	public event EventHandler<WarpKernTemperatureChangedEventArgs>? KritischeTemperaturReached;
}