﻿namespace Aufgabe01.Models;

internal class WarpKernTemperatureChangedEventArgs
{
	public int OldTemp { get; }
	public int NewTemp { get; }
	public string Time { get; }

	public WarpKernTemperatureChangedEventArgs(int oldTemp, int newTemp, string time)
	{
		OldTemp = oldTemp;
		NewTemp = newTemp;
		Time = time;
	}
}