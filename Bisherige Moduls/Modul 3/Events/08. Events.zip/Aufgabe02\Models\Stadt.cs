﻿namespace Aufgabe02.Models;

internal class Stadt : FlussBeobachter
{
	public Stadt(string name) : base(name)
	{
	}

	public override void WasserstandHatSichGeändert(object? sender, WasserstandChangedEventArgs e)
	{
		if (e.NeuerWasserstand > 8200 && sender != null)
		{
			Fluss fluss = (Fluss)sender;

			Console.WriteLine($"{Name} hat eine Wasserschutzwand am Fluss {fluss.Name} errichtet, " +
				$"Wasserstand hat sich von {e.AlterWasserstand} auf {e.NeuerWasserstand} verändert");
		}
	}
}