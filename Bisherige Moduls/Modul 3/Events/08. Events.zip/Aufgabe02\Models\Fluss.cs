﻿namespace Aufgabe02.Models;

internal class Fluss
{
	private int _wasserstand;

	public string Name { get; }

	public int Wasserstand
	{
		get => _wasserstand;
		set
		{
			if (value >= 100 && value <= 10000)
			{
				var eventArgs = new WasserstandChangedEventArgs(_wasserstand, value);

				_wasserstand = value;
				WasserstandChanged?.Invoke(this, eventArgs);
			}
		}
	}

	public event EventHandler<WasserstandChangedEventArgs>? WasserstandChanged;

	public Fluss(string name, int wasserstand)
	{
		Name = name;
		Wasserstand = wasserstand;
	}
}