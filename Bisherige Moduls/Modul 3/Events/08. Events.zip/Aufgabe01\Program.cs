﻿using Aufgabe01.Models;

namespace Aufgabe01
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			var warpKern = new WarpKern();
			var warpKernKonsole = new WarpKernKonsole();

			warpKern.TemperaturChanged += warpKernKonsole.TemperaturHatSichGeändert;
			warpKern.KritischeTemperaturReached += warpKernKonsole.KritischeTemperaturErreicht;

			warpKern.WarpKernTemperatur = 1;
			warpKern.WarpKernTemperatur = 10;
			warpKern.WarpKernTemperatur = 100;
			warpKern.WarpKernTemperatur = 1000;
			warpKern.WarpKernTemperatur = 10000;
		}
	}
}