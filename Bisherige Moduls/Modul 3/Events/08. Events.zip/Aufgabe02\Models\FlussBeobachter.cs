﻿namespace Aufgabe02.Models;

internal abstract class FlussBeobachter
{
	public string Name { get; }

	public FlussBeobachter(string name)
	{
		Name = name;
	}

	public abstract void WasserstandHatSichGeändert(object? sender, WasserstandChangedEventArgs e);
}