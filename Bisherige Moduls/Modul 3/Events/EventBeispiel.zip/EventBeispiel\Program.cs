﻿namespace EventBeispiel
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Schüler schüler = new Schüler
			{
				Name = "Petra",
				Klasse = "1B",
				GesamtNote = 5
			};

			schüler.NameChanged += Schüler_NameChanged;
			schüler.KlasseChanged += Schüler_KlasseChanged;
			schüler.GesamtNoteChanged += Schüler_GesamtNoteChanged;

			schüler.Name = "Paul";
			schüler.Klasse = "5A";
			schüler.Klasse = "7C";
			schüler.GesamtNote = 4;
		}


		private static void Schüler_NameChanged(object? sender, SchülerChangedEventArgs<string> e)
		{
			Console.WriteLine($"Schüler Name hat sich geändert: Alter Name {e.OldValue} Neuer Name: {e.NewValue}");
		}

		private static void Schüler_KlasseChanged(object? sender, SchülerChangedEventArgs<string> e)
		{
			Console.WriteLine($"Schüler Klasse hat sich geändert: Alte Klasse {e.OldValue} Neue Klasse: {e.NewValue}");
		}

		private static void Schüler_GesamtNoteChanged(object? sender, SchülerChangedEventArgs<int> e)
		{
			Console.WriteLine($"Schüler Gesamtnote hat sich geändert: Alte Note {e.OldValue} Neue Note: {e.NewValue}");
		}
	}

	public class Schüler
	{
		private string _name = string.Empty;
		private string _klasse = string.Empty;
		private int _gesamtNote = -1;

		public string Name
		{
			get => _name;
			set
			{
				if (_name != value)
				{
					NameChanged?.Invoke(this, new SchülerChangedEventArgs<string>(_name, value));
					_name = value;
				}
			}
		}
		public string Klasse
		{
			get => _klasse;
			set
			{
				if (_klasse != value)
				{
					KlasseChanged?.Invoke(this, new SchülerChangedEventArgs<string>(_klasse, value));
					_klasse = value;
				}
			}
		}

		public int GesamtNote
		{
			get => _gesamtNote;
			set
			{
				if (_gesamtNote != value)
				{
					GesamtNoteChanged?.Invoke(this, new SchülerChangedEventArgs<int>(_gesamtNote, value));
					_gesamtNote = value;
				}
			}
		}

		public event EventHandler<SchülerChangedEventArgs<string>>? NameChanged;
		public event EventHandler<SchülerChangedEventArgs<string>>? KlasseChanged;
		public event EventHandler<SchülerChangedEventArgs<int>>? GesamtNoteChanged;
	}

	public class SchülerChangedEventArgs<T> : EventArgs
	{
		public T OldValue { get; }
		public T NewValue { get; }

		public SchülerChangedEventArgs(T oldValue, T newValue)
		{
			OldValue = oldValue;
			NewValue = newValue;
		}
	}
}
