﻿namespace Aufgabe01.Extensions
{
	public static class ArrayExtensions
	{
		public static List<T> ArrayToList<T>(this T[] arr)
		{
			List<T> list = new List<T>();

			foreach (var item in arr)
			{
				list.Add(item);
			}

			// List<T> list = [.. arr];

			return list;
		}
	}
}