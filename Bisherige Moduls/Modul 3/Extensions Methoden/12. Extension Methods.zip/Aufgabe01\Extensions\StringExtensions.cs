﻿namespace Aufgabe01.Extensions
{
	public static class StringExtensions
	{
		public static bool IsPalindrom(this string str)
		{
			return str.ReverseString() == str;
		}

		public static string ReverseString(this string str)
		{
			string s = string.Empty;

			for (int i = 0; i < str.Length; i++)
			{
				s += str[str.Length - 1 - i];
			}

			return s;
		}
	}
}