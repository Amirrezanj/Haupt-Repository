﻿using Aufgabe01.Extensions;

namespace Aufgabe01
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			string s = "Anna";

			string[] strings = ["Peter", "Paul"];

			Console.WriteLine(s.ReverseString());
			Console.WriteLine(s.IsPalindrom());
			List<string> list = strings.ArrayToList();
		}
	}
}