﻿using Aufgabe01.Attributes;

namespace Aufgabe01.Models;

[Table(Name = "tblDummy")]
public class Dummy
{
    [Column(Name = "Name", DbType = "NVARCHAR(100)")]
    public string Name { get; set; } = string.Empty;

    [Column(Name = "BirthDate", DbType = "DATETIME")]
    public DateTime GebDat { get; set; }
}
