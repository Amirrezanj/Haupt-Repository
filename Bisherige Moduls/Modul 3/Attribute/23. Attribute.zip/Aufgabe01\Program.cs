﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Dummy dummy = new Dummy();

            string createTableCode = SqlCodeGenerator.GetCreateTableCode(typeof(Dummy));

            Console.WriteLine(createTableCode);
        }
    }
}
