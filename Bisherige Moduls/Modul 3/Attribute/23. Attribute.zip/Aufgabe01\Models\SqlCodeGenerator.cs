﻿using Aufgabe01.Attributes;
using System.Reflection;

namespace Aufgabe01.Models;

public static class SqlCodeGenerator
{
    public static string GetCreateTableCode(Type t)
    {
        TableAttribute? tableAttribute = t.GetCustomAttribute<TableAttribute>();

        if (tableAttribute == null)
            throw new Exception("TableAttribute not found");

        PropertyInfo[] properties = t.GetProperties().Where(x => x.CustomAttributes.Any(y => y.AttributeType == typeof(ColumnAttribute))).ToArray();

        if (properties.Length == 0)
            throw new Exception("ColumnAttribute not found");

        string columnDefinitionString = string.Empty;

        for (int i = 0; i < properties.Length; i++) {
            ColumnAttribute columnAttribute = properties[i].GetCustomAttribute<ColumnAttribute>()!;

            columnDefinitionString += $"{columnAttribute.Name} {columnAttribute.DbType}";

            if (i < properties.Length - 1)
                columnDefinitionString += ", ";
        }

        return $"CREATE TABLE {tableAttribute.Name} ({columnDefinitionString});";
    }
}
