﻿namespace Aufgabe01.Attributes;

[AttributeUsage(AttributeTargets.Property)]
public class ColumnAttribute : Attribute
{
    public string Name { get; set; } = string.Empty;
    public string DbType { get; set; } = string.Empty;
}
