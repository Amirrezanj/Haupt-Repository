namespace Aufgabe01
{
	public partial class Form1 : Form
	{
		private CancellationTokenSource? _cts;

		public Form1()
		{
			InitializeComponent();
		}

		private async void button1_Click(object sender, EventArgs e)
		{
			try
			{
				button1.Enabled = false;
				Cursor = Cursors.WaitCursor;
				_cts = new CancellationTokenSource();
				progressBar1.Value = 0;
				label1.Text = string.Empty;

				double result = await Task.Run(() => ComputePi(_cts.Token), _cts.Token);
				label1.Text = result.ToString();
			}
			catch (OperationCanceledException)
			{
				MessageBox.Show("Berechnung wurde abgebrochen");
				progressBar1.Value = 0;
			}
			finally
			{
				Cursor = Cursors.Default;
				button1.Enabled = true;
			}
		}

		private double ComputePi(CancellationToken token)
		{
			double sum = 0.0;
			const double step = 1e-9;

			for (int i = 0; i < 1_000_000_000; i++)
			{
				token.ThrowIfCancellationRequested();
				double x = (i + 0.5) * step;
				sum += 4.0 / (1.0 + x * x);

				if (i % 10000000 == 0)
				{
					BeginInvoke((MethodInvoker)delegate
					{
						progressBar1.Value += 1;
					});
				}
			}

			return sum * step;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			_cts?.Cancel();
		}
	}
}