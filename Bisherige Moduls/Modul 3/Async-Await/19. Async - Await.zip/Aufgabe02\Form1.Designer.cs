﻿namespace Aufgabe02
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			_startDownloadButton = new Button();
			_stopDownloadButton = new Button();
			_clearIconsButton = new Button();
			_urlTextBox = new TextBox();
			_iconFlowLayoutPanel = new FlowLayoutPanel();
			_errorTextBox = new TextBox();
			SuspendLayout();
			// 
			// _startDownloadButton
			// 
			_startDownloadButton.Location = new Point(438, 45);
			_startDownloadButton.Name = "_startDownloadButton";
			_startDownloadButton.Size = new Size(174, 23);
			_startDownloadButton.TabIndex = 0;
			_startDownloadButton.Text = "Download Icons";
			_startDownloadButton.UseVisualStyleBackColor = true;
			_startDownloadButton.Click += StartDownloadButtonClick;
			// 
			// _stopDownloadButton
			// 
			_stopDownloadButton.Enabled = false;
			_stopDownloadButton.Location = new Point(438, 74);
			_stopDownloadButton.Name = "_stopDownloadButton";
			_stopDownloadButton.Size = new Size(174, 23);
			_stopDownloadButton.TabIndex = 3;
			_stopDownloadButton.Text = "Stop Downloads";
			_stopDownloadButton.UseVisualStyleBackColor = true;
			_stopDownloadButton.Click += StopDownloadButtonClick;
			// 
			// _clearIconsButton
			// 
			_clearIconsButton.Location = new Point(438, 103);
			_clearIconsButton.Name = "_clearIconsButton";
			_clearIconsButton.Size = new Size(174, 23);
			_clearIconsButton.TabIndex = 4;
			_clearIconsButton.Text = "Clear Icons";
			_clearIconsButton.UseVisualStyleBackColor = true;
			_clearIconsButton.Click += ClearIconsButtonClick;
			// 
			// _urlTextBox
			// 
			_urlTextBox.Location = new Point(26, 45);
			_urlTextBox.Multiline = true;
			_urlTextBox.Name = "_urlTextBox";
			_urlTextBox.Size = new Size(393, 226);
			_urlTextBox.TabIndex = 2;
			// 
			// _iconFlowLayoutPanel
			// 
			_iconFlowLayoutPanel.FlowDirection = FlowDirection.TopDown;
			_iconFlowLayoutPanel.Location = new Point(26, 293);
			_iconFlowLayoutPanel.Name = "_iconFlowLayoutPanel";
			_iconFlowLayoutPanel.Size = new Size(586, 194);
			_iconFlowLayoutPanel.TabIndex = 1;
			// 
			// _errorTextBox
			// 
			_errorTextBox.Location = new Point(26, 511);
			_errorTextBox.Multiline = true;
			_errorTextBox.Name = "_errorTextBox";
			_errorTextBox.ReadOnly = true;
			_errorTextBox.ScrollBars = ScrollBars.Vertical;
			_errorTextBox.Size = new Size(586, 99);
			_errorTextBox.TabIndex = 5;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(645, 622);
			Controls.Add(_errorTextBox);
			Controls.Add(_clearIconsButton);
			Controls.Add(_stopDownloadButton);
			Controls.Add(_urlTextBox);
			Controls.Add(_iconFlowLayoutPanel);
			Controls.Add(_startDownloadButton);
			Name = "Form1";
			Text = "Form1";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Button _startDownloadButton;
		private Button _stopDownloadButton;
		private Button _clearIconsButton;
		private TextBox _urlTextBox;
		private FlowLayoutPanel _iconFlowLayoutPanel;
		private TextBox _errorTextBox;
	}
}
