namespace Aufgabe02
{
	public partial class Form1 : Form
	{
		private readonly HttpClient _httpClient = new();
		private readonly List<Task> _downloadTasks = [];
		private readonly List<MemoryStream> _streams = [];
		private CancellationTokenSource? _cts;

		public Form1()
		{
			InitializeComponent();
		}

		private async void StartDownloadButtonClick(object sender, EventArgs e)
		{
			try
			{
				_startDownloadButton.Enabled = false;
				_stopDownloadButton.Enabled = true;
				_clearIconsButton.Enabled = false;
				Cursor = Cursors.WaitCursor;

				Clean();

				_cts = new CancellationTokenSource();

				foreach (var url in _urlTextBox.Text.Split(Environment.NewLine))
				{
					if (string.IsNullOrWhiteSpace(url))
						continue;

					_downloadTasks.Add(DownloadFavIcon(url, _cts.Token));
				}

				await Task.WhenAll(_downloadTasks);
			}
			finally
			{
				_startDownloadButton.Enabled = true;
				_stopDownloadButton.Enabled = false;
				_clearIconsButton.Enabled = true;
				Cursor = Cursors.Default;
				MessageBox.Show(_streams.Count.ToString());
			}
		}

		private void StopDownloadButtonClick(object sender, EventArgs e)
		{
			_cts?.Cancel();
		}

		private void ClearIconsButtonClick(object sender, EventArgs e)
		{
			_urlTextBox.Text = string.Empty;
			Clean();
		}

		private void Clean()
		{
			_iconFlowLayoutPanel.Controls.Clear();

			foreach (var stream in _streams)
			{
				stream.Close();
			}

			_streams.Clear();
		}

		private async Task DownloadFavIcon(string url, CancellationToken token)
		{
			try
			{
				await Task.Delay(5000, token);

				var bytes = await _httpClient.GetByteArrayAsync(url + "/favicon.ico", token);
				var ms = new MemoryStream(bytes);

				_streams.Add(ms);

				_iconFlowLayoutPanel.Controls.Add(new PictureBox
				{
					Image = Image.FromStream(ms)
				});
			}
			catch (OperationCanceledException)
			{
				// Ignored
			}
			catch (Exception ex)
			{
				_errorTextBox.Text += _errorTextBox.Text + ex.Message + Environment.NewLine;
			}
		}
	}
}