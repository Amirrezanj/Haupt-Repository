using System.IO.Compression;

namespace Aufgabe03
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void �ffnenButtonClick(object sender, EventArgs e)
		{
			try
			{
				_komprimierButton.Enabled = false;
				_dekomprimierButton.Enabled = false;

				var result = openFileDialog1.ShowDialog();

				if (result == DialogResult.OK)
				{
					_zielBytesLabel.Text = "- bytes";
					_percentageLabel.Text = "0 %";

					if (openFileDialog1.FileName.EndsWith(".comp"))
					{
						_dateiTextBox.Text = openFileDialog1.FileName;
						_zielTextBox.Text = openFileDialog1.FileName.Replace(".comp", "");

						FileInfo fileInfo = new FileInfo(openFileDialog1.FileName);
						_dateiBytesLabel.Text = $"{fileInfo.Length} bytes";

						_dekomprimierButton.Enabled = true;
					}
					else
					{
						_dateiTextBox.Text = openFileDialog1.FileName;
						_zielTextBox.Text = openFileDialog1.FileName + ".comp";

						FileInfo fileInfo = new FileInfo(openFileDialog1.FileName);
						_dateiBytesLabel.Text = $"{fileInfo.Length} bytes";

						_komprimierButton.Enabled = true;
					}
				}
				else
				{
					_dateiTextBox.Text = string.Empty;
					_zielTextBox.Text = string.Empty;
					_dateiBytesLabel.Text = "- bytes";
					_zielBytesLabel.Text = "- bytes";
					_percentageLabel.Text = "0 %";
				}
			}
			catch (Exception)
			{
				MessageBox.Show("Unbekannter Fehler ist aufgetreten");
			}
		}

		private void KomprimierButtonClick(object sender, EventArgs e)
		{
			try
			{
				_komprimierButton.Enabled = false;
				_�ffnenButton.Enabled = false;

				GZipFile(_dateiTextBox.Text, _zielTextBox.Text, CompressionMode.Compress);

				FileInfo fileInfo = new FileInfo(_zielTextBox.Text);
				_zielBytesLabel.Text = $"{fileInfo.Length} bytes";

				FileInfo dateiFileInfo = new FileInfo(_dateiTextBox.Text);
				_percentageLabel.Text = $"{CalculatePercentageDifference(dateiFileInfo.Length, fileInfo.Length):F2} %";
			}
			catch (Exception)
			{
				MessageBox.Show("Unbekannter Fehler ist aufgetreten");
			}
			finally
			{
				_�ffnenButton.Enabled = true;
				_komprimierButton.Enabled = true;
			}
		}

		private void DekomprimierButtonClick(object sender, EventArgs e)
		{
			try
			{
				_dekomprimierButton.Enabled = false;
				_�ffnenButton.Enabled = false;

				GZipFile(_dateiTextBox.Text, _zielTextBox.Text, CompressionMode.Decompress);

				FileInfo fileInfo = new FileInfo(_zielTextBox.Text);
				_zielBytesLabel.Text = $"{fileInfo.Length} bytes";

				FileInfo dateiFileInfo = new FileInfo(_dateiTextBox.Text);
				_percentageLabel.Text = $"{CalculatePercentageDifference(dateiFileInfo.Length, fileInfo.Length):F2} %";
			}
			catch (Exception)
			{
				MessageBox.Show("Unbekannter Fehler ist aufgetreten");
			}
			finally
			{
				_�ffnenButton.Enabled = true;
				_dekomprimierButton.Enabled = true;
			}
		}

		private static void GZipFile(string originPath, string targetPath, CompressionMode compressionMode)
		{
			FileStream? originStream = null;
			FileStream? targetStream = null;
			GZipStream? gzipstream = null;

			try
			{
				originStream = new FileStream(originPath, FileMode.Open, FileAccess.Read, FileShare.None);
				targetStream = new FileStream(targetPath, FileMode.Create, FileAccess.Write, FileShare.None);

				if (compressionMode == CompressionMode.Compress)
				{
					gzipstream = new GZipStream(targetStream, compressionMode);
					originStream.CopyTo(gzipstream);
				}
				else
				{
					gzipstream = new GZipStream(originStream, compressionMode);
					gzipstream.CopyTo(targetStream);
				}
			}
			finally
			{
				gzipstream?.Close();
				targetStream?.Close();
				originStream?.Close();
			}
		}

		private static double CalculatePercentageDifference(long originalSize, long newSize)
		{
			if (originalSize <= 0)
				throw new ArgumentException("Original size must be a positive integer.");

			if (newSize < 0)
				throw new ArgumentException("New size must not be negative.");

			double difference = newSize - originalSize;
			double percentage = (difference / originalSize) * 100;

			return Math.Round(percentage, 2);
		}
	}
}