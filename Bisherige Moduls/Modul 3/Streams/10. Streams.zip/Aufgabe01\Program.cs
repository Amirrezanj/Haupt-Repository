﻿namespace Aufgabe01
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			var enumerationOptions = new EnumerationOptions
			{
				RecurseSubdirectories = true,
			};

			var files = Directory.GetFiles("C:\\", "test.txt", enumerationOptions);

			if (files.Length == 0)
			{
				Console.WriteLine("Keine passende Datei gefunden");
				return;
			}

			var filePath = files[0];
			Console.WriteLine("Selected File: " + filePath);

			var fileStream = File.OpenWrite(filePath);
			StreamWriter streamWriter = new StreamWriter(fileStream);

			string input = string.Empty;

			while (input != ".")
			{
				input = Console.ReadLine()!;

				if (input != ".")
				{
					streamWriter.WriteLine(DateTime.Now + " " + input);
				}
			}

			streamWriter.Close();
		}
	}
}