﻿using System.Net;

namespace Aufgabe02
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "lookup");
			FileSystemWatcher watcher = new FileSystemWatcher(folderPath, "*.lookup");
			watcher.Created += WatcherCreated;
			watcher.EnableRaisingEvents = true;

			Console.WriteLine("Zum beenden beliebige Taste drücken");
			Console.ReadLine();
		}

		private static void WatcherCreated(object sender, FileSystemEventArgs e)
		{
			Console.WriteLine("Neue Datei gefunden: {0}", e.Name);
			var lines = File.ReadAllLines(e.FullPath);
			var stream = File.OpenWrite(Path.ChangeExtension(e.FullPath, ".resolved"));
			var writer = new StreamWriter(stream);

			foreach (var line in lines)
			{
				var ips = Dns.GetHostEntry(line);

				foreach (var ip in ips.AddressList)
				{
					writer.WriteLine(ip);
				}
			}

			writer.Close();
		}
	}
}