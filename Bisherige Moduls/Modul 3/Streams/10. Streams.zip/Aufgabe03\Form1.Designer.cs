﻿using System.Windows.Forms;

namespace Aufgabe03
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			label2 = new Label();
			_dateiTextBox = new TextBox();
			_zielTextBox = new TextBox();
			_öffnenButton = new Button();
			_komprimierButton = new Button();
			_dekomprimierButton = new Button();
			_dateiBytesLabel = new Label();
			_zielBytesLabel = new Label();
			openFileDialog1 = new OpenFileDialog();
			_percentageLabel = new Label();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(12, 15);
			label1.Name = "label1";
			label1.Size = new Size(37, 15);
			label1.TabIndex = 0;
			label1.Text = "Datei:";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(12, 49);
			label2.Name = "label2";
			label2.Size = new Size(29, 15);
			label2.TabIndex = 1;
			label2.Text = "Ziel:";
			// 
			// _dateiTextBox
			// 
			_dateiTextBox.Location = new Point(58, 12);
			_dateiTextBox.Name = "_dateiTextBox";
			_dateiTextBox.ReadOnly = true;
			_dateiTextBox.Size = new Size(520, 23);
			_dateiTextBox.TabIndex = 2;
			// 
			// _zielTextBox
			// 
			_zielTextBox.Location = new Point(58, 46);
			_zielTextBox.Name = "_zielTextBox";
			_zielTextBox.ReadOnly = true;
			_zielTextBox.Size = new Size(520, 23);
			_zielTextBox.TabIndex = 3;
			// 
			// _öffnenButton
			// 
			_öffnenButton.Location = new Point(697, 12);
			_öffnenButton.Name = "_öffnenButton";
			_öffnenButton.Size = new Size(99, 23);
			_öffnenButton.TabIndex = 4;
			_öffnenButton.Text = "Öffnen";
			_öffnenButton.UseVisualStyleBackColor = true;
			_öffnenButton.Click += ÖffnenButtonClick;
			// 
			// _komprimierButton
			// 
			_komprimierButton.Enabled = false;
			_komprimierButton.Location = new Point(58, 88);
			_komprimierButton.Name = "_komprimierButton";
			_komprimierButton.Size = new Size(155, 23);
			_komprimierButton.TabIndex = 5;
			_komprimierButton.Text = "Komprimieren";
			_komprimierButton.UseVisualStyleBackColor = true;
			_komprimierButton.Click += KomprimierButtonClick;
			// 
			// _dekomprimierButton
			// 
			_dekomprimierButton.Enabled = false;
			_dekomprimierButton.Location = new Point(423, 88);
			_dekomprimierButton.Name = "_dekomprimierButton";
			_dekomprimierButton.Size = new Size(155, 23);
			_dekomprimierButton.TabIndex = 6;
			_dekomprimierButton.Text = "Dekomprimieren";
			_dekomprimierButton.UseVisualStyleBackColor = true;
			_dekomprimierButton.Click += DekomprimierButtonClick;
			// 
			// _dateiBytesLabel
			// 
			_dateiBytesLabel.AutoSize = true;
			_dateiBytesLabel.Location = new Point(598, 15);
			_dateiBytesLabel.Name = "_dateiBytesLabel";
			_dateiBytesLabel.Size = new Size(43, 15);
			_dateiBytesLabel.TabIndex = 7;
			_dateiBytesLabel.Text = "- bytes";
			// 
			// _zielBytesLabel
			// 
			_zielBytesLabel.AutoSize = true;
			_zielBytesLabel.Location = new Point(598, 49);
			_zielBytesLabel.Name = "_zielBytesLabel";
			_zielBytesLabel.Size = new Size(43, 15);
			_zielBytesLabel.TabIndex = 8;
			_zielBytesLabel.Text = "- bytes";
			// 
			// openFileDialog1
			// 
			openFileDialog1.FileName = "openFileDialog1";
			// 
			// _percentageLabel
			// 
			_percentageLabel.AutoSize = true;
			_percentageLabel.Location = new Point(615, 92);
			_percentageLabel.Name = "_percentageLabel";
			_percentageLabel.Size = new Size(26, 15);
			_percentageLabel.TabIndex = 9;
			_percentageLabel.Text = "0 %";
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(808, 123);
			Controls.Add(_percentageLabel);
			Controls.Add(_zielBytesLabel);
			Controls.Add(_dateiBytesLabel);
			Controls.Add(_dekomprimierButton);
			Controls.Add(_komprimierButton);
			Controls.Add(_öffnenButton);
			Controls.Add(_zielTextBox);
			Controls.Add(_dateiTextBox);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "Form1";
			Text = "Kompression";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private Label label2;
		private TextBox _dateiTextBox;
		private TextBox _zielTextBox;
		private Button _öffnenButton;
		private Button _komprimierButton;
		private Button _dekomprimierButton;
		private Label _dateiBytesLabel;
		private Label _zielBytesLabel;
		private OpenFileDialog openFileDialog1;
		private Label _percentageLabel;
	}
}
