﻿using Aufgabe01.Models;

namespace Aufgabe01
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Einkaufsliste einkaufsliste = new Einkaufsliste(2);
            einkaufsliste[0] = "Gurke";
            einkaufsliste[1] = "Tomate";

            Console.WriteLine(einkaufsliste[0]);
            Console.WriteLine(einkaufsliste["Gurke"]);
        }
    }
}