﻿namespace Aufgabe01.Models
{
    internal class Einkaufsliste
    {
        private string[] _liste;

        public Einkaufsliste(int kapazität)
        {
            _liste = new string[kapazität];
        }

        public string this[int index]
        {
            get
            {
                return _liste[index];
            }
            set
            {
                _liste[index] = value;
            }
        }

        public int this[string name]
        {
            get
            {
                for (int i = 0; i < _liste.Length; i++)
                {
                    if (_liste[i] == name)
                        return i;
                }

                return -1;
            }
        }
    }
}