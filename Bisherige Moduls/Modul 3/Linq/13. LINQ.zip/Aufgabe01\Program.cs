﻿using System.Diagnostics;

namespace Aufgabe01
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			//Aufgabe1();
			//Aufgabe2();
			//Aufgabe3();
			//Aufgabe4();
			//Aufgabe5();
			//Aufgabe6();
			//Aufgabe7();
			//Aufgabe8();
			//Aufgabe9();
			//Aufgabe10();
		}

		private static void Aufgabe1()
		{
			int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0, 22, 12, 16, 18, 11, 19, 13 };
			numbers.Where(x => x < 7);
			numbers.Where(x => x % 2 == 0);
			numbers.Where(x => x % 2 != 0 && x < 10);
			numbers.Skip(5).Where(x => x % 2 == 0);
		}

		private static void Aufgabe2()
		{
			string[] numbers = { "zero", "one", "two", "three", "four", "five", "six",
			"seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen" };
			numbers.Where(x => x.Length == 3);
			numbers.Where(x => x.Contains('o'));
			numbers.Where(x => x.EndsWith("teen"));
			numbers.Where(x => x.EndsWith("teen")).Select(x => x.ToUpper());
			numbers.Where(x => x.Contains("four"));
		}

		private static void Aufgabe3()
		{
			int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0, 22, 12, 16, 18, 11, 19, 13 };
			numbers.Sum();
			numbers.Min();
			numbers.Max();
			numbers.Average();
			numbers.Where(x => x % 2 == 0).Min();
			numbers.Where(x => x % 2 != 0).Max();
			numbers.Where(x => x % 2 == 0).Sum();
			numbers.Where(x => x % 2 != 0).Average();
		}

		private static void Aufgabe4()
		{
			int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0, 22, 12, 16, 18, 11, 19, 13 };
			numbers.OrderBy(x => x);
			numbers.OrderByDescending(x => x);
			numbers.Where(x => x % 2 == 0).OrderBy(x => x);
		}

		private static void Aufgabe5()
		{
			string[] numbers = { "zero", "one", "two", "three", "four", "five", "six", "seven",
			"eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen" };
			numbers.OrderBy(x => x.Length);
			numbers.OrderBy(x => x.Length).ThenByDescending(x => x);
			numbers.Reverse();
		}

		private static void Aufgabe6()
		{
			DirectoryInfo directoryInfo = new DirectoryInfo("C:\\Windows\\System32");
			var files = directoryInfo.GetFiles();

			foreach (var file in files.OrderByDescending(x => x.Name))
			{
				//Console.WriteLine(file.Name);
			}

			foreach (var file in files.OrderBy(x => x.Length))
			{
				//Console.WriteLine(file.Name + " " + file.Length);
			}

			foreach (var file in files.OrderBy(x => x.LastAccessTime))
			{
				Console.WriteLine(file.Name + " " + file.LastAccessTime);
			}
		}

		private static void Aufgabe7()
		{
			int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0, 22, 12, 16, 18, 11, 19, 13 };
			numbers.Take(5);
			numbers.TakeLast(5);
			numbers.Skip(3).SkipLast(3);
			numbers.Where(x => x > 0);
			numbers.SkipWhile(x => x != 12).Skip(1);

			DirectoryInfo directoryInfo = new DirectoryInfo("C:\\Windows\\System32");
			var files = directoryInfo.EnumerateFiles();

			files.OrderBy(x => x.CreationTime).Take(5);

			var pages = files.Select((dir, index) => new { dir, index })
				.GroupBy(x => x.index / 5)
				.Select(x => x.Select(x => x.dir));

			for (int i = 0; i < pages.Count(); i++)
			{
				foreach (var file in pages.ElementAt(i))
				{
					Console.WriteLine($"{i} {file.Name}");
				}
			}
		}

		private static void Aufgabe8()
		{
			string[] numbers = { "zero", "one", "two", "three", "four", "five", "six",
			"seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen" };

			numbers.GroupBy(x => x.FirstOrDefault());
			numbers.GroupBy(x => x.Length);
			numbers.GroupBy(x => new { FirstLetter = x[0], x.Length });

			/*foreach(var group in numbers.GroupBy(x => x[0]))
			{
				group.GroupBy(x => x.Length);
			}*/
		}

		private static void Aufgabe9()
		{
			var processes = Process.GetProcesses();
			processes.GroupBy(x => x.Threads.Count);
			processes.GroupBy(x => x.Modules.Count);

			foreach (var group in processes.GroupBy(x => x.Modules.Count))
			{
				group.OrderBy(x => x.ProcessName);
			}
		}

		private static void Aufgabe10()
		{
			int[] factorsOf300 = { 2, 2, 3, 5, 5 };
			int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
			int[] numbersB = { 1, 3, 5, 7, 8 };

			factorsOf300.Distinct();
			numbersA.Union(numbersB);
			numbersA.Intersect(numbersB);
			numbersA.Except(numbersB);
		}
	}
}